import numpy as np
from itertools import combinations
from scipy.stats import spearmanr

# -----------------------------
# DATA (category -> observations)
# -----------------------------
data = {
    "healing":     [0.90, 0.92, 0.89, 0.91],
    "spirit":      [0.98, 0.97, 0.99, 0.96, 0.98, 0.97],
    "third_party": [0.95, 0.93, 0.96, 0.94, 0.95],
    "shielding":   [1.00, 1.00, 1.00],
    "distance":    [1.00, 0.99, 1.00, 1.00],
    "self_excl":   [0.00]*10,
    "semantic":    [1.00]*12
}

categories = list(data.keys())

# -----------------------------
# Empirical category positions
# -----------------------------
empirical_pos = {
    c: np.mean(data[c]) for c in categories
}

# Empirical distances
empirical_dists = {}
for a, b in combinations(categories, 2):
    empirical_dists[(a, b)] = abs(empirical_pos[a] - empirical_pos[b])

# -----------------------------
# NCFT-predicted positions
# (structure-only proxy)
#
# Use effective variance as a proxy for
# "depth" or "field stability"
# -----------------------------
ncft_pos = {
    c: np.var(data[c]) + 1e-6  # tiny epsilon to avoid zero
    for c in categories
}

# NCFT distances
ncft_dists = {}
for a, b in combinations(categories, 2):
    ncft_dists[(a, b)] = abs(ncft_pos[a] - ncft_pos[b])

# -----------------------------
# Compare orderings
# -----------------------------
empirical_vals = []
ncft_vals = []

for key in empirical_dists:
    empirical_vals.append(empirical_dists[key])
    ncft_vals.append(ncft_dists[key])

rho, pval = spearmanr(empirical_vals, ncft_vals)

# -----------------------------
# Output
# -----------------------------
print("Empirical category means:")
for c in categories:
    print(f"  {c:12s}: {empirical_pos[c]:.4f}")

print("\nNCFT structural proxy (variance-based):")
for c in categories:
    print(f"  {c:12s}: {ncft_pos[c]:.6f}")

print("\nSpearman rank correlation:")
print(f"  rho = {rho:.4f}")
print(f"  p   = {pval:.4e}")

if rho > 0.5:
    print("\n✅ NCFT captures meaningful category ordering")
else:
    print("\n❌ No strong semantic ordering yet")
