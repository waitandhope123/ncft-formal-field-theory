import numpy as np
import math

# --- Dataset (as provided) ---
healing_final = [0.90, 0.92, 0.89, 0.91]     # from 0.81→0.90 etc; use final values
spirit        = [0.98, 0.97, 0.99, 0.96, 0.98, 0.97]
third_party   = [0.95, 0.93, 0.96, 0.94, 0.95]
shielding     = [1.00, 1.00, 1.00]
distance      = [1.00, 0.99, 1.00, 1.00]
self_excl     = [0.00]*10
semantic      = [1.00]*12

data = {
    "healing": healing_final,
    "spirit": spirit,
    "third_party": third_party,
    "shielding": shielding,
    "distance": distance,
    "self_excl": self_excl,
    "semantic": semantic
}

# --- Deterministic 22/22 split (train=22, test=22) ---
train, test = {}, {}
for k, v in data.items():
    v = list(v)
    m = len(v)//2
    train[k] = v[:m]
    test[k]  = v[m:]

# Move one semantic from test->train to make 22/22 exactly
train["semantic"].append(test["semantic"].pop(0))

assert sum(len(v) for v in train.values()) == 22
assert sum(len(v) for v in test.values())  == 22

train_vals = np.array([x for vs in train.values() for x in vs], dtype=float)
test_vals  = np.array([x for vs in test.values() for x in vs], dtype=float)

# --- Student-t logpdf (for Jeffreys-prior Normal predictive) ---
def student_t_logpdf(x, mu, scale, df):
    # log pdf of Student-t with df degrees, location mu, scale
    from mpmath import log, gamma, pi
    return float(
        log(gamma((df+1)/2)) - log(gamma(df/2))
        - 0.5*log(df*pi*(scale**2))
        - ((df+1)/2)*log(1 + ((x-mu)**2)/(df*(scale**2)))
    )

# --- Null model: Normal with unknown mu,sigma; Jeffreys prior p(mu,sigma)∝1/sigma ---
def null_logpred(train_vals, test_vals):
    n = len(train_vals)
    xbar = float(train_vals.mean())
    s = float(np.std(train_vals, ddof=1))
    df = n - 1
    scale = s * math.sqrt(1 + 1/n)
    return sum(student_t_logpdf(x, xbar, scale, df) for x in test_vals)

# --- NCFT model: fixed means by category (from your claimed prediction targets) ---
theory_means = {
    "healing": 0.90,
    "spirit": 0.98,
    "third_party": 0.95,
    "shielding": 1.00,
    "distance": 1.00,
    "self_excl": 0.00,
    "semantic": 1.00
}

def ncft_logpred(train_dict, test_dict):
    # shared noise sigma estimated from train residuals; Jeffreys prior
    residuals = []
    for k, vals in train_dict.items():
        mu = theory_means[k]
        residuals += [x - mu for x in vals]
    residuals = np.array(residuals, dtype=float)
    n = len(residuals)
    sse = float(np.sum(residuals**2))
    df = n  # known-mean case
    scale = math.sqrt((sse/n) * (1 + 1/n))

    lp = 0.0
    for k, vals in test_dict.items():
        mu = theory_means[k]
        for x in vals:
            lp += student_t_logpdf(x, mu, scale, df)
    return lp, scale, df, sse

lp_null = null_logpred(train_vals, test_vals)
lp_ncft, scale, df, sse = ncft_logpred(train, test)

logBF = lp_ncft - lp_null
BF = math.exp(logBF)

print("log p(test | null) =", lp_null)
print("log p(test | NCFT) =", lp_ncft)
print("log BF_10 =", logBF)
print("BF_10 =", BF)
print("NCFT implied noise scale =", scale, "df =", df, "train SSE =", sse)
