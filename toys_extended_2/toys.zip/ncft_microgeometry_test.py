import numpy as np
import math
from itertools import combinations

# -----------------------------
# DATA (category -> observations)
# -----------------------------
data = {
    "healing":     [0.90, 0.92, 0.89, 0.91],
    "spirit":      [0.98, 0.97, 0.99, 0.96, 0.98, 0.97],
    "third_party": [0.95, 0.93, 0.96, 0.94, 0.95],
    "shielding":   [1.00, 1.00, 1.00],
    "distance":    [1.00, 0.99, 1.00, 1.00],
    "semantic":    [1.00]*12,
    # NOTE: self_excl removed on purpose
}

cats = list(data.keys())

# -----------------------------
# Energy distance (1D)
# -----------------------------
def energy_distance(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    exy = np.mean(np.abs(x[:, None] - y[None, :]))
    exx = np.mean(np.abs(x[:, None] - x[None, :]))
    eyy = np.mean(np.abs(y[:, None] - y[None, :]))
    d2 = 2.0 * exy - exx - eyy
    return float(max(d2, 0.0)) ** 0.5

# -----------------------------
# Spearman without SciPy
# -----------------------------
def rankdata(a):
    a = np.asarray(a)
    order = np.argsort(a)
    ranks = np.empty(len(a), dtype=float)
    ranks[order] = np.arange(len(a), dtype=float)
    sorted_a = a[order]
    i = 0
    while i < len(a):
        j = i
        while j + 1 < len(a) and sorted_a[j + 1] == sorted_a[i]:
            j += 1
        if j > i:
            avg = (i + j) / 2.0
            ranks[order[i:j+1]] = avg
        i = j + 1
    return ranks

def spearmanr(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    rx = rankdata(x); ry = rankdata(y)
    rx -= rx.mean(); ry -= ry.mean()
    denom = (np.sqrt((rx**2).mean()) * np.sqrt((ry**2).mean()) + 1e-12)
    return float((rx * ry).mean() / denom)

# -----------------------------
# K-means in 1D (for a simple 3-pole proxy)
# This avoids needing SciPy/sklearn and avoids EM degeneracy.
# -----------------------------
def kmeans_1d(x, k=3, iters=200, seed=0):
    rng = np.random.default_rng(seed)
    x = np.asarray(x, dtype=float)
    # init centers from quantiles
    qs = np.linspace(0.1, 0.9, k)
    centers = np.quantile(x, qs)
    for _ in range(iters):
        d = np.abs(x[:, None] - centers[None, :])
        labels = np.argmin(d, axis=1)
        new_centers = np.array([
            x[labels == j].mean() if np.any(labels == j) else centers[j]
            for j in range(k)
        ])
        if np.allclose(new_centers, centers, atol=1e-10):
            break
        centers = new_centers
    return centers

def soft_membership_profile(vals, centers, tau=0.01):
    # softmax over negative squared distance
    v = np.asarray(vals, dtype=float)
    d2 = (v[:, None] - centers[None, :])**2
    logits = -d2 / (2*tau*tau)
    logits -= logits.max(axis=1, keepdims=True)
    w = np.exp(logits)
    w /= w.sum(axis=1, keepdims=True)
    return w.mean(axis=0)  # average membership profile

# -----------------------------
# Empirical distance matrix
# -----------------------------
D_emp = np.zeros((len(cats), len(cats)), dtype=float)
for i, a in enumerate(cats):
    for j, b in enumerate(cats):
        if i < j:
            D_emp[i, j] = D_emp[j, i] = energy_distance(data[a], data[b])

# -----------------------------
# NCFT relational proxy: 3-pole soft membership profile
# -----------------------------
all_vals = np.array([x for vs in data.values() for x in vs], dtype=float)
centers = kmeans_1d(all_vals, k=3, seed=0)

profiles = {}
for c in cats:
    profiles[c] = soft_membership_profile(data[c], centers, tau=0.01)

D_ncft = np.zeros((len(cats), len(cats)), dtype=float)
for i, a in enumerate(cats):
    for j, b in enumerate(cats):
        if i < j:
            D_ncft[i, j] = D_ncft[j, i] = float(np.linalg.norm(profiles[a] - profiles[b], ord=2))

# -----------------------------
# Scores
# -----------------------------
emp_vec, ncft_vec = [], []
for i in range(len(cats)):
    for j in range(i+1, len(cats)):
        emp_vec.append(D_emp[i, j])
        ncft_vec.append(D_ncft[i, j])

rho = spearmanr(emp_vec, ncft_vec)

def knn(D, k=2):
    out = {}
    for i, c in enumerate(cats):
        idx = np.argsort(D[i, :])
        idx = [j for j in idx if j != i][:k]
        out[c] = [cats[j] for j in idx]
    return out

k = 2
NN_emp = knn(D_emp, k=k)
NN_ncft = knn(D_ncft, k=k)
overlap = np.mean([len(set(NN_emp[c]).intersection(NN_ncft[c]))/k for c in cats])

# -----------------------------
# Print
# -----------------------------
print("Centers (3-pole proxy):", centers)
print("\nCategory profiles (mean soft memberships):")
for c in cats:
    print(f"  {c:12s}: {profiles[c]}")

print("\nSpearman rank correlation (distance matrices):")
print(f"  rho = {rho:.4f}")

print(f"\n{k}-NN neighborhood overlap:")
print(f"  overlap = {overlap:.4f}")

if rho > 0.5 and overlap > 0.6:
    print("\n✅ Micro-geometry semantic signal detected")
else:
    print("\n❌ No strong micro-geometry signal yet (data may be too coarse)")
