import numpy as np
import math
from itertools import combinations

# -----------------------------
# DATA (category -> observations)
# -----------------------------
data = {
    "healing":     [0.90, 0.92, 0.89, 0.91],
    "spirit":      [0.98, 0.97, 0.99, 0.96, 0.98, 0.97],
    "third_party": [0.95, 0.93, 0.96, 0.94, 0.95],
    "shielding":   [1.00, 1.00, 1.00],
    "distance":    [1.00, 0.99, 1.00, 1.00],
    "self_excl":   [0.00]*10,
    "semantic":    [1.00]*12
}

cats = list(data.keys())

# -----------------------------
# Utility: Energy distance (1D, sample-based)
# D^2 = 2E|X-Y| - E|X-X'| - E|Y-Y'|
# -----------------------------
def energy_distance(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    # pairwise abs diffs
    exy = np.mean(np.abs(x[:, None] - y[None, :]))
    exx = np.mean(np.abs(x[:, None] - x[None, :]))
    eyy = np.mean(np.abs(y[:, None] - y[None, :]))
    d2 = 2.0 * exy - exx - eyy
    return float(max(d2, 0.0)) ** 0.5

# -----------------------------
# Utility: Spearman correlation without SciPy
# -----------------------------
def rankdata(a):
    a = np.asarray(a)
    order = np.argsort(a)
    ranks = np.empty(len(a), dtype=float)
    ranks[order] = np.arange(len(a), dtype=float)
    # average ranks for ties
    sorted_a = a[order]
    i = 0
    while i < len(a):
        j = i
        while j + 1 < len(a) and sorted_a[j + 1] == sorted_a[i]:
            j += 1
        if j > i:
            avg = (i + j) / 2.0
            ranks[order[i:j+1]] = avg
        i = j + 1
    return ranks

def spearmanr(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    rx = rankdata(x)
    ry = rankdata(y)
    rx -= rx.mean()
    ry -= ry.mean()
    denom = (np.sqrt((rx**2).mean()) * np.sqrt((ry**2).mean()) + 1e-12)
    return float((rx * ry).mean() / denom)

# -----------------------------
# Global 2-component Gaussian Mixture (EM), 1D
# -----------------------------
def fit_gmm2_1d(all_vals, max_iter=500, tol=1e-10, sigma_floor=1e-3, seed=0):
    rng = np.random.default_rng(seed)
    x = np.asarray(all_vals, dtype=float)
    n = len(x)

    # init means near min/max (robust for 0/1 data)
    mu1, mu2 = float(np.min(x)), float(np.max(x))
    w = 0.5
    s = float(np.std(x)) if n > 1 else 0.1
    s1 = max(s, sigma_floor)
    s2 = max(s, sigma_floor)

    def norm_pdf(xx, mu, sig):
        return (1.0 / (math.sqrt(2 * math.pi) * sig)) * np.exp(-0.5 * ((xx - mu) / sig) ** 2)

    prev_ll = -np.inf
    for _ in range(max_iter):
        p1 = w * norm_pdf(x, mu1, s1)
        p2 = (1 - w) * norm_pdf(x, mu2, s2)
        denom = p1 + p2 + 1e-12
        r1 = p1 / denom
        r2 = 1 - r1

        w_new = float(np.mean(r1))
        mu1_new = float(np.sum(r1 * x) / (np.sum(r1) + 1e-12))
        mu2_new = float(np.sum(r2 * x) / (np.sum(r2) + 1e-12))

        s1_new = math.sqrt(float(np.sum(r1 * (x - mu1_new) ** 2) / (np.sum(r1) + 1e-12)))
        s2_new = math.sqrt(float(np.sum(r2 * (x - mu2_new) ** 2) / (np.sum(r2) + 1e-12)))
        s1_new = max(s1_new, sigma_floor)
        s2_new = max(s2_new, sigma_floor)

        ll = float(np.sum(np.log(denom)))
        if abs(ll - prev_ll) < tol:
            w, mu1, mu2, s1, s2 = w_new, mu1_new, mu2_new, s1_new, s2_new
            break
        prev_ll = ll
        w, mu1, mu2, s1, s2 = w_new, mu1_new, mu2_new, s1_new, s2_new

    return w, mu1, mu2, s1, s2

def gmm_responsibility(x, params):
    w, mu1, mu2, s1, s2 = params
    x = np.asarray(x, dtype=float)
    def norm_pdf(xx, mu, sig):
        return (1.0 / (math.sqrt(2 * math.pi) * sig)) * np.exp(-0.5 * ((xx - mu) / sig) ** 2)
    p1 = w * norm_pdf(x, mu1, s1)
    p2 = (1 - w) * norm_pdf(x, mu2, s2)
    denom = p1 + p2 + 1e-12
    return p1 / denom  # responsibility for component 1

# -----------------------------
# Build matrices
# -----------------------------
# Empirical distance matrix via energy distance
D_emp = np.zeros((len(cats), len(cats)), dtype=float)
for i, a in enumerate(cats):
    for j, b in enumerate(cats):
        if i < j:
            D_emp[i, j] = D_emp[j, i] = energy_distance(data[a], data[b])

# NCFT-style relational proxy:
# Fit global 2-pole mixture, then represent each category by mean responsibility rbar
all_vals = [x for vs in data.values() for x in vs]
params = fit_gmm2_1d(all_vals, seed=0)

rbar = {}
for c in cats:
    r = gmm_responsibility(data[c], params)
    rbar[c] = float(np.mean(r))

D_ncft = np.zeros((len(cats), len(cats)), dtype=float)
for i, a in enumerate(cats):
    for j, b in enumerate(cats):
        if i < j:
            D_ncft[i, j] = D_ncft[j, i] = abs(rbar[a] - rbar[b])

# -----------------------------
# Score: Spearman over upper triangle distances
# -----------------------------
emp_vec = []
ncft_vec = []
pairs = []
for i in range(len(cats)):
    for j in range(i+1, len(cats)):
        emp_vec.append(D_emp[i, j])
        ncft_vec.append(D_ncft[i, j])
        pairs.append((cats[i], cats[j]))

emp_vec = np.asarray(emp_vec)
ncft_vec = np.asarray(ncft_vec)
rho = spearmanr(emp_vec, ncft_vec)

# -----------------------------
# Score: k-NN overlap
# -----------------------------
def knn_neighbors(D, k=2):
    neigh = {}
    for i, c in enumerate(cats):
        idx = np.argsort(D[i, :])
        idx = [j for j in idx if j != i][:k]
        neigh[c] = [cats[j] for j in idx]
    return neigh

k = 2
NN_emp = knn_neighbors(D_emp, k=k)
NN_ncft = knn_neighbors(D_ncft, k=k)

overlaps = []
for c in cats:
    overlaps.append(len(set(NN_emp[c]).intersection(set(NN_ncft[c]))) / k)
knn_overlap = float(np.mean(overlaps))

# -----------------------------
# Print
# -----------------------------
print("GMM2 params (w, mu1, mu2, s1, s2):")
print(" ", params)

print("\nCategory mixture responsibility rbar (component-1 membership):")
for c in cats:
    print(f"  {c:12s}: {rbar[c]:.6f}")

print("\nSpearman rank correlation between distance matrices:")
print(f"  rho = {rho:.4f}")

print(f"\n{k}-NN neighborhood overlap (mean fraction shared):")
print(f"  overlap = {knn_overlap:.4f}")

# Basic verdict thresholds (pre-registered-ish)
if rho > 0.5 and knn_overlap > 0.5:
    print("\n✅ Relational semantic geometry signal detected")
else:
    print("\n❌ No strong relational geometry signal yet (or proxy too weak)")
