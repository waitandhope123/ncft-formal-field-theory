import numpy as np
import math

# -----------------------------
# DATA (category -> observations)
# -----------------------------
data = {
    "healing":     [0.90, 0.92, 0.89, 0.91],
    "spirit":      [0.98, 0.97, 0.99, 0.96, 0.98, 0.97],
    "third_party": [0.95, 0.93, 0.96, 0.94, 0.95],
    "shielding":   [1.00, 1.00, 1.00],
    "distance":    [1.00, 0.99, 1.00, 1.00],
    "self_excl":   [0.00]*10,
    "semantic":    [1.00]*12
}

# NCFT category means (as currently claimed)
ncft_means = {
    "healing": 0.90,
    "spirit": 0.98,
    "third_party": 0.95,
    "shielding": 1.00,
    "distance": 1.00,
    "self_excl": 0.00,
    "semantic": 1.00
}

# -----------------------------
# Helpers: Student-t predictive for Normal with unknown mean/variance
# (Jeffreys prior p(mu,sigma) ∝ 1/sigma)
# -----------------------------
def student_t_logpdf(x, mu, scale, df):
    # Numerically stable log Student-t pdf
    # pdf = gamma((df+1)/2)/(gamma(df/2)*sqrt(df*pi)*scale) * (1 + ((x-mu)/scale)^2/df)^(-(df+1)/2)
    lgamma = math.lgamma
    return (
        lgamma((df + 1) / 2.0)
        - lgamma(df / 2.0)
        - 0.5 * (math.log(df) + math.log(math.pi) + 2.0 * math.log(scale))
        - ((df + 1) / 2.0) * math.log(1.0 + ((x - mu) / scale) ** 2 / df)
    )

def normal_jeffreys_logpred(train_vals, test_vals):
    """Predictive log-likelihood for test given train under Normal(mu,sigma) with Jeffreys prior."""
    train_vals = np.asarray(train_vals, dtype=float)
    test_vals = np.asarray(test_vals, dtype=float)

    n = len(train_vals)
    if n < 2:
        # Too little data: fallback to very broad predictive
        # This is conservative (hurts the model rather than helping it).
        broad_mu = float(train_vals.mean()) if n == 1 else 0.5
        broad_scale = 0.5
        df = 2
        return float(sum(student_t_logpdf(x, broad_mu, broad_scale, df) for x in test_vals))

    xbar = float(train_vals.mean())
    s = float(np.std(train_vals, ddof=1))
    # avoid zero variance blowups
    s = max(s, 1e-6)

    df = n - 1
    scale = s * math.sqrt(1.0 + 1.0 / n)

    return float(sum(student_t_logpdf(x, xbar, scale, df) for x in test_vals))

# -----------------------------
# Null C: 2-component Gaussian mixture (EM on train, fixed sigma floor)
# -----------------------------
def fit_gmm2(train_vals, max_iter=200, tol=1e-8, sigma_floor=1e-3, rng=None):
    rng = np.random.default_rng(0) if rng is None else rng
    x = np.asarray(train_vals, dtype=float)
    n = len(x)
    if n < 4:
        # too little data, return degenerate mixture near mean
        mu = float(np.mean(x)) if n else 0.5
        return (0.5, mu, mu, 0.1, 0.1)

    # init means near min/max
    mu1, mu2 = float(np.min(x)), float(np.max(x))
    w = 0.5
    s1 = max(float(np.std(x)), sigma_floor)
    s2 = s1

    def norm_pdf(x, mu, s):
        return (1.0 / (math.sqrt(2 * math.pi) * s)) * np.exp(-0.5 * ((x - mu) / s) ** 2)

    prev_ll = -np.inf
    for _ in range(max_iter):
        p1 = w * norm_pdf(x, mu1, s1)
        p2 = (1 - w) * norm_pdf(x, mu2, s2)
        denom = p1 + p2 + 1e-12
        r1 = p1 / denom
        r2 = 1 - r1

        # M-step
        w_new = float(np.mean(r1))
        mu1_new = float(np.sum(r1 * x) / (np.sum(r1) + 1e-12))
        mu2_new = float(np.sum(r2 * x) / (np.sum(r2) + 1e-12))
        s1_new = math.sqrt(float(np.sum(r1 * (x - mu1_new) ** 2) / (np.sum(r1) + 1e-12)))
        s2_new = math.sqrt(float(np.sum(r2 * (x - mu2_new) ** 2) / (np.sum(r2) + 1e-12)))
        s1_new = max(s1_new, sigma_floor)
        s2_new = max(s2_new, sigma_floor)

        # log-likelihood
        ll = float(np.sum(np.log(denom)))
        if abs(ll - prev_ll) < tol:
            w, mu1, mu2, s1, s2 = w_new, mu1_new, mu2_new, s1_new, s2_new
            break
        prev_ll = ll
        w, mu1, mu2, s1, s2 = w_new, mu1_new, mu2_new, s1_new, s2_new

    return (w, mu1, mu2, s1, s2)

def gmm2_logpred(params, test_vals):
    w, mu1, mu2, s1, s2 = params
    x = np.asarray(test_vals, dtype=float)
    def logsumexp(a, b):
        m = np.maximum(a, b)
        return m + np.log(np.exp(a - m) + np.exp(b - m))

    # log N(x|mu,s)
    logn1 = -0.5*np.log(2*np.pi*s1*s1) - 0.5*((x-mu1)/s1)**2 + np.log(w + 1e-12)
    logn2 = -0.5*np.log(2*np.pi*s2*s2) - 0.5*((x-mu2)/s2)**2 + np.log(1 - w + 1e-12)
    return float(np.sum(logsumexp(logn1, logn2)))

# -----------------------------
# Splits
# -----------------------------
def event_holdout_split(data_dict, frac=0.5, seed=0):
    rng = np.random.default_rng(seed)
    train, test = {}, {}
    for k, vals in data_dict.items():
        vals = np.asarray(vals, dtype=float)
        idx = np.arange(len(vals))
        rng.shuffle(idx)
        m = int(math.floor(len(vals) * frac))
        m = max(1, min(m, len(vals)-1)) if len(vals) >= 2 else len(vals)
        train[k] = list(vals[idx[:m]])
        test[k] = list(vals[idx[m:]])
    return train, test

def category_holdout_split(data_dict, frac=0.5, seed=0):
    rng = np.random.default_rng(seed)
    cats = list(data_dict.keys())
    rng.shuffle(cats)
    m = int(math.floor(len(cats) * frac))
    train_cats, test_cats = cats[:m], cats[m:]
    train = {c: data_dict[c] for c in train_cats}
    test  = {c: data_dict[c] for c in test_cats}
    return train, test, train_cats, test_cats

# -----------------------------
# Models
# -----------------------------
def logpred_nullA_pooled(train, test):
    train_vals = [x for vs in train.values() for x in vs]
    test_vals  = [x for vs in test.values() for x in vs]
    return normal_jeffreys_logpred(train_vals, test_vals)

def logpred_nullB_per_category(train, test):
    lp = 0.0
    for k, test_vals in test.items():
        # If category wasn't in train (category holdout), fall back to pooled train
        if k in train and len(train[k]) >= 2:
            lp += normal_jeffreys_logpred(train[k], test_vals)
        else:
            pooled = [x for vs in train.values() for x in vs]
            lp += normal_jeffreys_logpred(pooled, test_vals)
    return float(lp)

def logpred_nullC_gmm2(train, test, seed=0):
    train_vals = [x for vs in train.values() for x in vs]
    test_vals  = [x for vs in test.values() for x in vs]
    params = fit_gmm2(train_vals, rng=np.random.default_rng(seed))
    return gmm2_logpred(params, test_vals)

def logpred_ncft_fixed_means(train, test):
    # Fit ONE shared noise scale from train residuals (conservative floor)
    residuals = []
    for k, vals in train.items():
        mu = ncft_means[k]
        residuals += [x - mu for x in vals]
    residuals = np.asarray(residuals, dtype=float)
    n = len(residuals)
    sse = float(np.sum(residuals**2))
    # scale estimate with floor to prevent "rounding to 0/1" artifacts dominating
    sigma = math.sqrt(max(sse / max(n, 1), 1e-4))  # floor at 0.01^2
    # Predict test with Normal(mu, sigma) (not t), to avoid giving NCFT unfair heavy tails
    lp = 0.0
    for k, vals in test.items():
        mu = ncft_means[k]
        for x in vals:
            lp += -0.5*math.log(2*math.pi*sigma*sigma) - 0.5*((x-mu)/sigma)**2
    return float(lp), sigma

# -----------------------------
# Run evaluations
# -----------------------------
def run_suite(split_name, train, test, seed=0, extra=None):
    lpA = logpred_nullA_pooled(train, test)
    lpB = logpred_nullB_per_category(train, test)
    lpC = logpred_nullC_gmm2(train, test, seed=seed)
    lpN, sigma = logpred_ncft_fixed_means(train, test)

    def bf(logp1, logp0):
        return math.exp(logp1 - logp0)

    print("="*70)
    print(f"{split_name}")
    if extra:
        print(extra)
    print("-"*70)
    print(f"log p(test|nullA pooled)     = {lpA: .6f}")
    print(f"log p(test|nullB per-cat)    = {lpB: .6f}")
    print(f"log p(test|nullC gmm2)       = {lpC: .6f}")
    print(f"log p(test|NCFT fixed means) = {lpN: .6f}  (sigma floor-fit={sigma:.4f})")
    print()
    print(f"BF(NCFT/nullA pooled)  = {bf(lpN, lpA):.3e}")
    print(f"BF(NCFT/nullB per-cat) = {bf(lpN, lpB):.3e}")
    print(f"BF(NCFT/nullC gmm2)    = {bf(lpN, lpC):.3e}")
    print("="*70)
    print()

# Event-holdout
train_e, test_e = event_holdout_split(data, frac=0.5, seed=1)
run_suite("EVENT-HOLDOUT (within-category split)", train_e, test_e, seed=1)

# Category-holdout
train_c, test_c, train_cats, test_cats = category_holdout_split(data, frac=0.5, seed=2)
run_suite(
    "CATEGORY-HOLDOUT (whole categories unseen)",
    train_c, test_c, seed=2,
    extra=f"TRAIN CATS={train_cats} | TEST CATS={test_cats}"
)
