import numpy as np

# -----------------------------
# DATA (category -> observations)
# -----------------------------
data = {
    "healing":     [0.90, 0.92, 0.89, 0.91],
    "spirit":      [0.98, 0.97, 0.99, 0.96, 0.98, 0.97],
    "third_party": [0.95, 0.93, 0.96, 0.94, 0.95],
    "shielding":   [1.00, 1.00, 1.00],
    "distance":    [1.00, 0.99, 1.00, 1.00],
    "self_excl":   [0.00]*10,
    "semantic":    [1.00]*12
}

# -----------------------------
# HOLD-OUT SPLIT (by category)
# -----------------------------
rng = np.random.default_rng(42)
categories = list(data.keys())
rng.shuffle(categories)

train_cats = categories[:len(categories)//2]
test_cats  = categories[len(categories)//2:]

# -----------------------------
# TRAIN: infer GLOBAL spectrum only
# -----------------------------
train_values = np.concatenate([data[c] for c in train_cats])

# Structural NCFT assumption:
# mean coupling scales as ~1/N_eff
N_eff = len(train_values)
C_global = np.mean(train_values)
predicted_mean = C_global  # no category info used

# -----------------------------
# NULL MODEL
# -----------------------------
null_mean = np.mean(train_values)

# -----------------------------
# TEST
# -----------------------------
def mse(pred, true):
    return np.mean((true - pred)**2)

ncft_errors = []
null_errors = []

for c in test_cats:
    true_mean = np.mean(data[c])
    ncft_errors.append(mse(predicted_mean, true_mean))
    null_errors.append(mse(null_mean, true_mean))

print("TRAIN CATEGORIES:", train_cats)
print("TEST CATEGORIES :", test_cats)
print()
print(f"NCFT predicted mean (no labels): {predicted_mean:.4f}")
print(f"Null predicted mean             : {null_mean:.4f}")
print()
print(f"NCFT MSE on held-out categories : {np.mean(ncft_errors):.6f}")
print(f"Null MSE on held-out categories : {np.mean(null_errors):.6f}")

if np.mean(ncft_errors) < np.mean(null_errors):
    print("\n✅ NCFT shows forward predictive advantage")
else:
    print("\n❌ NCFT does NOT outperform null (yet)")
