import numpy as np
from scipy.stats import spearmanr

# ----------------------------
# Utilities
# ----------------------------

def normalize(v):
    n = np.linalg.norm(v)
    return v / n if n > 0 else v

def random_state(dim):
    return normalize(np.random.randn(dim))

def bilinear_overlap(a, b):
    return abs(np.vdot(a, b))**2

def interaction_matrix(states):
    N = len(states)
    C = np.zeros((N, N))
    for i in range(N):
        for j in range(i+1, N):
            C[i,j] = bilinear_overlap(states[i], states[j])
            C[j,i] = C[i,j]
    return C

def matrix_entropy(C, eps=1e-12):
    flat = C.flatten()
    flat = flat / (flat.sum() + eps)
    flat = flat[flat > eps]
    return -np.sum(flat * np.log(flat))

# ----------------------------
# Core simulation
# ----------------------------

def run_simulation(
    N=24,
    dim=8,
    steps=300,
    dt=0.02,
    coherent=True,
    noise=0.0,
    seed=0
):
    rng = np.random.default_rng(seed)

    # Initial states
    states = np.array([random_state(dim) for _ in range(N)])

    # Frequencies
    if coherent:
        freqs = rng.normal(1.0, 0.05, N)   # σ < 0.1
    else:
        freqs = rng.normal(1.0, 0.5, N)    # decoherent

    C_history = []
    entropy_history = []

    for t in range(steps):
        C = interaction_matrix(states)
        C_history.append(C.copy())
        entropy_history.append(matrix_entropy(C))

        # Update rule (pairwise closure)
        new_states = []
        for i in range(N):
            influence = np.zeros(dim)
            for j in range(N):
                if i != j:
                    influence += C[i,j] * states[j]

            # NCFT vs null difference is only freq coherence
            freq_factor = 1.0
            if coherent:
                freq_factor = np.exp(-(freqs[i] - freqs.mean())**2)

            update = states[i] + dt * freq_factor * influence
            update += noise * rng.normal(size=dim)

            new_states.append(normalize(update))

        states = np.array(new_states)

    return np.array(C_history), np.array(entropy_history)

# ----------------------------
# Metrics
# ----------------------------

def rank_stability(C_history):
    """Mean Spearman rank correlation between successive timesteps"""
    corrs = []
    for t in range(len(C_history)-1):
        a = np.sort(C_history[t].flatten())
        b = np.sort(C_history[t+1].flatten())
        r, _ = spearmanr(a, b)
        corrs.append(r)
    return np.nanmean(corrs)

def topk_partner_stability(C_history, k=3):
    """How often top-k partners remain the same"""
    stable = []
    for t in range(len(C_history)-1):
        C1 = C_history[t]
        C2 = C_history[t+1]
        for i in range(len(C1)):
            top1 = np.argsort(C1[i])[-k:]
            top2 = np.argsort(C2[i])[-k:]
            stable.append(len(set(top1) & set(top2)) / k)
    return np.mean(stable)

# ----------------------------
# Run comparison
# ----------------------------

if __name__ == "__main__":

    ncft_C, ncft_H = run_simulation(coherent=True, noise=0.01, seed=1)
    null_C, null_H = run_simulation(coherent=False, noise=0.01, seed=1)

    print("=== Rank stability ===")
    print("NCFT :", rank_stability(ncft_C))
    print("Null :", rank_stability(null_C))

    print("\n=== Top-k partner stability ===")
    print("NCFT :", topk_partner_stability(ncft_C))
    print("Null :", topk_partner_stability(null_C))

    print("\n=== Mean entropy ===")
    print("NCFT :", ncft_H.mean())
    print("Null :", null_H.mean())
