# ncft_constraint_violation_stress_toy.py
#
# Purpose:
# Stress-test NCFT axioms against a generic bilinear null model by
# intentionally injecting instability sources and measuring failure modes.
#
# This toy is designed to DISCRIMINATE constraint-preserving behavior,
# not to demonstrate emergent structure or empirical relevance.

import numpy as np

np.random.seed(0)

# -----------------------
# Utilities
# -----------------------

def normalize(v):
    n = np.linalg.norm(v)
    return v / n if n > 0 else v

def bilinear(a, b):
    return abs(np.vdot(a, b))**2

# -----------------------
# Field System
# -----------------------

class FieldSystem:
    def __init__(self, N, dim, enforce_ncft=True):
        self.N = N
        self.dim = dim
        self.enforce = enforce_ncft

        self.states = np.random.randn(N, dim)
        self.freqs  = np.random.normal(
            1.0,
            0.05 if enforce_ncft else 0.5,
            N
        )

        if self.enforce:
            self.states = np.array([normalize(s) for s in self.states])

    def step(self, noise=0.0, triadic=False):
        new_states = []

        for i in range(self.N):
            influence = np.zeros(self.dim)

            for j in range(self.N):
                if i == j:
                    continue

                C = bilinear(self.states[i], self.states[j])

                # NCFT enforces analytic bounds
                if self.enforce:
                    C = min(max(C, 0.0), 1.0)

                influence += C * self.states[j]

            # Illegal triadic interaction (null only)
            if triadic and not self.enforce:
                k = np.random.randint(0, self.N)
                influence += 0.5 * self.states[k] * np.dot(
                    self.states[i], self.states[k]
                )

            updated = (
                self.states[i]
                + 0.01 * influence
                + noise * np.random.randn(self.dim)
            )

            # NCFT projection
            if self.enforce:
                updated = normalize(updated)

            new_states.append(updated)

        self.states = np.array(new_states)

    def diagnostics(self):
        norms = np.linalg.norm(self.states, axis=1)

        C_vals = []
        overflow = False

        for i in range(self.N):
            for j in range(i + 1, self.N):
                C = bilinear(self.states[i], self.states[j])
                if not np.isfinite(C):
                    overflow = True
                C_vals.append(C)

        C_vals = np.array(C_vals)

        return {
            "max_norm": float(np.max(norms)),
            "min_norm": float(np.min(norms)),
            "max_C": float(np.nanmax(C_vals)),
            "mean_C": float(np.nanmean(C_vals)),
            "overflow_detected": overflow,
            "nan_detected": bool(np.isnan(self.states).any())
        }

# -----------------------
# Stress Test Runner
# -----------------------

def run_stress_test(steps=300):
    ncft = FieldSystem(N=25, dim=8, enforce_ncft=True)
    null = FieldSystem(N=25, dim=8, enforce_ncft=False)

    log = {"ncft": [], "null": []}

    for t in range(steps):
        noise = 0.05 if t > steps // 3 else 0.0
        triadic = t > steps // 2

        ncft.step(noise=noise, triadic=triadic)
        null.step(noise=noise, triadic=triadic)

        log["ncft"].append(ncft.diagnostics())
        log["null"].append(null.diagnostics())

    return log

# -----------------------
# Summary Output
# -----------------------

if __name__ == "__main__":
    results = run_stress_test()

    def summarize(label):
        max_norms = [r["max_norm"] for r in results[label]]
        max_Cs    = [r["max_C"] for r in results[label]]
        overflow  = any(r["overflow_detected"] for r in results[label])
        nans      = any(r["nan_detected"] for r in results[label])

        print(f"\n=== {label.upper()} SYSTEM ===")
        print("Max norm:", max(max_norms))
        print("Max coupling:", max(max_Cs))
        print("Overflow detected:", overflow)
        print("NaNs detected:", nans)

    summarize("ncft")
    summarize("null")
