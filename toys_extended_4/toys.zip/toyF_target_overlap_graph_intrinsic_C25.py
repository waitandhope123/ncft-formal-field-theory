import numpy as np
from toy_utils import random_states, normalize, coupling, pairwise_stats

# ----------------------------
# Graph builders
# ----------------------------
def ring_graph_edges(N: int, k: int = 4):
    """
    Undirected ring with k neighbors on each side (total degree 2k).
    Returns list of edges (i, j) with i<j.
    """
    edges = set()
    for i in range(N):
        for s in range(1, k + 1):
            j = (i + s) % N
            a, b = (i, j) if i < j else (j, i)
            edges.add((a, b))
    return sorted(edges)

def er_graph_edges(N: int, p: float = 0.1, seed: int = 0):
    rng = np.random.default_rng(seed)
    edges = []
    for i in range(N):
        for j in range(i + 1, N):
            if rng.random() < p:
                edges.append((i, j))
    return edges

# ----------------------------
# Intrinsic update machinery
# ----------------------------
def tangent_project(psi: np.ndarray, g: np.ndarray) -> np.ndarray:
    # complex-safe tangent projection at psi
    return g - psi * np.vdot(psi, g)

def energy(psis: np.ndarray, edges, C0: float) -> float:
    E = 0.0
    for (i, j) in edges:
        cij = coupling(psis[i], psis[j])
        E += (cij - C0) ** 2
    return float(E)

def grad_proxy_target_overlap(psis: np.ndarray, edges, C0: float):
    """
    A practical gradient proxy for E = Σ (C_ij - C0)^2.

    For C_ij = |<psi_i|psi_j>|^2, a usable direction (not exact analytic grad,
    but aligned in practice) is:
      g_i += 4*(C_ij - C0) * <psi_j|psi_i> * psi_j
    (and similarly for g_j)

    Then we project to tangent space per i and retract by normalization.
    """
    N, d = psis.shape
    g = np.zeros_like(psis, dtype=psis.dtype)

    for (i, j) in edges:
        psi_i = psis[i]
        psi_j = psis[j]
        inner_ji = np.vdot(psi_j, psi_i)              # <psi_j|psi_i>
        cij = float(np.abs(inner_ji) ** 2)            # |<psi_j|psi_i>|^2

        # coefficient drives cij toward C0
        a = 4.0 * (cij - C0)

        # push i in direction of psi_j, scaled by phase inner product
        g[i] += a * inner_ji * psi_j

        # symmetric push for j
        inner_ij = np.vdot(psi_i, psi_j)
        g[j] += a * inner_ij * psi_i

    return g

def intrinsic_step(psis: np.ndarray, eta: float, edges, C0: float):
    g_all = grad_proxy_target_overlap(psis, edges, C0)
    out = psis.copy()
    for i in range(out.shape[0]):
        gi_tan = tangent_project(out[i], g_all[i])
        out[i] = normalize(out[i] - eta * gi_tan)  # minus: descend energy
    return out

# ----------------------------
# Main run
# ----------------------------
def run(
    N=50,
    d=16,
    steps=1500,
    eta=0.15,
    C0=0.25,
    graph="ring",
    ring_k=4,
    er_p=0.10,
    seed=2,
    print_every=100,
):
    psis = random_states(N, d, complex_states=True, seed=seed)

    if graph == "ring":
        edges = ring_graph_edges(N, k=ring_k)
    elif graph == "er":
        edges = er_graph_edges(N, p=er_p, seed=seed)
    else:
        raise ValueError("graph must be 'ring' or 'er'")

    print(f"TOY F — TARGET-OVERLAP GRAPH INTRINSIC")
    print(f"N={N} d={d} steps={steps} eta={eta} C0={C0} graph={graph} | edges={len(edges)}")

    for t in range(0, steps + 1):
        if t % print_every == 0 or t == steps:
            st = pairwise_stats(psis)  # full-graph stats (not just edges)
            E = energy(psis, edges, C0)
            norms = np.linalg.norm(psis, axis=1)
            max_norm_err = float(np.max(np.abs(norms - 1.0)))
            print(
                f"t={t:04d} | E={E:.6f} | <C>={st['mean']:.6f} σ={st['sigma']:.6f} "
                f"Cmax={st['max']:.6f} gt1={st['count_gt1']} | norm_err={max_norm_err:.2e}"
            )

        # safety: intrinsic should never violate these
        st_now = pairwise_stats(psis)
        if st_now["count_gt1"] > 0:
            print("💥 Unexpected: C>1 detected (should not happen with intrinsic + normalized states).")
            return

        psis = intrinsic_step(psis, eta=eta, edges=edges, C0=C0)

    import os
    os.makedirs("outputs", exist_ok=True)
    np.save("outputs/toyF_final_psis.npy", psis)
    print("Saved outputs/toyF_final_psis.npy")
    print("✅ Completed.")

if __name__ == "__main__":
    run(
        N=50, d=16, steps=1500,
        eta=0.15,
        C0=0.25,
        graph="ring", ring_k=4,
        seed=2,
        print_every=100
    )
