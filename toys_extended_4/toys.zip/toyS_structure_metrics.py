import numpy as np
from toy_utils import coupling, pairwise_stats, random_states

def gram_matrix(psis: np.ndarray) -> np.ndarray:
    # G_ij = <psi_i|psi_j>
    return psis @ np.conjugate(psis).T

def effective_rank_from_gram(G: np.ndarray) -> float:
    """
    Effective rank via entropy of normalized eigenvalues of (G G†) or of |G|^2-like PSD.
    We'll use H = -Σ p log p, erank = exp(H).
    """
    # PSD matrix: K = |G|^2 elementwise is not necessarily PSD; instead use A = G G† (PSD)
    A = G @ np.conjugate(G).T
    evals = np.linalg.eigvalsh(A).real
    evals = np.clip(evals, 0.0, None)
    if evals.sum() <= 0:
        return 0.0
    p = evals / evals.sum()
    p = np.clip(p, 1e-15, 1.0)
    H = -float(np.sum(p * np.log(p)))
    return float(np.exp(H))

def spectral_embed_from_C(psis: np.ndarray, k: int = 6) -> np.ndarray:
    """
    Use C_ij = |<psi_i|psi_j>|^2 as affinity; build Laplacian embedding (top-k eigenvectors).
    """
    N = psis.shape[0]
    C = np.zeros((N, N), dtype=float)
    for i in range(N):
        C[i, i] = 1.0
        for j in range(i + 1, N):
            cij = coupling(psis[i], psis[j])
            C[i, j] = C[j, i] = cij

    # Degree and normalized Laplacian
    deg = np.sum(C, axis=1)
    Dinv_sqrt = np.diag(1.0 / np.sqrt(np.clip(deg, 1e-12, None)))
    L = np.eye(N) - Dinv_sqrt @ C @ Dinv_sqrt

    # Take smallest eigenvectors (excluding the trivial one)
    evals, evecs = np.linalg.eigh(L)
    idx = np.argsort(evals)
    # skip the first eigenvector (often ~constant)
    take = idx[1:k+1]
    X = evecs[:, take]
    # row-normalize
    Xn = X / np.sqrt(np.sum(X**2, axis=1, keepdims=True) + 1e-12)
    return Xn

def kmeans(X: np.ndarray, k: int, seed: int = 0, iters: int = 50):
    rng = np.random.default_rng(seed)
    N = X.shape[0]
    centers = X[rng.choice(N, size=k, replace=False)].copy()
    labels = np.zeros(N, dtype=int)

    for _ in range(iters):
        # assign
        d2 = ((X[:, None, :] - centers[None, :, :]) ** 2).sum(axis=2)
        new_labels = np.argmin(d2, axis=1)

        if np.all(new_labels == labels):
            break
        labels = new_labels

        # update
        for j in range(k):
            mask = labels == j
            if np.any(mask):
                centers[j] = X[mask].mean(axis=0)
            else:
                centers[j] = X[rng.integers(0, N)]
    return labels

def cluster_compactness(X: np.ndarray, labels: np.ndarray) -> float:
    # Mean within-cluster squared distance
    k = labels.max() + 1
    total = 0.0
    count = 0
    for j in range(k):
        pts = X[labels == j]
        if len(pts) <= 1:
            continue
        ctr = pts.mean(axis=0)
        total += float(((pts - ctr) ** 2).sum())
        count += pts.shape[0]
    return total / max(count, 1)

def run(psis: np.ndarray, embed_k=6, clusters=4, seed=0):
    st = pairwise_stats(psis)
    G = gram_matrix(psis)
    erank = effective_rank_from_gram(G)

    X = spectral_embed_from_C(psis, k=embed_k)
    labels = kmeans(X, k=clusters, seed=seed)
    comp = cluster_compactness(X, labels)

    uniq, counts = np.unique(labels, return_counts=True)

    print("TOY S — STRUCTURE METRICS")
    print(f"N={psis.shape[0]} d={psis.shape[1]}")
    print(f"Pairwise: <C>={st['mean']:.6f} σ={st['sigma']:.6f} Cmax={st['max']:.6f}")
    print(f"Effective rank (Gram-derived): {erank:.3f}  (1.0 means collapsed)")
    print(f"Spectral embedding dims: {embed_k} | KMeans clusters: {clusters}")
    print(f"Cluster sizes: {dict(zip(uniq.tolist(), counts.tolist()))}")
    print(f"Within-cluster compactness (lower => tighter): {comp:.6f}")

if __name__ == "__main__":
    psis = np.load("outputs/toyF_final_psis.npy")
    run(psis, embed_k=6, clusters=4, seed=0)