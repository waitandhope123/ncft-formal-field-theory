import numpy as np
import matplotlib.pyplot as plt
from ncft import random_states, flow_step, energy, purity, coupling_matrix

def psd(x, dt=1.0):
    x = np.asarray(x)
    x = x - x.mean()
    X = np.fft.rfft(x)
    P = (np.abs(X)**2) / len(x)
    f = np.fft.rfftfreq(len(x), d=dt)
    return f[1:], P[1:]  # drop zero freq

# ---- regime ----
N, d, eta = 30, 4, 0.2
gamma = 0.02
drive_amp = 0.02
noise = 0.005
steps = 1200
burn = 200

rng = np.random.default_rng(0)
psi = random_states(N, d, seed=0)

E, P, M = [], [], []

for t in range(steps):
    drive = drive_amp * (rng.normal(size=(N,d)) + 1j*rng.normal(size=(N,d)))
    psi = flow_step(psi, eta, noise=noise, gamma=gamma, drive=drive, rng=rng)
    if t >= burn:
        E.append(energy(psi))
        P.append(purity(psi))
        C = coupling_matrix(psi)
        M.append(C.mean())

# PSDs
fE, pE = psd(E)
fP, pP = psd(P)
fM, pM = psd(M)

plt.figure()
plt.loglog(fE, pE, label="E(t)")
plt.loglog(fP, pP, label="purity(t)")
plt.loglog(fM, pM, label="mean C(t)")
plt.xlabel("frequency")
plt.ylabel("PSD")
plt.title("Toy 20: fluctuation spectra under drive/noise")
plt.legend()
plt.tight_layout()
plt.show()
