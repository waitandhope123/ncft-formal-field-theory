import numpy as np
import matplotlib.pyplot as plt
from collections import deque
from ncft import random_states, project

# ---------- graph utilities ----------
def make_ring(N, k=2):
    adj = [[] for _ in range(N)]
    for i in range(N):
        for t in range(1, k+1):
            adj[i].append((i+t) % N)
            adj[i].append((i-t) % N)
    return [list(set(a)) for a in adj]

def bfs_distances(adj, src):
    dist = [-1]*len(adj)
    q = deque([src])
    dist[src] = 0
    while q:
        u = q.popleft()
        for v in adj[u]:
            if dist[v] == -1:
                dist[v] = dist[u] + 1
                q.append(v)
    return np.array(dist)

# ---------- NCFT graph-local flow ----------
def graph_flow_step(psi, eta, adj):
    N, d = psi.shape
    delta = np.zeros_like(psi)
    for i in range(N):
        for j in adj[i]:
            delta[i] += np.vdot(psi[j], psi[i]) * psi[j]
    return project(psi + eta * delta)

# ---------- measure correlation profile ----------
def measure_profile(psi, psi_p, adj, dist, steps=150):
    resp_by_dist = {k: [] for k in range(dist.max()+1)}

    for _ in range(steps):
        for i in range(len(adj)):
            dpsi = np.linalg.norm(psi_p[i] - psi[i])
            resp_by_dist[dist[i]].append(dpsi)

        psi   = graph_flow_step(psi,   eta, adj)
        psi_p = graph_flow_step(psi_p, eta, adj)

    xs, ys = [], []
    for k in sorted(resp_by_dist):
        xs.append(k)
        ys.append(np.mean(resp_by_dist[k]))

    return np.array(xs), np.array(ys)

# ---------- exponential fit ----------
def fit_correlation_length(xs, ys, cutoff=1e-12):
    mask = ys > cutoff
    xs = xs[mask]
    ys = ys[mask]

    logy = np.log(ys)
    coeff = np.polyfit(xs, logy, 1)
    slope = coeff[0]
    xi = -1.0 / slope if slope < 0 else np.inf
    return xi

# ---------- main scan ----------
N, d = 40, 4
etas = [0.05, 0.1, 0.15, 0.25, 0.4]
adj = make_ring(N, k=2)
dist = bfs_distances(adj, 0)

xis = []

for eta in etas:
    psi = random_states(N, d, seed=0)
    for _ in range(400):
        psi = graph_flow_step(psi, eta, adj)

    psi_p = psi.copy()
    v = np.random.normal(size=d) + 1j*np.random.normal(size=d)
    v /= np.linalg.norm(v)
    psi_p[0] = project(psi_p[0] + 1e-3*v)

    xs, ys = measure_profile(psi, psi_p, adj, dist)
    xi = fit_correlation_length(xs, ys)
    xis.append(xi)

    # plot profile
    plt.figure()
    plt.semilogy(xs, ys, "o-")
    plt.xlabel("graph distance")
    plt.ylabel("edge-local response")
    plt.title(f"Toy 18 v3: correlation decay (η={eta})")
    plt.tight_layout()
    plt.show()

# ---------- summary ----------
print("\nToy 18 v3: extracted correlation lengths")
for e, x in zip(etas, xis):
    print(f"  eta={e:.2f}  ->  xi ≈ {x:.2f}")

plt.figure()
plt.plot(etas, xis, "o-")
plt.xlabel("coupling strength η")
plt.ylabel("correlation length ξ")
plt.title("Toy 18 v3: correlation length vs coupling")
plt.tight_layout()
plt.show()
