import numpy as np
import matplotlib.pyplot as plt
from ncft import random_states, flow_step, coupling_matrix

def relaxation_time_from_response(norms, frac=1/np.e, floor=1e-10):
    """
    τ = first time response falls below max(frac * initial, floor).
    If response never decays below threshold, return np.nan.
    """
    y0 = norms[0]
    thresh = max(y0 * frac, floor)
    for t, y in enumerate(norms):
        if y <= thresh:
            return t
    return np.nan

def run_one(N, d, eta, sigma, steady_steps=250, probe_steps=200, eps=1e-3, seed=0):
    rng = np.random.default_rng(seed)
    psi = random_states(N, d, seed=seed)

    # reach steady state under noise sigma
    for _ in range(steady_steps):
        psi = flow_step(psi, eta, noise=sigma, rng=rng)

    C0 = coupling_matrix(psi)

    # perturb one field
    v = rng.normal(size=d) + 1j*rng.normal(size=d)
    v = v / np.linalg.norm(v)
    psi_p = psi.copy()
    psi_p[0] = psi_p[0] + eps * v
    psi_p[0] = psi_p[0] / np.linalg.norm(psi_p[0])

    norms = []
    for _ in range(probe_steps):
        C = coupling_matrix(psi_p)
        norms.append(np.linalg.norm(C - C0))
        psi_p = flow_step(psi_p, eta, noise=sigma, rng=rng)

    norms = np.array(norms)
    # remove numerical floor effects (optional)
    return norms

# ---- parameters you can sweep ----
N, d, eta = 20, 4, 0.2
sigmas = [0.0, 0.002, 0.005, 0.01, 0.02, 0.04, 0.06]
reps = 3

taus = []
for s in sigmas:
    tau_rep = []
    for r in range(reps):
        norms = run_one(N,d,eta,s,seed=10_000 + r + int(1e6*s))
        tau_rep.append(relaxation_time_from_response(norms))

    finite = [t for t in tau_rep if not np.isnan(t)]

    if len(finite) == 0:
        taus.append((s, np.nan, np.nan))
    else:
        taus.append((s, float(np.mean(finite)), float(np.std(finite))))

print("\nToy 17 summary:")
for s, m, sdv in taus:
    if np.isnan(m):
        print(f"  sigma={s:.4f}: τ not observed (effectively infinite)")
    else:
        print(f"  sigma={s:.4f}: τ = {m:.1f} ± {sdv:.1f}")

sig = np.array([x[0] for x in taus])
mu  = np.array([x[1] for x in taus])
sd  = np.array([x[2] for x in taus])

plt.figure()
plt.errorbar(sig, mu, yerr=sd, fmt="o-")
plt.xlabel("noise σ")
plt.ylabel("relaxation time τ (steps to 1/e)")
plt.title("Toy 17: critical slowing-down scan")
plt.tight_layout()
plt.show()
