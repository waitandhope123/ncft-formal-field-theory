import numpy as np
import matplotlib.pyplot as plt
from ncft import random_states, flow_step, coupling_matrix

def relaxation_time_from_response(norms, frac=1/np.e, floor=1e-12):
    y0 = norms[0]
    thresh = max(frac * y0, floor)
    for t, y in enumerate(norms):
        if y <= thresh:
            return t
    return np.nan

def run_pair(N, d, eta, sigma, steady_steps=250, probe_steps=300, eps=1e-3, seed=0):
    rng = np.random.default_rng(seed)
    psi = random_states(N, d, seed=seed)

    # reach steady state
    for _ in range(steady_steps):
        psi = flow_step(psi, eta, noise=sigma, rng=rng)

    # make perturbed copy
    psi_p = psi.copy()
    v = rng.normal(size=d) + 1j * rng.normal(size=d)
    v /= np.linalg.norm(v)
    psi_p[0] = (psi_p[0] + eps * v)
    psi_p[0] /= np.linalg.norm(psi_p[0])

    norms = []

    for _ in range(probe_steps):
        C_ref = coupling_matrix(psi)
        C_pert = coupling_matrix(psi_p)
        norms.append(np.linalg.norm(C_pert - C_ref))

        # identical noise for both
        noise = sigma * (rng.normal(size=psi.shape) + 1j*rng.normal(size=psi.shape))
        psi   = flow_step(psi,   eta, noise=0.0, rng=rng) + noise
        psi_p = flow_step(psi_p, eta, noise=0.0, rng=rng) + noise

        psi   /= np.linalg.norm(psi, axis=1, keepdims=True)
        psi_p /= np.linalg.norm(psi_p, axis=1, keepdims=True)

    return np.array(norms)

# ---- scan parameters ----
N, d, eta = 20, 4, 0.2
sigmas = [0.0, 0.002, 0.005, 0.01, 0.02, 0.04]
reps = 3

taus = []
for s in sigmas:
    tau_rep = []
    for r in range(reps):
        norms = run_pair(N,d,eta,s,seed=1000*r + int(1e6*s))
        tau_rep.append(relaxation_time_from_response(norms))

    finite = [t for t in tau_rep if not np.isnan(t)]
    if len(finite) == 0:
        taus.append((s, np.nan, np.nan))
    else:
        taus.append((s, np.mean(finite), np.std(finite)))

# ---- output ----
print("\nToy 17 v2 summary:")
for s, m, sd in taus:
    if np.isnan(m):
        print(f"  sigma={s:.4f}: τ not observed")
    else:
        print(f"  sigma={s:.4f}: τ = {m:.1f} ± {sd:.1f}")

sig = np.array([x[0] for x in taus])
mu  = np.array([x[1] for x in taus])
sd  = np.array([x[2] for x in taus])

plt.figure()
plt.errorbar(sig, mu, yerr=sd, fmt="o-")
plt.xlabel("noise σ")
plt.ylabel("relaxation time τ (baseline-corrected)")
plt.title("Toy 17 v2: critical slowing-down scan")
plt.tight_layout()
plt.show()
