import numpy as np
import matplotlib.pyplot as plt
from collections import deque
from ncft import random_states, project, coupling_matrix

def bfs_distances(adj, src):
    N = len(adj)
    dist = [-1]*N
    q = deque([src])
    dist[src] = 0
    while q:
        u = q.popleft()
        for v in adj[u]:
            if dist[v] == -1:
                dist[v] = dist[u] + 1
                q.append(v)
    return np.array(dist)

def make_ring(N, k=2):
    adj = [[] for _ in range(N)]
    for i in range(N):
        for t in range(1, k+1):
            a = (i+t) % N
            b = (i-t) % N
            adj[i].append(a); adj[i].append(b)
    return [sorted(set(x)) for x in adj]

def graph_flow_step(psi, eta, adj, rng=None):
    # same as NCFT flow but only sum neighbors
    if rng is None:
        rng = np.random.default_rng()
    N, d = psi.shape
    delta = np.zeros_like(psi)
    for i in range(N):
        for j in adj[i]:
            # <psi_j|psi_i> psi_j
            delta[i] += np.vdot(psi[j], psi[i]) * psi[j]
    delta = delta - eta * 0.0  # keep placeholder; no self-term needed because adjacency excludes i
    psi = project(psi + eta*delta)
    return psi

# ---- run setup ----
N, d, eta = 40, 4, 0.15
adj = make_ring(N, k=2)

rng = np.random.default_rng(0)
psi = random_states(N, d, seed=0)
for _ in range(400):
    psi = graph_flow_step(psi, eta, adj, rng=rng)

C0 = coupling_matrix(psi)

# perturb node 0
v = rng.normal(size=d) + 1j*rng.normal(size=d)
v /= np.linalg.norm(v)
psi_p = psi.copy()
psi_p[0] = project(psi_p[0] + 1e-3*v)

# evolve perturbed system and compute response kernel vs distance
probe_steps = 120
dist = bfs_distances(adj, 0)

resp_by_dist = {k: [] for k in range(dist.max()+1)}
for _ in range(probe_steps):
    C = coupling_matrix(psi_p)
    dC = np.abs(C - C0)
    # summarize response for each node i by total change in row i
    row_resp = dC.sum(axis=1)
    for i in range(N):
        if dist[i] >= 0:
            resp_by_dist[int(dist[i])].append(row_resp[i])
    psi_p = graph_flow_step(psi_p, eta, adj, rng=rng)

# average response per graph distance
xs, ys = [], []
for k in sorted(resp_by_dist.keys()):
    arr = np.array(resp_by_dist[k])
    xs.append(k)
    ys.append(arr.mean())

plt.figure()
plt.semilogy(xs, ys, "o-")
plt.xlabel("graph distance from perturbation")
plt.ylabel("avg response magnitude")
plt.title("Toy 18: correlation length on a ring graph")
plt.tight_layout()
plt.show()
