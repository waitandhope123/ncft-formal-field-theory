import numpy as np
import matplotlib.pyplot as plt
from ncft import random_states, project, coupling_matrix, purity

def detuning_kernel(wi, wj, w0, kappa):
    # suppress coupling when |wi-wj| grows
    return np.exp(- (np.abs(wi - wj) / max(w0,1e-12))**2 / max(kappa,1e-12))

def flow_step_detuned(psi, w, eta, kappa=1.0, rng=None):
    if rng is None:
        rng = np.random.default_rng()
    N, d = psi.shape
    delta = np.zeros_like(psi)
    w0 = np.mean(w)
    for i in range(N):
        for j in range(N):
            if i == j: 
                continue
            K = detuning_kernel(w[i], w[j], w0, kappa)
            delta[i] += K * (np.vdot(psi[j], psi[i]) * psi[j])
    psi = project(psi + eta*delta)
    return psi

# ---- scan detuning strength ----
N, d, eta = 25, 4, 0.15
sigmas = [0.0, 0.02, 0.05, 0.1, 0.2, 0.4]     # frequency dispersion scale
kappas = [0.2, 0.5, 1.0, 2.0]                  # tolerance to detuning
steps = 300

rng = np.random.default_rng(0)

results = {}
for kappa in kappas:
    vals = []
    for sw in sigmas:
        w = rng.normal(loc=1.0, scale=sw, size=N)
        psi = random_states(N, d, seed=int(1000*kappa + 1e4*sw))
        for _ in range(steps):
            psi = flow_step_detuned(psi, w, eta, kappa=kappa, rng=rng)
        vals.append(purity(psi))
    results[kappa] = vals

plt.figure()
for kappa in kappas:
    plt.plot(sigmas, results[kappa], "o-", label=f"kappa={kappa}")
plt.xlabel("frequency dispersion σ_ω")
plt.ylabel("purity (steady)")
plt.title("Toy 19: coherence vs frequency detuning")
plt.legend()
plt.tight_layout()
plt.show()
