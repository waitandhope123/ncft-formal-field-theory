import numpy as np
import matplotlib.pyplot as plt
from collections import deque
from ncft import random_states, project

# ---------- graph constructors ----------
def ring_graph(N, k=2):
    adj = [[] for _ in range(N)]
    for i in range(N):
        for t in range(1, k+1):
            adj[i].append((i+t) % N)
            adj[i].append((i-t) % N)
    return [list(set(a)) for a in adj]

def small_world_graph(N, k=2, p=0.1, seed=0):
    rng = np.random.default_rng(seed)
    adj = ring_graph(N, k)
    for i in range(N):
        for j in adj[i][:]:
            if rng.random() < p:
                new = rng.integers(0, N)
                if new != i and new not in adj[i]:
                    adj[i].remove(j)
                    adj[j].remove(i)
                    adj[i].append(new)
                    adj[new].append(i)
    return adj

def random_regular_graph(N, deg=4, seed=0):
    rng = np.random.default_rng(seed)
    adj = [[] for _ in range(N)]
    stubs = np.repeat(np.arange(N), deg)
    rng.shuffle(stubs)
    for a, b in stubs.reshape(-1, 2):
        if b not in adj[a] and a != b:
            adj[a].append(b)
            adj[b].append(a)
    return adj

# ---------- graph utilities ----------
def bfs_distances(adj, src):
    dist = [-1]*len(adj)
    q = deque([src])
    dist[src] = 0
    while q:
        u = q.popleft()
        for v in adj[u]:
            if dist[v] == -1:
                dist[v] = dist[u] + 1
                q.append(v)
    return np.array(dist)

# ---------- NCFT graph-local flow ----------
def graph_flow_step(psi, eta, adj):
    N, d = psi.shape
    delta = np.zeros_like(psi)
    for i in range(N):
        for j in adj[i]:
            delta[i] += np.vdot(psi[j], psi[i]) * psi[j]
    return project(psi + eta * delta)

# ---------- measure ξ ----------
def measure_xi(adj, eta, N=40, d=4, steps=150):
    dist = bfs_distances(adj, 0)

    psi = random_states(N, d, seed=0)
    for _ in range(400):
        psi = graph_flow_step(psi, eta, adj)

    psi_p = psi.copy()
    v = np.random.normal(size=d) + 1j*np.random.normal(size=d)
    v /= np.linalg.norm(v)
    psi_p[0] = project(psi_p[0] + 1e-3*v)

    resp = {k: [] for k in range(dist.max()+1)}

    for _ in range(steps):
        for i in range(N):
            resp[dist[i]].append(np.linalg.norm(psi_p[i] - psi[i]))
        psi   = graph_flow_step(psi,   eta, adj)
        psi_p = graph_flow_step(psi_p, eta, adj)

    xs, ys = [], []
    for k in sorted(resp):
        xs.append(k)
        ys.append(np.mean(resp[k]))

    xs, ys = np.array(xs), np.array(ys)
    mask = ys > 1e-12
    slope = np.polyfit(xs[mask], np.log(ys[mask]), 1)[0]
    xi = -1/slope if slope < 0 else np.inf
    return xs, ys, xi

# ---------- main comparison ----------
N, eta = 40, 0.2

graphs = {
    "Ring": ring_graph(N),
    "Small-world": small_world_graph(N, p=0.1),
    "Random regular": random_regular_graph(N)
}

xis = {}

for name, adj in graphs.items():
    xs, ys, xi = measure_xi(adj, eta)
    xis[name] = xi

    plt.figure()
    plt.semilogy(xs, ys, "o-")
    plt.xlabel("graph distance")
    plt.ylabel("edge-local response")
    plt.title(f"Toy 18 v4: {name} graph (ξ ≈ {xi:.2f})")
    plt.tight_layout()
    plt.show()

print("\nToy 18 v4: correlation length by topology")
for name, xi in xis.items():
    print(f"  {name}: ξ ≈ {xi:.2f}")
