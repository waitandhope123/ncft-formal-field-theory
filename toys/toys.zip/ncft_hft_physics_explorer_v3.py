import numpy as np
from scipy.linalg import expm

def project_to_unit_disk(psi):
    norm = np.linalg.norm(psi)
    return psi / norm if norm > 0 else psi

def ncft_hft_physics_explorer_v3():
    print("NCFT-HFT v3 - GLOBAL NORMALIZATION")
    print("AXIOM #3: Total system norm=1.000 eternal\n")
    
    scales = [("DYAD", 2), ("GROUP", 7), ("TRIBE", 25), ("SPECIES", 50)]
    
    for name, N in scales:
        dim = 2 * N
        state_vec = np.zeros(dim, dtype=complex)
        
        np.random.seed(42 + N)
        for i in range(N):
            angle = np.random.uniform(0, 2*np.pi)
            state_vec[2*i:2*i+2] = [np.cos(angle), np.sin(angle)]
        
        # Normalize TOTAL SYSTEM at t=0
        state_vec = state_vec / np.linalg.norm(state_vec)
        
        H = np.zeros((dim,dim), dtype=complex)
        for i in range(N):
            for j in range(i+1, N):
                coupling_strength = np.random.uniform(0.01, 0.2)
                coupling = coupling_strength * np.array([[0,0],[1j,0]])
                H[2*i:2*i+2, 2*j:2*j+2] = coupling
                H[2*j:2*j+2, 2*i:2*i+2] = coupling.conj().T
        
        def coherence_stats(state):
            coherences = []
            for i in range(N):
                for j in range(i+1, N):
                    Cij = np.abs(np.vdot(state[2*i:2*i+2], state[2*j:2*j+2]))**2
                    coherences.append(Cij)
            return np.mean(coherences), np.std(coherences)
        
        print(f"{name:6s} (N={N}):", end=" ")
        
        for t, label in [(0.1, "fast"), (1.0, "mid"), (5.0, "slow")]:
            U = expm(-1j * H * t)
            state_t = U @ state_vec
            
            # *** AXIOM #3: GLOBAL NORMALIZATION ***
            state_t = state_t / np.linalg.norm(state_t)
            
            mean_C, std_C = coherence_stats(state_t)
            print(f"{label:4s}:C={mean_C:.3f}σ={std_C:.3f}", end=" ")
        print()
        
        # LONG TEST with GLOBAL normalization
        U_long = expm(-1j * H * 20.0)
        state_long = U_long @ state_vec
        state_long = state_long / np.linalg.norm(state_long)
        final_norm = np.linalg.norm(state_long)
        print(f"                LONG(t=20): norm={final_norm:.3f} {'STABLE' if abs(final_norm-1)<0.01 else '✗'}")

ncft_hft_physics_explorer_v3()
