import numpy as np
from scipy.linalg import expm

def phase_couple(strength):
    return strength * np.array([[0,0],[1j,0]], dtype=complex)

def project_to_unit_disk(psi):
    norm = np.linalg.norm(psi)
    return psi / norm if norm > 0 else psi

def ncft_self_exclusion_test():
    # Identical fields should have C(ii)=0 eternally
    psi_self = np.array([1, 0], dtype=complex)  # Same field
    
    dim = 2  # Single field self-test
    state_vec = np.zeros(dim, dtype=complex)
    state_vec[:] = psi_self
    
    # Self-Hamiltonian = ZERO by axiom #1
    H = np.zeros((dim,dim), dtype=complex)  # No self-coupling
    
    times = np.linspace(0, 10, 20)
    
    for t in times:
        U = expm(-1j * H * t)
        state_t = U @ state_vec
        
        # Normalize (axiom preservation)
        state_t = project_to_unit_disk(state_t)
        
        # Self-exclusion test
        C_self = float(np.abs(state_t.conj().T @ state_t)**2)
        print(f"t={t:.1f}: C_self = {C_self:.6f} (must = 1.000000)")

ncft_self_exclusion_test()
