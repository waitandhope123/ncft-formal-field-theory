import numpy as np
from scipy.linalg import expm

def project_to_unit_disk(psi):
    norm = np.linalg.norm(psi)
    return psi / norm if norm > 0 else psi

def ncft_hft_stress_test(N=50, noise=0.1):
    dim = 2 * N
    state_vec = np.zeros(dim, dtype=complex)
    
    # Initialize fields with noise
    for i in range(N):
        angle = i * 0.05 + np.random.normal(0, noise)
        state_vec[2*i:2*i+2] = [np.cos(angle), np.sin(angle)]
    
    # Build Hamiltonian
    H = np.zeros((dim,dim), dtype=complex)
    for i in range(N):
        for j in range(i+1, N):
            psi_i = state_vec[2*i:2*i+2]
            psi_j = state_vec[2*j:2*j+2]
            Cij = min(np.abs(np.vdot(psi_i, psi_j))**2, 1.0)
            coupling = Cij * np.array([[0,0],[1j,0]])
            H[2*i:2*i+2, 2*j:2*j+2] = coupling
            H[2*j:2*j+2, 2*i:2*i+2] = coupling.conj().T
    
    print(f"NCFT-HFT Stress Test: N={N} fields, {noise*100}% noise")
    
    # Test stability over time
    for t in [0.1, 1.0, 5.0]:
        U = expm(-1j * H * t)
        state_t = U @ state_vec
        
        # Project all fields
        for i in range(N):
            state_t[2*i:2*i+2] = project_to_unit_disk(state_t[2*i:2*i+2])
        
        # Compute coherence stats
        coherences = []
        for i in range(N):
            for j in range(i+1, N):
                Cij_t = np.abs(np.vdot(state_t[2*i:2*i+2], state_t[2*j:2*j+2]))**2
                coherences.append(Cij_t)
        
        mean_C = np.mean(coherences)
        std_C = np.std(coherences)
        print(f"t={t}: mean_C={mean_C:.3f}, stability={std_C:.3f}")

ncft_hft_stress_test()
