import numpy as np
from scipy.linalg import expm

def phase_couple(strength):
    return strength * np.array([[0,0],[1j,0]], dtype=complex)

def ncft_nfield_sim(N=10, t=1.0):
    dim = 2 * N  # 2D states per field
    state_vec = np.zeros(dim, dtype=complex)
    
    # Generate N fields with semantic hierarchy
    for i in range(N):
        angle = i * 0.1  # Gradual detuning
        state_vec[2*i:2*i+2] = np.array([np.cos(angle), np.sin(angle)], dtype=complex)
    
    # Build full Hamiltonian - pairwise phase coupling
    H = np.zeros((dim, dim), dtype=complex)
    for i in range(N):
        for j in range(i+1, N):
            # Fidelity-based coupling strength
            psi_i = state_vec[2*i:2*i+2]
            psi_j = state_vec[2*j:2*j+2]
            Cij = np.abs(psi_i.conj().T @ psi_j)**2
            coupling = Cij * phase_couple(0.1)
            
            H[2*i:2*i+2, 2*j:2*j+2] = coupling
            H[2*j:2*j+2, 2*i:2*i+2] = coupling.conj().T
    
    # Evolve
    U = expm(-1j * H * t)
    state_t = U @ state_vec
    
    # Compute total saturation
    total_C = 0
    for i in range(N):
        for j in range(i+1, N):
            psi_i_t = state_t[2*i:2*i+2]
            psi_j_t = state_t[2*j:2*j+2]
            total_C += np.abs(psi_i_t.conj().T @ psi_j_t)**2
    
    # Stats
    sigmas = []
    for i in range(N):
        psi_i = state_vec[2*i:2*i+2]
        psi_i_t = state_t[2*i:2*i+2]
        drift = np.angle(psi_i_t) - np.angle(psi_i)
        sigmas.append(np.std(drift))
    
    print(f"N={N}")
    print("Total coupling sum =", total_C)
    print("Max pairwise C =", max([np.abs(state_t[2*i:2*i+2].conj().T @ state_t[2*j:2*j+2])**2 
                                  for i in range(N) for j in range(i+1,N)]))
    print("Avg sigma =", np.mean(sigmas))
    print("Max sigma =", np.max(sigmas))

# Run scaling test
ncft_nfield_sim(N=10)
