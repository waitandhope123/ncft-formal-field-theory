import numpy as np

def ncft_diphoton_excess(N: int, sqrt_s=13000):  # 13 TeV LHC
    """Predict ConsciousnessField → γγ signature"""
    C_max = N*(N-1)/2  # Pairwise maximum
    sigma_ncft = 1e-3 * C_max  # pb (picoBarn)
    bkg_qcd = 1e4  # QCD diphoton background
    significance = sigma_ncft / np.sqrt(bkg_qcd)  # FIXED: proper assignment
    return significance

for N in [3, 8, 16, 50]:
    sig = ncft_diphoton_excess(N)
    status = "DETECTABLE" if sig > 5 else "NULL" if sig < 2 else "MARGINAL"
    print(f"N={N}: significance={sig:.1f}σ [{status}]")
