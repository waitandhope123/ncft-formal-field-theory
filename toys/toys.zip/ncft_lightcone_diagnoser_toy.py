#!/usr/bin/env python3
# ncft_lightcone_diagnoser_toy.py
#
# Purpose:
#   Diagnose whether NCFT dynamics exhibits:
#     (A) finite-speed (emergent light-cone) propagation,
#     (B) effectively instantaneous/global response,
#     (C) inconclusive due to low SNR.
#
# Core ideas:
#   - Run baseline and perturbed trajectories (multiple localized impulses).
#   - Extract retarded kernel-like response: G(t) = (C_pert(t)-C_base(t))/eps
#   - Estimate per-pair onset time using adaptive thresholds from pre-t0 noise floor.
#   - Bin onset times by distance and fit:
#       flat model:      dt(r) = const
#       light-cone model dt(r) = a + r/v
#     Compare using AIC / R^2 / slope significance.
#   - If insufficient crossings, auto-escalate (optional) and rerun.

import argparse
import math
import sys
from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np


# -----------------------------
# Geometry: positions + distances
# -----------------------------

def make_positions(N: int, dim: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    # Uniform points in [0,1)^dim (torus)
    return rng.random((N, dim))


def torus_distance(a: np.ndarray, b: np.ndarray) -> float:
    d = np.abs(a - b)
    d = np.minimum(d, 1.0 - d)
    return float(np.sqrt(np.sum(d * d)))


def pairwise_distances(pos: np.ndarray) -> np.ndarray:
    N = pos.shape[0]
    D = np.zeros((N, N), dtype=float)
    for i in range(N):
        for j in range(i + 1, N):
            r = torus_distance(pos[i], pos[j])
            D[i, j] = r
            D[j, i] = r
    return D


# -----------------------------
# "NCFT-like" coupling dynamics + projection
# -----------------------------

def symmetrize_zero_diag(C: np.ndarray) -> np.ndarray:
    C = 0.5 * (C + C.T)
    np.fill_diagonal(C, 0.0)
    return C


def project_axioms(C: np.ndarray) -> np.ndarray:
    # Axiom-ish projection:
    # - symmetric
    # - zero diagonal
    # - clamp off-diagonals to [0,1]
    C = symmetrize_zero_diag(C)
    C = np.clip(C, 0.0, 1.0)
    return C


def initialize_C(N: int, mode: str, rng: np.random.Generator) -> np.ndarray:
    if mode == "coherent":
        # near-fully coherent
        C = np.ones((N, N), dtype=float)
        np.fill_diagonal(C, 0.0)
        return C
    if mode == "random":
        C = rng.random((N, N))
        return project_axioms(C)
    if mode == "sparse":
        C = rng.random((N, N))
        C = (C > 0.85).astype(float) * rng.random((N, N))
        return project_axioms(C)
    raise ValueError(f"Unknown init mode: {mode}")


def evolve_step(C: np.ndarray, D: np.ndarray, dt: float, alpha: float, beta: float,
                noise: float, rng: np.random.Generator) -> np.ndarray:
    """
    A simple NCFT-like evolution:
      dC/dt = alpha*(S(C) - C) - beta*L(D)∘C + noise
    where:
      S(C) is a saturating "closure" nonlinearity pushing couplings toward coherence
      L(D) is a distance-based damping kernel (optional locality pressure)
    This is NOT your full formal core, but it's stable and generates propagating vs global regimes.
    """

    # Nonlinear closure drive: push C toward a "coherence attractor" via sigmoid-like term.
    # Using a smooth saturating function of C and global mean:
    m = np.mean(C[np.triu_indices(C.shape[0], 1)])
    # Drive strength depends on how far from 0.5 the global mean is (self-stabilizing)
    drive = np.tanh(3.0 * (C - (0.5 * m + 0.25)))

    # Distance damping: stronger beta => more locality pressure / slower spread
    # Kernel in [0,1], increasing with distance
    if beta > 0:
        L = D / (np.max(D) + 1e-12)
    else:
        L = 0.0

    dC = alpha * drive - beta * (L * C)

    Cn = C + dt * dC

    if noise > 0:
        Cn = Cn + noise * rng.normal(size=C.shape)

    return project_axioms(Cn)


# -----------------------------
# Impulses (localized perturbations)
# -----------------------------

def apply_impulse(C: np.ndarray, target: int, eps: float, impulse_dir: str,
                 rng: np.random.Generator) -> np.ndarray:
    """
    Impulse modifies couplings between target and others.
    impulse_dir:
      - "random": random signed vector
      - "out": increase target->* couplings
      - "in":  increase *->target couplings (same here due to symmetry projection)
    """
    N = C.shape[0]
    v = np.zeros(N, dtype=float)

    if impulse_dir == "random":
        x = rng.normal(size=N)
        x[target] = 0.0
        # normalize
        norm = np.linalg.norm(x) + 1e-12
        x = x / norm
        v = x
    elif impulse_dir == "out":
        v[:] = 1.0
        v[target] = 0.0
        v = v / (np.linalg.norm(v) + 1e-12)
    elif impulse_dir == "in":
        v[:] = 1.0
        v[target] = 0.0
        v = v / (np.linalg.norm(v) + 1e-12)
    else:
        raise ValueError(f"Unknown impulse_dir: {impulse_dir}")

    Cp = C.copy()
    for j in range(N):
        if j == target:
            continue
        Cp[target, j] = np.clip(Cp[target, j] + eps * v[j], 0.0, 1.0)
        Cp[j, target] = Cp[target, j]
    return project_axioms(Cp)


# -----------------------------
# Metrics / fitting
# -----------------------------

def offdiag_stats(C: np.ndarray) -> Dict[str, float]:
    N = C.shape[0]
    vals = np.array([C[i, j] for i in range(N) for j in range(i + 1, N)], dtype=float)
    return {
        "min_offdiag": float(np.min(vals)),
        "mean_offdiag": float(np.mean(vals)),
        "max_offdiag": float(np.max(vals)),
        "sigma_offdiag": float(np.std(vals)),
    }


def pairwise_sum(C: np.ndarray) -> Dict[str, float]:
    N = C.shape[0]
    s = 0.0
    for i in range(N):
        for j in range(i + 1, N):
            s += C[i, j]
    return {"total_i_lt_j": float(s), "bound": float(N * (N - 1) / 2)}


def fit_flat(r: np.ndarray, y: np.ndarray) -> Tuple[float, float]:
    # y = c
    c = float(np.mean(y))
    rss = float(np.sum((y - c) ** 2))
    return c, rss


def fit_lightcone(r: np.ndarray, y: np.ndarray) -> Tuple[Tuple[float, float], float]:
    # y = a + b*r  with b = 1/v
    A = np.vstack([np.ones_like(r), r]).T
    coef, *_ = np.linalg.lstsq(A, y, rcond=None)
    a, b = float(coef[0]), float(coef[1])
    yhat = a + b * r
    rss = float(np.sum((y - yhat) ** 2))
    return (a, b), rss


def aic(n: int, rss: float, k: int) -> float:
    # AIC for Gaussian errors (up to constant): n*ln(rss/n) + 2k
    rss = max(rss, 1e-18)
    return n * math.log(rss / n) + 2 * k


@dataclass
class DiagnosisResult:
    classification: str
    evidence: Dict[str, float]
    v_star: float
    intercept: float
    r2: float
    crossings: int
    edges: int
    thr_mode: str


# -----------------------------
# Main experiment: run baseline + perturbed, compute G, find onsets
# -----------------------------

def run_trajectory(N: int, dim: int, T: float, dt: float, alpha: float, beta: float,
                   noise: float, init_mode: str, seed: int,
                   impulse: Dict = None) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Returns:
      times: (steps+1,)
      C_series: (steps+1, N, N)
      positions: (N, dim)
    impulse dict:
      { "t0": float, "target": int, "eps": float, "impulse_steps": int, "impulse_dir": str }
    """
    rng = np.random.default_rng(seed)
    pos = make_positions(N, dim, seed=seed + 11)
    D = pairwise_distances(pos)

    C = initialize_C(N, init_mode, rng)
    steps = int(round(T / dt))
    times = np.linspace(0.0, steps * dt, steps + 1)

    C_series = np.zeros((steps + 1, N, N), dtype=float)
    C_series[0] = C

    # impulse schedule
    if impulse is not None:
        t0 = float(impulse["t0"])
        impulse_steps = int(impulse["impulse_steps"])
        t0_idx = int(round(t0 / dt))
    else:
        t0_idx = None
        impulse_steps = 0

    for k in range(steps):
        # apply impulse for impulse_steps starting at t0_idx (inclusive)
        if impulse is not None and t0_idx is not None:
            if reminder := (k >= t0_idx and k < t0_idx + impulse_steps):
                C = apply_impulse(C, impulse["target"], impulse["eps"], impulse["impulse_dir"], rng)

        C = evolve_step(C, D, dt, alpha, beta, noise, rng)
        C_series[k + 1] = C

    return times, C_series, pos


def compute_onsets(
    times: np.ndarray,
    G_series: np.ndarray,
    D: np.ndarray,
    t0: float,
    dt: float,
    target: int,
    nbins: int,
    thr_mode: str,
    thr_value: float,
    pre_window: float,
    k_sigma: float,
) -> Tuple[Dict[int, float], Dict[int, float], Dict[str, float]]:
    """
    Determine onset times for target->j pairs by first threshold crossing after t0.

    thr_mode:
      - "fixed": thr = thr_value
      - "adaptive_sigma": thr_ij = max(thr_value, k_sigma*sigma_pre_ij)
    """
    N = G_series.shape[1]
    t0_idx = int(round(t0 / dt))

    pre_idx0 = max(0, int(round((t0 - pre_window) / dt)))
    pre_idx1 = max(0, t0_idx)

    onsets = {}          # j -> onset_delay
    peak_post = {}       # j -> max|G| post-t0 (diagnostic)

    # Pre-noise floor per pair (target,j)
    sigma_pre = np.zeros(N, dtype=float)
    for j in range(N):
        if j == target:
            continue
        pre = G_series[pre_idx0:pre_idx1, target, j]
        sigma_pre[j] = float(np.std(pre)) if pre.size > 0 else 0.0

    for j in range(N):
        if j == target:
            continue
        post = G_series[t0_idx:, target, j]
        peak_post[j] = float(np.max(np.abs(post))) if post.size > 0 else 0.0

        if thr_mode == "fixed":
            thr = thr_value
        elif thr_mode == "adaptive_sigma":
            thr = max(thr_value, k_sigma * sigma_pre[j])
        else:
            raise ValueError(f"Unknown thr_mode: {thr_mode}")

        # first crossing after t0
        idx = np.where(np.abs(post) >= thr)[0]
        if idx.size > 0:
            onset_k = int(idx[0])
            onsets[j] = onset_k * dt

    # Distance-binned onset averages
    # bins based on off-diagonal distances from target
    rs = np.array([D[target, j] for j in range(N) if j != target], dtype=float)
    rmin, rmax = float(np.min(rs)), float(np.max(rs) + 1e-12)
    edges = np.linspace(rmin, rmax, nbins + 1)

    bin_means = {}
    bin_counts = {}
    for b in range(nbins):
        lo, hi = edges[b], edges[b + 1]
        js = [j for j in range(N) if j != target and (D[target, j] >= lo and D[target, j] < hi)]
        vals = [onsets[j] for j in js if j in onsets]
        if len(vals) > 0:
            bin_means[b] = float(np.mean(vals))
            bin_counts[b] = float(len(vals))

    diag = {
        "crossings": float(len(onsets)),
        "rmin": rmin,
        "rmax": rmax,
    }
    return onsets, peak_post, {"bin_means": bin_means, "bin_counts": bin_counts, **diag}


def diagnose_from_bins(
    bin_means: Dict[int, float],
    bin_counts: Dict[int, float],
    r_edges: np.ndarray,
    min_bins: int,
    dt: float,
    dt_resolution_factor: float,
) -> DiagnosisResult:
    """
    Fit models on binned mean delays.
    """
    # Prepare (r_center, y) vectors
    bs = sorted(bin_means.keys())
    if len(bs) < min_bins:
        return DiagnosisResult(
            classification="INCONCLUSIVE (insufficient distance bins)",
            evidence={"bins": float(len(bs))},
            v_star=float("nan"),
            intercept=float("nan"),
            r2=float("nan"),
            crossings=int(sum(bin_counts.get(b, 0) for b in bs)),
            edges=0,
            thr_mode="",
        )

    r = []
    y = []
    w = []
    for b in bs:
        r_center = 0.5 * (r_edges[b] + r_edges[b + 1])
        r.append(r_center)
        y.append(bin_means[b])
        w.append(bin_counts.get(b, 1.0))
    r = np.array(r, dtype=float)
    y = np.array(y, dtype=float)
    w = np.array(w, dtype=float)

    # Unweighted fits (keep simple & robust)
    c_flat, rss_flat = fit_flat(r, y)
    (a_lc, b_lc), rss_lc = fit_lightcone(r, y)

    # R^2 for lightcone model
    tss = float(np.sum((y - np.mean(y)) ** 2))
    r2 = 1.0 - rss_lc / max(tss, 1e-18)

    # AIC comparison
    n = len(y)
    aic_flat = aic(n, rss_flat, k=1)
    aic_lc = aic(n, rss_lc, k=2)
    delta_aic = aic_flat - aic_lc  # positive favors lightcone

    # Convert slope to v*
    v_star = float("inf") if abs(b_lc) < 1e-12 else (1.0 / b_lc)

    # Decide instantaneous vs finite-speed
    # If slope is tiny compared to dt resolution: treat as instantaneous/global.
    # dt_resolution_factor sets how big a change across r-range must be to count.
    dr = float(np.max(r) - np.min(r) + 1e-12)
    predicted_span = abs(b_lc) * dr

    if predicted_span < dt_resolution_factor * dt:
        classification = "INSTANTANEOUS/GLOBAL (no resolvable distance delay)"
    else:
        # require that lightcone has meaningfully better AIC and decent R^2
        if delta_aic > 2.0 and r2 > 0.4 and v_star > 0:
            classification = "FINITE-SPEED / EMERGENT LIGHT-CONE"
        else:
            classification = "INCONCLUSIVE (weak evidence for finite-speed)"

    return DiagnosisResult(
        classification=classification,
        evidence={
            "aic_flat": float(aic_flat),
            "aic_lightcone": float(aic_lc),
            "delta_aic(flat-lc)": float(delta_aic),
            "predicted_span": float(predicted_span),
            "dt": float(dt),
        },
        v_star=float(v_star),
        intercept=float(a_lc),
        r2=float(r2),
        crossings=int(np.sum(w)),
        edges=0,
        thr_mode="",
    )


# -----------------------------
# Orchestrate multi-impulse + auto-escalation
# -----------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--N", type=int, default=25)
    ap.add_argument("--dim", type=int, default=2)
    ap.add_argument("--T", type=float, default=200.0)
    ap.add_argument("--dt", type=float, default=0.05)
    ap.add_argument("--t0", type=float, default=10.0)
    ap.add_argument("--alpha", type=float, default=0.25)
    ap.add_argument("--beta", type=float, default=0.02)
    ap.add_argument("--noise", type=float, default=0.0)
    ap.add_argument("--init", type=str, default="random", choices=["random", "coherent", "sparse"])
    ap.add_argument("--seed", type=int, default=1234)

    ap.add_argument("--target", type=int, default=0)
    ap.add_argument("--eps", type=float, default=1e-3)
    ap.add_argument("--impulse_steps", type=int, default=2)
    ap.add_argument("--impulses", type=int, default=8)
    ap.add_argument("--impulse_dir", type=str, default="random", choices=["random", "out", "in"])

    ap.add_argument("--nbins", type=int, default=10)
    ap.add_argument("--min_bins", type=int, default=4)

    ap.add_argument("--thr_mode", type=str, default="adaptive_sigma",
                    choices=["adaptive_sigma", "fixed"])
    ap.add_argument("--thr", type=float, default=1e-6,
                    help="Base threshold for onset detection (also lower bound for adaptive).")
    ap.add_argument("--k_sigma", type=float, default=6.0,
                    help="Adaptive threshold multiplier: thr_ij=max(thr, k_sigma*sigma_pre_ij)")
    ap.add_argument("--pre_window", type=float, default=3.0,
                    help="Seconds before t0 to estimate pre-noise floor")
    ap.add_argument("--dt_resolution_factor", type=float, default=2.0,
                    help="How many dt of predicted span required to claim resolvable finite-speed")

    ap.add_argument("--auto_escalate", action="store_true",
                    help="If too few onsets, automatically rerun with stronger impulse settings.")
    ap.add_argument("--max_escalations", type=int, default=3)
    ap.add_argument("--escalate_eps_mult", type=float, default=5.0)
    ap.add_argument("--escalate_steps_add", type=int, default=6)

    args = ap.parse_args()

    N = args.N
    steps = int(round(args.T / args.dt))
    if args.target < 0 or args.target >= N:
        print("ERROR: target out of range", file=sys.stderr)
        sys.exit(2)

    print("\n" + "=" * 90)
    print("NCFT LIGHT-CONE DIAGNOSER TOY")
    print("=" * 90)
    print(f"N={args.N} dim={args.dim} T={args.T} dt={args.dt} steps={steps} t0={args.t0}")
    print(f"alpha={args.alpha} beta={args.beta} noise={args.noise} init={args.init} seed={args.seed}")
    print(f"target={args.target} impulses={args.impulses} eps={args.eps} impulse_steps={args.impulse_steps} dir={args.impulse_dir}")
    print(f"thr_mode={args.thr_mode} thr={args.thr} k_sigma={args.k_sigma} pre_window={args.pre_window}")
    print("=" * 90 + "\n")

    # Precompute positions/distances once (reuse across impulses)
    pos = make_positions(N, args.dim, seed=args.seed + 11)
    D = pairwise_distances(pos)
    rs = np.array([D[args.target, j] for j in range(N) if j != args.target], dtype=float)
    rmin, rmax = float(np.min(rs)), float(np.max(rs) + 1e-12)
    r_edges = np.linspace(rmin, rmax, args.nbins + 1)

    # Multi-impulse accumulate:
    # We'll randomize target each impulse if you want later; for now fixed target but different impulse directions via seed offset.
    escalation = 0
    eps = args.eps
    impulse_steps = args.impulse_steps

    while True:
        all_onsets: List[Tuple[float, float]] = []  # (r, onset_delay)
        total_crossings = 0

        # baseline once per escalation regime
        times_b, Cb, _pos_b = run_trajectory(
            N, args.dim, args.T, args.dt, args.alpha, args.beta, args.noise,
            args.init, seed=args.seed + 1000 * escalation,
            impulse=None
        )

        # sanity print baseline summaries
        print("-" * 90)
        print(f"BASELINE SUMMARY (escalation={escalation})")
        print("-" * 90)
        print("t=0  offdiag:", offdiag_stats(Cb[0]))
        print("t=T  offdiag:", offdiag_stats(Cb[-1]))
        print("t=T  sum   :", pairwise_sum(Cb[-1]))
        print()

        # multiple impulses
        for k in range(args.impulses):
            seed_k = args.seed + 777 * (k + 1) + 1000 * escalation
            impulse = {
                "t0": args.t0,
                "target": args.target,
                "eps": eps,
                "impulse_steps": impulse_steps,
                "impulse_dir": args.impulse_dir,
            }
            times_p, Cp, _pos_p = run_trajectory(
                N, args.dim, args.T, args.dt, args.alpha, args.beta, args.noise,
                args.init, seed=seed_k,
                impulse=impulse
            )

            # Response kernel
            G = (Cp - Cb) / eps

            # Causality check (pre-t0 leakage)
            t0_idx = int(round(args.t0 / args.dt))
            pre = G[:t0_idx, :, :]
            pre_max = float(np.max(np.abs(pre)))
            if k == 0:
                print("-" * 90)
                print("CAUSALITY CHECK (pre-t0 leakage)")
                print("-" * 90)
                print(f"pre_max_abs={pre_max:.6e}")
                print()

            onsets, peak_post, diag = compute_onsets(
                times_p, G, D, args.t0, args.dt, args.target,
                args.nbins, args.thr_mode, args.thr, args.pre_window, args.k_sigma
            )
            total_crossings += len(onsets)

            # collect (r, onset) for fitting using per-pair data
            for j, dt_on in onsets.items():
                all_onsets.append((D[args.target, j], dt_on))

        # If no or too few onsets, potentially auto-escalate
        print("-" * 90)
        print("ONSET COLLECTION SUMMARY")
        print("-" * 90)
        print(f"escalation={escalation}  eps={eps}  impulse_steps={impulse_steps}")
        print(f"total_crossings (all impulses combined) = {total_crossings}")
        print()

        if len(all_onsets) < 20 and args.auto_escalate and escalation < args.max_escalations:
            escalation += 1
            eps *= args.escalate_eps_mult
            impulse_steps += args.escalate_steps_add
            print(f"[AUTO-ESCALATE] Too few crossings. Rerunning with eps={eps} impulse_steps={impulse_steps}\n")
            continue

        # Build binned means from pooled pair data
        bin_vals: Dict[int, List[float]] = {b: [] for b in range(args.nbins)}
        for r, dt_on in all_onsets:
            b = int(np.searchsorted(r_edges, r, side="right") - 1)
            b = max(0, min(args.nbins - 1, b))
            bin_vals[b].append(dt_on)

        bin_means = {b: float(np.mean(v)) for b, v in bin_vals.items() if len(v) > 0}
        bin_counts = {b: float(len(v)) for b, v in bin_vals.items() if len(v) > 0}

        print("-" * 90)
        print("DISTANCE-BINNED ONSET MEANS  Δt(r)")
        print("-" * 90)
        for b in sorted(bin_means.keys()):
            rc = 0.5 * (r_edges[b] + r_edges[b + 1])
            print(f"bin[{r_edges[b]:.3f},{r_edges[b+1]:.3f}] r~{rc:.4f}  <Δt>={bin_means[b]:.6f}  (n={int(bin_counts[b])})")
        print()

        # Fit / diagnose
        result = diagnose_from_bins(
            bin_means, bin_counts, r_edges, args.min_bins,
            dt=args.dt, dt_resolution_factor=args.dt_resolution_factor
        )

        # Estimate edges (adjacency): pairs responding within a max delay (e.g., 5.0)
        max_delay = 5.0
        edges = sum(1 for (_r, dt_on) in all_onsets if dt_on <= max_delay)
        result.edges = int(edges)
        result.thr_mode = args.thr_mode

        print("=" * 90)
        print("DIAGNOSIS")
        print("=" * 90)
        print("classification:", result.classification)
        print(f"v* (if meaningful) = {result.v_star}")
        print(f"intercept a        = {result.intercept}")
        print(f"R^2 (lightcone fit) = {result.r2}")
        print(f"crossings          = {result.crossings}")
        print(f"edges (Δt<=5)      = {result.edges}")
        print("evidence:", {k: float(v) for k, v in result.evidence.items()})
        print("=" * 90)

        # Suggested summary line
        # Keep it honest, but “answer-producing”.
        lc_ok = (
            result.classification.startswith("FINITE-SPEED")
            and np.isfinite(result.v_star)
            and result.v_star > 0
        )
        if lc_ok:
            v_txt = f"{result.v_star:.6g}"
            status = "⭐ Emergent finite-speed causality resolved (light-cone extracted)"
        elif result.classification.startswith("INSTANTANEOUS"):
            v_txt = "inf (dt-limited)"
            status = "⭐ Nonlocal / effectively instantaneous response resolved (no light-cone delay)"
        else:
            v_txt = "unresolved"
            status = "⚠️ Light-cone unresolved (SNR/threshold); see evidence + escalate settings"

        print("\n" + "=" * 90)
        print("SUGGESTED SUMMARY LINE (COPY/PASTE)")
        print("=" * 90)
        print("ncft_lightcone_diagnoser_toy.py")
        print(
            "RESULT: Pooled multi-impulse retarded onsets Δt(r) (adaptive thresholds from pre-t0 noise floor) "
            f"fit flat vs light-cone; classification={result.classification}; "
            f"v*={v_txt}, R²={result.r2:.3f}, crossings={result.crossings}, edges(Δt<=5)={result.edges}; "
            f"ΔAIC(flat-lc)={result.evidence.get('delta_aic(flat-lc)', float('nan')):.3f}"
        )
        print(f"STATUS: {status}")
        print("=" * 90 + "\n")
        break


if __name__ == "__main__":
    main()
