"""
ncft_coupled_dynamics_simulator.py

NCFT Coupled Dynamics Simulator (CDS)
Runs NCFT (via Axiomatic Closure Operator) alongside:
  1) Harmonic oscillators
  2) Brownian particles
  3) Lattice scalar field

Physics evolves normally.
NCFT is observed, not injected.
"""

import numpy as np
from itertools import combinations

EPS = 1e-12

# ============================================================
# NCFT CORE (ACO)
# ============================================================

class ConsciousnessField:
    def __init__(self, fid, state):
        self.id = fid
        self.state = self._norm(state)

    def _norm(self, psi):
        n = np.linalg.norm(psi)
        if n < EPS:
            raise ValueError("Zero norm forbidden")
        return psi / n


def coupling(f1, f2):
    if f1.id == f2.id:
        return 0.0
    c = abs(np.vdot(f1.state, f2.state)) ** 2
    if not (0.0 - EPS <= c <= 1.0 + EPS):
        raise AssertionError("Coupling bound violated")
    return float(np.clip(c, 0.0, 1.0))


def ncft_metrics(fields):
    pairs = [coupling(f1, f2) for f1, f2 in combinations(fields, 2)]
    mean = float(np.mean(pairs))
    sigma = float(np.std(pairs))
    return mean, sigma


# ============================================================
# PHYSICS SUBSTRATES
# ============================================================

def evolve_oscillators(x, v, k=1.0, dt=0.05, noise=0.02):
    a = -k * x
    v += a * dt + noise * np.random.randn(*v.shape)
    x += v * dt
    energy = 0.5 * (v**2 + k * x**2).sum()
    phase_spread = np.std(np.arctan2(v, x))
    return x, v, energy, phase_spread


def evolve_particles(pos, dt=0.05, noise=0.2):
    pos += noise * np.random.randn(*pos.shape) * dt
    spread = np.std(pos)
    return pos, spread


def evolve_lattice(phi, dt=0.05, kappa=0.2, noise=0.01):
    lap = np.roll(phi, 1) + np.roll(phi, -1) - 2 * phi
    phi += kappa * lap * dt + noise * np.random.randn(*phi.shape)
    variance = np.var(phi)
    return phi, variance


# ============================================================
# MAIN SIMULATION
# ============================================================

def run_sim(T=100, N=8, dim=16):
    rng = np.random.default_rng(0)

    # Physics initial conditions
    x = rng.normal(size=N)
    v = rng.normal(size=N)
    pos = rng.normal(size=(N, 2))
    phi = rng.normal(size=32)

    # NCFT fields
    fields = [
        ConsciousnessField(
            f"f{i}",
            rng.normal(size=dim) + 1j * rng.normal(size=dim)
        )
        for i in range(N)
    ]

    for t in range(T):
        x, v, E, phase = evolve_oscillators(x, v)
        pos, spread = evolve_particles(pos)
        phi, var = evolve_lattice(phi)

        meanC, sigmaC = ncft_metrics(fields)
        status = "COHERENT" if sigmaC < 0.1 else "DECOHERED"

        print(
            f"t={t:03d} | "
            f"OSC: E={E:6.2f} φσ={phase:4.2f} | "
            f"PART: σ={spread:4.2f} | "
            f"LAT: var={var:6.4f} | "
            f"NCFT: ⟨C⟩={meanC:6.4f} σ={sigmaC:6.4f} {status}"
        )

        # Hard axiom check
        if sigmaC >= 0.1:
            raise RuntimeError("NCFT coherence axiom violated")

    print("\nSIMULATION COMPLETE — NCFT REMAINED AXIOMATICALLY CLOSED")


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    run_sim(T=120)
