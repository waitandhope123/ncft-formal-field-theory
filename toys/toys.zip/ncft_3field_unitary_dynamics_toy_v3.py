import numpy as np
from scipy.linalg import expm

psi1 = np.array([1, 0], dtype=complex)
psi2 = np.array([1, 0], dtype=complex)  
psi3 = np.array([0.995, 0.1], dtype=complex)

state_vec = np.zeros(6, dtype=complex)
state_vec[0:2] = psi1; state_vec[2:4] = psi2; state_vec[4:6] = psi3

def phase_couple(strength):
    return strength * np.array([[0,0],[1j,0]], dtype=complex)

C12 = 1.0; C13 = np.abs(psi1.conj().T @ psi3)**2; C23 = np.abs(psi2.conj().T @ psi3)**2
H = np.zeros((6,6), dtype=complex)

H[0:2,2:4] = H[2:4,0:2] = C12 * phase_couple(0.1)
H[0:2,4:6] = H[4:6,0:2] = C13 * phase_couple(0.1) 
H[2:4,4:6] = H[4:6,2:4] = C23 * phase_couple(0.1)

U = expm(-1j * H * 1.0)
state_t = U @ state_vec

psi1_t = state_t[0:2]; psi2_t = state_t[2:4]; psi3_t = state_t[4:6]

print("C12 =", float(np.abs(psi1_t.conj().T @ psi2_t)**2))
print("C13 =", float(np.abs(psi1_t.conj().T @ psi3_t)**2)) 
print("C23 =", float(np.abs(psi2_t.conj().T @ psi3_t)**2))

freq_drift1 = np.angle(psi1_t) - np.angle(psi1)
freq_drift2 = np.angle(psi2_t) - np.angle(psi2)
sigma_t = np.std(np.concatenate([freq_drift1, freq_drift2]))
print("sigma =", sigma_t)
