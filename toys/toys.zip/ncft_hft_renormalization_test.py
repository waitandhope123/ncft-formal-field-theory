import numpy as np
from scipy.linalg import expm, eigh

class NCFTRenorm:
    def __init__(self, N):
        self.N = N
        self.dim = 2 * N
        self.coupling = np.ones(N) * 0.1  # Running coupling g(μ)
        self.state = self.init_hierarchy()
    
    def init_hierarchy(self):
        state = np.zeros(self.dim, dtype=complex)
        for i in range(self.N):
            # Fractal phase structure
            phase = i * np.pi * (1 + 0.1 * np.sin(i * 0.5))
            state[2*i:2*i+2] = [np.cos(phase), np.sin(phase)]
        return state / np.linalg.norm(state)
    
    def beta_function(self, g):
        """NCFT beta function: dg/dlnμ = β(g)"""
        return -0.02 * g**3 + 0.01 * g  # QCD-like with IR fixed point
    
    def run_coupling_flow(self, scales):
        """Run coupling from UV to IR"""
        g_flow = np.zeros((len(scales), self.N))
        for i, s in enumerate(scales):
            self.coupling *= np.exp(self.beta_function(self.coupling) * s)
            g_flow[i] = self.coupling
        return g_flow
    
    def build_rg_hamiltonian(self, scale_idx=0):
        """Scale-dependent Hamiltonian H(μ)"""
        H = np.zeros((self.dim, self.dim), dtype=complex)
        
        # Multi-scale interactions
        scales = [0.1, 0.5, 1.0, 2.0]  # UV→IR
        g_mu = self.coupling[scale_idx % 4] if scale_idx < 4 else 0.05
        
        for i in range(self.N):
            for j in range(i+1, self.N):
                # Distance-dependent coupling
                distance = abs(i - j)
                g_ij = g_mu / (1 + distance * 0.1)
                
                # Hierarchical phase coupling
                psi_i = self.state[2*i:2*i+2]
                psi_j = self.state[2*j:2*j+2]
                Cij = np.abs(np.vdot(psi_i, psi_j))**2
                
                coupling = g_ij * Cij * np.array([[0, 0], [1j, 0]])
                H[2*i:2*i+2, 2*j:2*j+2] = coupling
                H[2*j:2*j+2, 2*i:2*i+2] = coupling.conj().T
        
        return H

def ncft_hft_renorm_test():
    print("NCFT-HFT RENORMALIZATION GROUP FLOW")
    print("Beta functions | Fixed points | Phase transitions\n")
    
    for N in [4, 12, 32]:
        renorm = NCFTRenorm(N)
        
        # Run coupling flow UV→IR
        scales = np.logspace(-2, 1, 8)  # 10 scales
        g_flow = renorm.run_coupling_flow(scales)
        
        def rg_stats(state, H):
            evals = np.linalg.eigvals(H)
            mean_C = np.mean([np.abs(np.vdot(state[2*i:2*i+2], state[2*j:2*j+2]))**2 
                            for i in range(N) for j in range(i+1, N)])
            return mean_C, np.mean(np.abs(evals)), np.std(np.abs(evals))
        
        print(f"N={N:2d}:", end=" ")
        
        state = renorm.state.copy()
        for scale_idx, scale in enumerate([0, 3, 7]):  # UV, mid, IR
            H = renorm.build_rg_hamiltonian(scale_idx)
            
            # Evolve at this scale
            U = expm(-1j * H * scale)
            state_t = U @ state
            state_t = state_t / np.linalg.norm(state_t)
            
            mean_C, E_mean, E_std = rg_stats(state_t, H)
            g_eff = np.mean(renorm.coupling[scale_idx])
            
            phase = "UV" if scale_idx == 0 else "IR" if scale_idx == 2 else "MID"
            print(f"{phase}:C={mean_C:.3f}g={g_eff:.3f}Eσ={E_std:.3f}", end=" ")
        
        print(f"| flow✓")

ncft_hft_renorm_test()
