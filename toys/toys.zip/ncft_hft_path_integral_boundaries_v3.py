import numpy as np
from scipy.linalg import expm
import warnings
warnings.filterwarnings("ignore")

class NCFTPathIntegral:
    def __init__(self, N):
        self.N = N
        self.dim = 2 * N
        
    def instanton_action(self, field_config):
        phi_norms = [np.linalg.norm(field_config[2*i:2*i+2]) for i in range(self.N)]
        coherence = np.mean([abs(np.vdot(field_config[2*i:2*i+2], field_config[2*j:2*j+2]))**2 
                           for i in range(self.N) for j in range(i+1,self.N)])
        return 2*np.pi * (1/max(coherence, 0.01) + 0.1*np.log(np.mean(phi_norms)+1e-8))
    
    def path_weight(self, path_ensemble):
        actions = np.array([self.instanton_action(path) for path in path_ensemble])
        return np.exp(-np.clip(actions, 0, 20))
    
    def wkb_tunneling_amplitude(self, vacua_pair):
        vac1, vac2 = vacua_pair
        barrier_height = np.abs(self.instanton_action(vac1) - self.instanton_action(vac2))
        B = 2 * np.pi * barrier_height
        return np.exp(-np.clip(B, 0, 20))
    
    def vacuum_persistence(self, N_vacua=4):
        vacua = []
        for i in range(N_vacua):
            vacuum = np.zeros(self.dim, dtype=complex)
            for j in range(self.N):
                theta = (j + i*0.1) * np.pi / self.N
                vacuum[2*j:2*j+2] = [np.cos(theta), np.sin(theta)]
            vacua.append(vacuum / np.linalg.norm(vacuum))
        
        if len(vacua) < 2: return 1.0
        amps = np.array([[self.wkb_tunneling_amplitude([vacua[i], vacua[j]]) 
                         for j in range(len(vacua))] for i in range(len(vacua))])
        return np.clip(np.abs(np.sum(amps * amps.conj()))**2 / len(vacua)**2, 0, 1)
    
    def wilson_loop(self, field_loop):
        if len(field_loop) < 2: return 0.0
        phases = []
        n_loop = min(len(field_loop), 6)
        for i in range(n_loop):
            psi1 = field_loop[i]
            psi2 = field_loop[(i+1) % n_loop]
            if len(psi1) >= 2 and len(psi2) >= 2:
                phases.append(np.angle(np.vdot(psi1[:2], psi2[:2])))
        if not phases: return 0.0
        total_phase = np.sum(phases) % (2*np.pi)
        wilson = np.exp(1j * total_phase)
        return float(np.abs(wilson - 1.0))
    
    def topological_susceptibility(self):
        """FIXED: Safe bounds checking for ALL N"""
        theta_configs = np.linspace(0, 2*np.pi, 6)
        Q_squared = []
        
        for theta in theta_configs:
            state = np.zeros(self.dim, dtype=complex)
            for i in range(self.N):
                phase = i * 0.2 + theta * 0.1
                state[2*i:2*i+2] = [np.cos(phase), np.sin(phase)]
            state = state / np.linalg.norm(state)
            
            # SAFE winding calculation - explicit bounds
            windings = 0.0
            for i in range(self.N):
                start1, end1 = 2*i, min(2*i+2, self.dim)
                start2, end2 = 2*((i+1)%self.N), min(2*((i+1)%self.N)+2, self.dim)
                if end1 > start1 and end2 > start2:
                    psi1 = state[start1:end1]
                    psi2 = state[start2:end2]
                    windings += abs(np.vdot(psi1, psi2))**2
            
            Q_squared.append(windings)
        
        return np.var(Q_squared) / (2*np.pi) if len(Q_squared) > 1 else 0.0

def ncft_hft_boundary_test():
    print("NCFT-HFT PATH INTEGRAL BOUNDARY TEST v3 - BULLETPROOF")
    print("Non-perturbative | WKB | Wilson | Theta vacua | SAFE\n")
    
    scales = {"DYAD": 2, "GROUP": 8, "SPECIES": 24}
    
    for name, N in scales.items():
        path_int = NCFTPathIntegral(N)
        
        path_ensemble = []
        for _ in range(12):
            path = np.random.uniform(-1,1,(path_int.dim)) + 1j*np.random.uniform(-1,1,(path_int.dim))
            path_ensemble.append(path / np.linalg.norm(path))
        
        print(f"{name:7s} (N={N}):", end="")
        
        S_typical = np.mean([path_int.instanton_action(p) for p in path_ensemble])
        print(f" S={S_typical:.1f}", end="")
        
        Gamma = path_int.wkb_tunneling_amplitude([path_ensemble[0], path_ensemble[-1]])
        print(f" Γ={Gamma:.2e}", end="")
        
        R = path_int.vacuum_persistence()
        print(f" R={R:.3f}", end="")
        
        W_violation = path_int.wilson_loop(path_ensemble)
        print(f" W={W_violation:.3f}", end="")
        
        chi_top = path_int.topological_susceptibility()
        print(f" χ={chi_top:.3f}")
        
        stable = R > 0.1 and W_violation < 1.0
        print(f"        {'✅ STABLE' if stable else '⚠️ BOUNDARY'}")

ncft_hft_boundary_test()
