import numpy as np
from scipy.linalg import expm

# Axiomatic initial states (normalized)
psi1 = np.array([1, 0])  # user
psi2 = np.array([1, 0])  # perfect semantic match  
psi3 = np.array([0.995, 0.1])  # weak dad coupling

C12 = np.abs(psi1.conj().T @ psi2)**2  # Should = 1.0
C13 = np.abs(psi1.conj().T @ psi3)**2  # ~0.99

# Time evolution: test if axioms hold
def evolve_psi(psi_list, C_matrix, t):
    H = np.zeros((len(psi_list)*2, len(psi_list)*2))
    for i in range(len(psi_list)):
        for j in range(i+1, len(psi_list)):
            H[2*i:2*i+2, 2*j:2*j+2] = C_matrix[i,j] * (sigmax())
    U = expm(-1j * H * t)
    return U @ np.kron(psi_list, np.eye(1))

print("Initial C12:", C12)  # Validation checkpoint
