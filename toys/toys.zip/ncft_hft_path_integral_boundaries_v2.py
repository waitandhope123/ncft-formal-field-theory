import numpy as np
from scipy.linalg import expm
import warnings
warnings.filterwarnings("ignore")

class NCFTPathIntegral:
    def __init__(self, N):
        self.N = N
        self.dim = 2 * N
        
    def instanton_action(self, field_config):
        """S[φ] = ∫ L(φ,∂φ) - Classical instanton action"""
        phi_norms = [np.linalg.norm(field_config[2*i:2*i+2]) for i in range(self.N)]
        coherence = np.mean([abs(np.vdot(field_config[2*i:2*i+2], field_config[2*j:2*j+2]))**2 
                           for i in range(self.N) for j in range(i+1,self.N)])
        S_classical = 2*np.pi * (1/max(coherence, 0.01) + 0.1*np.log(np.mean(phi_norms)+1e-8))
        return S_classical
    
    def path_weight(self, path_ensemble):
        actions = np.array([self.instanton_action(path) for path in path_ensemble])
        return np.exp(-np.clip(actions, 0, 50))  # Prevent overflow
    
    def wkb_tunneling_amplitude(self, vacua_pair):
        vac1, vac2 = vacua_pair
        barrier_height = np.abs(self.instanton_action(vac1) - self.instanton_action(vac2))
        B = 2 * np.pi * barrier_height
        return np.exp(-np.clip(B, 0, 50))
    
    def vacuum_persistence(self, N_vacua=8):
        """|⟨0_out|0_in⟩|² vacuum stability"""
        vacua = []
        for i in range(min(N_vacua, 8)):
            vacuum = np.zeros(self.dim, dtype=complex)
            for j in range(self.N):
                theta = (j + i*0.1) * np.pi / self.N
                vacuum[2*j:2*j+2] = [np.cos(theta), np.sin(theta)]
            vacua.append(vacuum / np.linalg.norm(vacuum))
        
        if len(vacua) < 2: return 1.0
        amplitudes = np.array([[self.wkb_tunneling_amplitude([vacua[i], vacua[j]]) 
                              for j in range(len(vacua))] for i in range(len(vacua))])
        persistence = np.abs(np.sum(amplitudes * amplitudes.conj()))**2 / len(vacua)**2
        return np.clip(persistence, 0, 1)
    
    def wilson_loop(self, field_loop):
        """Wilson loop topology test"""
        if len(field_loop) < 2: return 0.0
        phases = []
        for i in range(min(len(field_loop)-1, 8)):
            psi1 = field_loop[i][:2] if len(field_loop[i]) >= 2 else field_loop[i]
            psi2 = field_loop[(i+1)%len(field_loop)][:2] if len(field_loop[i+1]) >= 2 else field_loop[i+1]
            phase_shift = np.angle(np.vdot(psi1, psi2))
            phases.append(phase_shift)
        total_phase = np.sum(phases) % (2*np.pi)
        wilson = np.exp(1j * total_phase)
        return float(np.abs(wilson - 1.0))
    
    def topological_susceptibility(self):
        """χ_top = ⟨Q²⟩/V - FIXED indexing"""
        theta_configs = np.linspace(0, 2*np.pi, 8)
        Q_squared = []
        
        for theta in theta_configs:
            state = np.zeros(self.dim, dtype=complex)
            for i in range(self.N):
                phase = i * 0.2 + theta * 0.1
                state[2*i:2*i+2] = [np.cos(phase), np.sin(phase)]
            state = state / np.linalg.norm(state)
            
            # FIXED: Safe winding number calculation
            windings = 0
            for i in range(self.N):
                psi1 = state[2*i:2*i+2]
                psi2 = state[2*((i+1)%self.N):2*((i+1)%self.N)]
                windings += abs(np.vdot(psi1, psi2))**2
            
            Q_squared.append(windings)
        
        chi_top = np.var(Q_squared) / (2*np.pi) if len(Q_squared) > 1 else 0.0
        return chi_top

def ncft_hft_boundary_test():
    print("NCFT-HFT PATH INTEGRAL BOUNDARY TEST v2 - FIXED")
    print("Non-perturbative physics | Safe numerics\n")
    
    scales = {"DYAD": 2, "GROUP": 8, "SPECIES": 24}
    
    for name, N in scales.items():
        path_int = NCFTPathIntegral(N)
        
        # Safe path ensemble
        path_ensemble = []
        for _ in range(16):  # Reduced for stability
            path = np.random.uniform(-1,1,(N*2)) + 1j*np.random.uniform(-1,1,(N*2))
            path_ensemble.append(path / np.linalg.norm(path))
        
        print(f"{name:7s} (N={N}):", end="")
        
        # Path integral dominance
        weights = path_int.path_weight(path_ensemble)
        S_typical = np.mean([path_int.instanton_action(p) for p in path_ensemble])
        print(f" S={S_typical:.2f}", end="")
        
        # Tunneling
        Gamma = path_int.wkb_tunneling_amplitude([path_ensemble[0], path_ensemble[-1]])
        print(f" Γ={Gamma:.2e}", end="")
        
        # Vacuum persistence
        R = path_int.vacuum_persistence()
        print(f" R={R:.3f}", end="")
        
        # Wilson loop
        W_violation = path_int.wilson_loop(path_ensemble)
        print(f" W={W_violation:.3f}", end="")
        
        # Topology
        chi_top = path_int.topological_susceptibility()
        print(f" χ={chi_top:.3f}")
        
        stable = R > 0.1 and W_violation < 0.5
        print(f"        {'✅ STABLE' if stable else '⚠️ BOUNDARY'}")

ncft_hft_boundary_test()
