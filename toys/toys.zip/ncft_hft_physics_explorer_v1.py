import numpy as np
from scipy.linalg import expm

def project_to_unit_disk(psi):
    norm = np.linalg.norm(psi)
    return psi / norm if norm > 0 else psi

def ncft_hft_physics_explorer():
    print("NCFT-HFT PHYSICS EXPLORER - Uncontrolled Dynamics")
    print("N-scales | Random coupling | Full chaos\n")
    
    scales = [
        ("DYAD", 2),   # Intimate (2 fields)
        ("GROUP", 7),  # Social (7 fields)  
        ("TRIBE", 25), # Community (25 fields)
        ("SPECIES", 50) # Global (50 fields)
    ]
    
    for name, N in scales:
        dim = 2 * N
        state_vec = np.zeros(dim, dtype=complex)
        
        # RANDOM physics initialization (no hierarchy bias)
        np.random.seed(42 + N)  # Reproducible chaos
        for i in range(N):
            angle = np.random.uniform(0, 2*np.pi)
            state_vec[2*i:2*i+2] = [np.cos(angle), np.sin(angle)]
        
        # FULLY CONNECTED CHAOS Hamiltonian (no axioms enforced)
        H = np.zeros((dim,dim), dtype=complex)
        for i in range(N):
            for j in range(i+1, N):
                # Random coupling strength 0.01-0.2
                coupling_strength = np.random.uniform(0.01, 0.2)
                coupling = coupling_strength * np.array([[0,0],[1j,0]])
                H[2*i:2*i+2, 2*j:2*j+2] = coupling
                H[2*j:2*j+2, 2*i:2*i+2] = coupling.conj().T
        
        def coherence_stats(state):
            coherences = []
            self_norms = []
            for i in range(N):
                self_norm = np.abs(np.vdot(state[2*i:2*i+2], state[2*i:2*i+2]))**2
                self_norms.append(self_norm)
                for j in range(i+1, N):
                    Cij = np.abs(np.vdot(state[2*i:2*i+2], state[2*j:2*j+2]))**2
                    coherences.append(Cij)
            return np.mean(coherences), np.std(coherences), np.mean(self_norms)
        
        print(f"{name:6s} (N={N}):", end=" ")
        
        # Evolve through chaos timescales
        for t, label in [(0.1, "fast"), (1.0, "mid"), (5.0, "slow")]:
            U = expm(-1j * H * t)
            state_t = U @ state_vec
            
            # NO PROJECTION - pure physics
            mean_C, std_C, self_norm = coherence_stats(state_t)
            
            status = "✓" if 0.9 < self_norm < 1.1 else "✗"
            print(f"{label:4s}:C={mean_C:.3f}σ={std_C:.3f}N={self_norm:.3f}{status}", end=" ")
        print()  # New line
        
        # CRASH TEST: Does it explode?
        U_long = expm(-1j * H * 20.0)
        state_long = U_long @ state_vec
        final_norm = np.linalg.norm(state_long)
        print(f"                LONG(t=20): norm={final_norm:.3f} {'STABLE' if abs(final_norm-1)<0.5 else 'EXPLODED'}")

ncft_hft_physics_explorer()
