#!/usr/bin/env python3
# =============================================================================
# NCFT Axiom Compliance Harness (ACH) v1.0
# -----------------------------------------------------------------------------
# Goal: ONE canonical place to compute couplings + enforce/report axiom checks.
# Use this as the importable foundation for every other toy.
#
# This harness explicitly distinguishes:
#   - Coupling C_ij (bounded, axiom-governed)
#   - Unbounded metrics (GAIN / SCORE) that MUST NOT be called C or "fidelity"
#
# Run:
#   python ncft_axiom_compliance_harness.py --N 12 --T 10 --dt 0.1 --mode static
#   python ncft_axiom_compliance_harness.py --N 7 --T 200 --dt 0.05 --mode random_unitary
#
# Notes:
# - Default self-coupling convention is ZERO (C_ii=0) because Axiom 1 uses exclusion.
#   If you want C_ii=1 as a separate "self-similarity" metric, flip --self_rule one,
#   but then that is a convention, not derived from exclusion gating.
# =============================================================================

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Any
import argparse
import json
import math
import numpy as np


# =============================================================================
# DATA MODEL
# =============================================================================

@dataclass
class Field:
    id: str
    frequency: float = 1.0
    active: bool = True
    state: Optional[np.ndarray] = None  # complex vector

    def __post_init__(self):
        if self.state is None:
            self.state = np.array([1.0 + 0.0j], dtype=np.complex128)
        self.state = np.asarray(self.state, dtype=np.complex128)


# =============================================================================
# CORE NCFT METRICS (CANONICAL)
# =============================================================================

@dataclass
class CanonicalConfig:
    # Core conventions
    enforce_state_norm: bool = True        # per-field ||psi|| = 1
    enforce_global_norm: bool = False      # global ||Psi|| = 1 (optional)
    exclusion_by_id: bool = True           # gate if same id
    require_active: bool = True            # gate if either inactive

    # Self coupling convention for reporting matrix diagonal
    #   "zero": C_ii = 0
    #   "one" : C_ii = 1
    self_rule: str = "zero"

    # Axiom thresholds
    freq_sigma_max: float = 0.1            # Axiom 3
    coupling_eps: float = 1e-12            # numeric tolerance


def normalize_state(psi: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(psi)
    if n <= 0:
        return psi
    return psi / n


def global_normalize(fields: List[Field]) -> None:
    # Concatenate and normalize global vector, then split back
    sizes = [len(f.state) for f in fields]
    psi = np.concatenate([f.state for f in fields]).astype(np.complex128)
    n = np.linalg.norm(psi)
    if n <= 0:
        return
    psi = psi / n
    offset = 0
    for f, sz in zip(fields, sizes):
        f.state = psi[offset:offset+sz].copy()
        offset += sz


def universal_exclusion(f1: Field, f2: Field, cfg: CanonicalConfig) -> bool:
    # Interaction possible iff ids differ AND both active (if required)
    if cfg.exclusion_by_id and (f1.id == f2.id):
        return False
    if cfg.require_active and ((not f1.active) or (not f2.active)):
        return False
    return True


def coupling_C(f1: Field, f2: Field, cfg: CanonicalConfig) -> float:
    """
    Canonical bounded coupling:
        C(f1,f2) = |<psi1|psi2>|^2, with state vectors normalized.
    """
    # Self convention (diagonal) handled outside to keep definition strict.
    if not universal_exclusion(f1, f2, cfg):
        return 0.0

    # Inner product; for vectors, np.vdot does conjugate(psi1) dot psi2
    ip = np.vdot(f1.state, f2.state)
    return float(np.abs(ip) ** 2)


def compute_C_matrix(fields: List[Field], cfg: CanonicalConfig) -> np.ndarray:
    N = len(fields)
    C = np.zeros((N, N), dtype=np.float64)
    for i in range(N):
        for j in range(N):
            if i == j:
                C[i, j] = 1.0 if cfg.self_rule == "one" else 0.0
            else:
                C[i, j] = coupling_C(fields[i], fields[j], cfg)
    return C


def sum_pairwise_i_lt_j(C: np.ndarray) -> float:
    # assumes C is symmetric-ish; sums strictly i<j
    n = C.shape[0]
    total = 0.0
    for i in range(n):
        for j in range(i+1, n):
            total += float(C[i, j])
    return total


# =============================================================================
# DYNAMICS MODES (OPTIONAL) - strictly for exercise, not "physics claims"
# =============================================================================

def random_unitary_step(state: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """
    Applies a random 2x2 unitary if dim==2, else applies a random phase per component.
    Keeps norm invariant (up to numeric drift) if followed by normalize_state.
    """
    d = len(state)
    if d == 2:
        # Haar-ish via QR of random complex matrix
        Z = (rng.normal(size=(2, 2)) + 1j * rng.normal(size=(2, 2))).astype(np.complex128)
        Q, R = np.linalg.qr(Z)
        # Fix determinant phase
        diag = np.diag(R)
        phase = diag / np.abs(diag)
        U = Q @ np.diag(phase.conj())
        return U @ state
    else:
        phases = np.exp(1j * rng.uniform(0, 2*np.pi, size=d))
        return phases * state


def noisy_open_step(state: np.ndarray, rng: np.random.Generator, noise: float) -> np.ndarray:
    """
    Adds complex Gaussian noise (open-system style) then renormalize.
    """
    eps = (rng.normal(size=state.shape) + 1j * rng.normal(size=state.shape)).astype(np.complex128)
    return state + noise * eps


# =============================================================================
# AXIOM CHECKS + REPORTING
# =============================================================================

@dataclass
class StepReport:
    t: float
    freq_sigma: float
    global_norm: Optional[float]
    per_field_norms: List[float]
    C_min: float
    C_mean: float
    C_max: float
    C_sigma: float
    total_pairwise: float
    total_pairwise_bound: float
    violations: Dict[str, Any]


def check_axioms(fields: List[Field], cfg: CanonicalConfig) -> Tuple[np.ndarray, StepReport]:
    # Enforce normalization (if desired)
    if cfg.enforce_state_norm:
        for f in fields:
            f.state = normalize_state(f.state)

    if cfg.enforce_global_norm:
        global_normalize(fields)

    # Compute norms
    per_norms = [float(np.linalg.norm(f.state)) for f in fields]
    g_norm = None
    if cfg.enforce_global_norm:
        # global norm of concatenated vector
        psi = np.concatenate([f.state for f in fields])
        g_norm = float(np.linalg.norm(psi))

    # Compute C
    C = compute_C_matrix(fields, cfg)

    # Statistics excluding diagonal for min/max unless you want include it:
    N = len(fields)
    off_diag = []
    for i in range(N):
        for j in range(N):
            if i != j:
                off_diag.append(float(C[i, j]))
    off_diag_arr = np.array(off_diag, dtype=np.float64) if off_diag else np.array([0.0], dtype=np.float64)

    C_min = float(np.min(off_diag_arr))
    C_mean = float(np.mean(off_diag_arr))
    C_max = float(np.max(off_diag_arr))
    C_sig = float(np.std(off_diag_arr))

    total_pairwise = sum_pairwise_i_lt_j(C)
    total_bound = N * (N - 1) / 2.0  # maximum if all off-diagonal C_ij=1

    # Frequency coherence among active fields
    active_freqs = [f.frequency for f in fields if f.active]
    freq_sigma = float(np.std(active_freqs)) if active_freqs else 0.0

    # Violations
    v: Dict[str, Any] = {}

    # Axiom 2 bounds for off-diagonal couplings (strictly gated)
    # Allow small epsilon; record any indices that violate.
    bad_bounds = []
    for i in range(N):
        for j in range(N):
            if i == j:
                continue
            val = float(C[i, j])
            if val < -cfg.coupling_eps or val > 1.0 + cfg.coupling_eps:
                bad_bounds.append({"i": i, "j": j, "C": val})
    if bad_bounds:
        v["axiom2_bounds"] = {
            "count": len(bad_bounds),
            "examples": bad_bounds[:10],
            "note": "Off-diagonal C_ij must be in [0,1]. If you intended an unbounded metric, DO NOT call it C."
        }

    # Axiom 3 frequency coherence
    if freq_sigma >= cfg.freq_sigma_max + 1e-15:
        v["axiom3_frequency"] = {
            "sigma": freq_sigma,
            "threshold": cfg.freq_sigma_max,
            "active_count": len(active_freqs),
        }

    # Axiom 4 pairwise summation bound
    if total_pairwise > total_bound + cfg.coupling_eps:
        v["axiom4_pairwise_sum_bound"] = {
            "total_pairwise": total_pairwise,
            "bound": total_bound
        }

    # Symmetry check (numerical)
    sym_err = float(np.max(np.abs(C - C.T)))
    if sym_err > 1e-10:
        v["symmetry"] = {"max_abs(C-C^T)": sym_err}

    # Diagonal convention check
    diag = np.diag(C)
    expected_diag = 1.0 if cfg.self_rule == "one" else 0.0
    diag_err = float(np.max(np.abs(diag - expected_diag)))
    if diag_err > 1e-12:
        v["diagonal"] = {"expected": expected_diag, "max_abs_error": diag_err}

    # Norm checks
    if cfg.enforce_state_norm:
        norm_err = float(np.max(np.abs(np.array(per_norms) - 1.0)))
        if norm_err > 1e-10:
            v["per_field_norm"] = {"max_abs_error": norm_err}

    if cfg.enforce_global_norm and g_norm is not None:
        if abs(g_norm - 1.0) > 1e-10:
            v["global_norm"] = {"global_norm": g_norm}

    # Return report for caller to fill t
    rep = StepReport(
        t=0.0,
        freq_sigma=freq_sigma,
        global_norm=g_norm,
        per_field_norms=per_norms,
        C_min=C_min,
        C_mean=C_mean,
        C_max=C_max,
        C_sigma=C_sig,
        total_pairwise=total_pairwise,
        total_pairwise_bound=total_bound,
        violations=v
    )
    return C, rep


# =============================================================================
# HARNESS DRIVER
# =============================================================================

def build_fields(N: int, dim: int, rng: np.random.Generator, freq_mu: float, freq_sigma: float) -> List[Field]:
    fields: List[Field] = []
    for i in range(N):
        # Random complex state
        real = rng.normal(size=dim)
        imag = rng.normal(size=dim)
        psi = (real + 1j * imag).astype(np.complex128)
        # Give unique ids by default
        fid = f"f{i}"
        f = Field(id=fid, frequency=float(rng.normal(loc=freq_mu, scale=freq_sigma)), active=True, state=psi)
        fields.append(f)
    return fields


def run_harness(
    N: int,
    dim: int,
    T: int,
    dt: float,
    mode: str,
    cfg: CanonicalConfig,
    seed: int,
    noise: float,
    quiet: bool,
) -> Dict[str, Any]:
    rng = np.random.default_rng(seed)
    fields = build_fields(N, dim, rng, freq_mu=1.0, freq_sigma=0.02)

    # Enforce initial normalization (optional)
    if cfg.enforce_state_norm:
        for f in fields:
            f.state = normalize_state(f.state)
    if cfg.enforce_global_norm:
        global_normalize(fields)

    all_steps: List[Dict[str, Any]] = []
    any_violations = False

    for k in range(T + 1):
        t = k * dt

        # Evaluate
        C, rep = check_axioms(fields, cfg)
        rep.t = t

        step_payload = {
            "t": rep.t,
            "freq_sigma": rep.freq_sigma,
            "global_norm": rep.global_norm,
            "per_field_norms": rep.per_field_norms,
            "C_summary": {
                "min_offdiag": rep.C_min,
                "mean_offdiag": rep.C_mean,
                "max_offdiag": rep.C_max,
                "sigma_offdiag": rep.C_sigma,
            },
            "pairwise_sum": {
                "total_i_lt_j": rep.total_pairwise,
                "bound": rep.total_pairwise_bound,
            },
            "violations": rep.violations,
        }
        all_steps.append(step_payload)

        if rep.violations:
            any_violations = True

        # Print compact line
        if not quiet:
            status = "OK" if not rep.violations else f"VIOL({','.join(rep.violations.keys())})"
            print(
                f"t={t:8.3f} | "
                f"⟨C⟩={rep.C_mean:8.5f} "
                f"Cmax={rep.C_max:8.5f} "
                f"σC={rep.C_sigma:8.5f} "
                f"σf={rep.freq_sigma:8.5f} "
                f"Σ={rep.total_pairwise:10.4f}/{rep.total_pairwise_bound:10.4f} | "
                f"{status}"
            )

        # Step dynamics
        if k == T:
            break

        if mode == "static":
            pass
        elif mode == "random_unitary":
            for f in fields:
                f.state = random_unitary_step(f.state, rng)
        elif mode == "open_noisy":
            for f in fields:
                f.state = noisy_open_step(f.state, rng, noise=noise)
        elif mode == "random_unitary_plus_noise":
            for f in fields:
                f.state = random_unitary_step(f.state, rng)
                f.state = noisy_open_step(f.state, rng, noise=noise)
        else:
            raise ValueError(f"Unknown mode: {mode}")

    # Final rollup
    final = all_steps[-1]
    rollup = {
        "harness": "NCFT Axiom Compliance Harness (ACH)",
        "version": "1.0",
        "config": {
            "N": N,
            "dim": dim,
            "T_steps": T,
            "dt": dt,
            "mode": mode,
            "seed": seed,
            "noise": noise,
            "canonical": cfg.__dict__,
        },
        "final": final,
        "any_violations": any_violations,
        "violation_types": sorted({k for s in all_steps for k in s["violations"].keys()}),
        "steps": all_steps,  # keep for post-analysis; can be large
        "notes": [
            "Only the metric named C is treated as axiomatic coupling and must be bounded in [0,1] off-diagonal.",
            "If you compute amplification/gain metrics, store them separately and never label them as C or 'fidelity'.",
        ],
    }
    return rollup


# =============================================================================
# CLI
# =============================================================================

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="NCFT Axiom Compliance Harness (ACH) v1.0")
    p.add_argument("--N", type=int, default=12, help="Number of fields")
    p.add_argument("--dim", type=int, default=1, help="State vector dimension per field (1 or 2 recommended)")
    p.add_argument("--T", type=int, default=50, help="Number of steps")
    p.add_argument("--dt", type=float, default=0.1, help="Timestep size")
    p.add_argument("--mode", type=str, default="static",
                   choices=["static", "random_unitary", "open_noisy", "random_unitary_plus_noise"],
                   help="Dynamics mode")
    p.add_argument("--seed", type=int, default=123, help="RNG seed")

    # Canonical config switches
    p.add_argument("--no_state_norm", action="store_true", help="Disable per-field normalization enforcement")
    p.add_argument("--global_norm", action="store_true", help="Enable global normalization (concatenated)")
    p.add_argument("--no_exclusion_by_id", action="store_true", help="Disable exclusion-by-id gating")
    p.add_argument("--no_require_active", action="store_true", help="Disable active gating")
    p.add_argument("--self_rule", type=str, default="zero", choices=["zero", "one"],
                   help="Diagonal convention for C_ii")

    p.add_argument("--freq_sigma_max", type=float, default=0.1, help="Axiom 3 threshold on σ(f_active)")
    p.add_argument("--eps", type=float, default=1e-12, help="Numeric tolerance epsilon for coupling bounds")

    # Noise
    p.add_argument("--noise", type=float, default=0.01, help="Noise amplitude for open_noisy modes")

    # Output
    p.add_argument("--quiet", action="store_true", help="Suppress per-step lines")
    p.add_argument("--out", type=str, default="", help="Write JSON report to this file (optional)")
    p.add_argument("--no_steps", action="store_true", help="Do not include full per-step data in JSON (smaller)")
    return p.parse_args()


def main() -> None:
    args = parse_args()

    cfg = CanonicalConfig(
        enforce_state_norm=(not args.no_state_norm),
        enforce_global_norm=args.global_norm,
        exclusion_by_id=(not args.no_exclusion_by_id),
        require_active=(not args.no_require_active),
        self_rule=args.self_rule,
        freq_sigma_max=args.freq_sigma_max,
        coupling_eps=args.eps,
    )

    report = run_harness(
        N=args.N,
        dim=args.dim,
        T=args.T,
        dt=args.dt,
        mode=args.mode,
        cfg=cfg,
        seed=args.seed,
        noise=args.noise,
        quiet=args.quiet,
    )

    # Optionally shrink output
    if args.no_steps:
        report = dict(report)
        report.pop("steps", None)

    # Pretty summary
    final = report["final"]
    print("\n" + "=" * 88)
    print("ACH FINAL SUMMARY")
    print("=" * 88)
    print(f"N={report['config']['N']} dim={report['config']['dim']} mode={report['config']['mode']} steps={report['config']['T_steps']}")
    print(f"Any violations: {report['any_violations']}")
    if report["violation_types"]:
        print(f"Violation types: {', '.join(report['violation_types'])}")
    else:
        print("Violation types: (none)")
    print("Final C summary:", final["C_summary"])
    print("Final pairwise sum:", final["pairwise_sum"])
    print("=" * 88)

    # Write JSON
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        print(f"Wrote JSON report to: {args.out}")


if __name__ == "__main__":
    main()
