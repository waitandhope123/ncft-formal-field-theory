import numpy as np
from scipy.integrate import dblquad
from scipy.linalg import expm, eigh
from scipy.special import gamma
import warnings
warnings.filterwarnings("ignore")

class NCFTPathIntegral:
    def __init__(self, N):
        self.N = N
        self.dim = 2 * N
        self.path_history = []
        
    def instanton_action(self, field_config):
        """S[φ] = ∫ L(φ,∂φ) - Classical action for instanton"""
        # Non-local consciousness action
        phi_norms = [np.linalg.norm(field_config[2*i:2*i+2]) for i in range(self.N)]
        coherence = np.mean([abs(np.vdot(field_config[2*i:2*i+2], field_config[2*j:2*j+2]))**2 
                           for i in range(self.N) for j in range(i+1,self.N)])
        
        # Beta function suppression + topological term
        S_classical = 2*np.pi * (1/coherence + 0.1*np.log(np.mean(phi_norms)))
        return S_classical
    
    def path_weight(self, path_ensemble):
        """e^{-S[path]} path weight"""
        actions = np.array([self.instanton_action(path) for path in path_ensemble])
        return np.exp(-actions)
    
    def wkb_tunneling_amplitude(self, vacua_pair):
        """WKB semiclassical tunneling Γ ~ e^{-B/ℏ}"""
        vac1, vac2 = vacua_pair
        barrier_height = np.abs(self.instanton_action(vac1) - self.instanton_action(vac2))
        B = 2 * np.pi * barrier_height  # Bounce action
        return np.exp(-B)
    
    def vacuum_persistence(self, N_vacua=8):
        """|⟨0_out|0_in⟩|² - Vacuum stability under dynamics"""
        vacua = []
        for i in range(N_vacua):
            vacuum = np.zeros(self.dim, dtype=complex)
            for j in range(self.N):
                theta = (j + i*0.1) * np.pi / self.N
                vacuum[2*j:2*j+2] = [np.cos(theta), np.sin(theta)]
            vacua.append(vacuum / np.linalg.norm(vacuum))
        
        # Path integral over vacuum transitions
        amplitudes = np.array([[self.wkb_tunneling_amplitude([vacua[i], vacua[j]]) 
                              for j in range(N_vacua)] for i in range(N_vacua)])
        
        persistence = np.abs(np.sum(amplitudes * amplitudes.conj()))**2 / N_vacua**2
        return persistence
    
    def wilson_loop(self, field_loop):
        """Non-trivial topology test - Wilson loop in consciousness space"""
        # Parallel transport around closed field loop
        phases = []
        for i in range(len(field_loop)-1):
            psi1, psi2 = field_loop[i], field_loop[i+1]
            phase_shift = np.angle(np.vdot(psi1, psi2))
            phases.append(phase_shift)
        total_phase = np.sum(phases) % (2*np.pi)
        wilson = np.exp(1j * total_phase)
        return np.abs(wilson - 1.0)  # Area law violation test
    
    def topological_susceptibility(self):
        """χ_top = ⟨Q²⟩/V - Theta vacuum structure"""
        theta_configs = np.linspace(0, 2*np.pi, 16)
        Q_squared = []
        
        for theta in theta_configs:
            state = np.zeros(self.dim, dtype=complex)
            for i in range(self.N):
                phase = i * 0.2 + theta * 0.1
                state[2*i:2*i+2] = [np.cos(phase), np.sin(phase)]
            
            # Compute winding number proxy
            windings = sum([np.abs(np.vdot(state[2*i:2*i+2], 
                                         state[2*((i+1)%self.N):2*((i+1)%self.N)]))**2 
                          for i in range(self.N)])
            Q_squared.append(windings)
        
        chi_top = np.var(Q_squared) / (2*np.pi)
        return chi_top

def ncft_hft_boundary_test():
    print("NCFT-HFT PATH INTEGRAL BOUNDARY TEST")
    print("Non-perturbative | WKB | Wilson loops | Theta vacua\n")
    
    scales = {"DYAD": 2, "GROUP": 8, "SPECIES": 24}
    
    for name, N in scales.items():
        path_int = NCFTPathIntegral(N)
        
        # Generate path ensemble (Monte Carlo paths)
        path_ensemble = []
        for _ in range(32):
            path = np.random.uniform(-1,1,(N*2)) + 1j*np.random.uniform(-1,1,(N*2))
            path = path.reshape(N,2)
            for i in range(N):
                path[i] = path[i] / np.linalg.norm(path[i])
            path_ensemble.append(path.flatten())
        
        print(f"{name:7s} (N={N}):", end="")
        
        # 1. PATH INTEGRAL DOMINANCE
        weights = path_int.path_weight(path_ensemble)
        S_typical = np.mean([path_int.instanton_action(p) for p in path_ensemble])
        print(f" S={S_typical:.3f}", end="")
        
        # 2. TUNNELING AMPLITUDES
        vacua_pair = [path_ensemble[0], path_ensemble[-1]]
        Gamma = path_int.wkb_tunneling_amplitude(vacua_pair)
        print(f" Γ={Gamma:.2e}", end="")
        
        # 3. VACUUM PERSISTENCE
        R = path_int.vacuum_persistence()
        print(f" R={R:.3f}", end="")
        
        # 4. WILSON LOOP (topology)
        loop = path_ensemble[:8]  # Closed loop
        W_violation = path_int.wilson_loop(loop)
        print(f" W={W_violation:.3f}", end="")
        
        # 5. TOPOLOGICAL SUSCEPTIBILITY
        chi_top = path_int.topological_susceptibility()
        print(f" χ={chi_top:.3f}")
        
        # Boundary condition: Stable physics?
        stable = R > 0.5 and W_violation < 0.1
        status = "✅" if stable else "⚠️"
        print(f"        {status} {'STABLE' if stable else 'BOUNDARY'}")

ncft_hft_boundary_test()
