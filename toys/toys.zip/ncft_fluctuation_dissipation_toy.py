#!/usr/bin/env python3
"""
ncft_fluctuation_dissipation_toy.py

NCFT Fluctuation–Dissipation / Noise–Response Duality Toy

What it does
------------
1) Runs an OPEN/NOISY simulation (no external drive) and measures:
   - Time series of an observable y(t) (default: mean_offdiag(C))
   - Power spectrum S_y(omega) via FFT

2) Runs a DRIVEN simulation (sinusoidal drive on a target species) and measures:
   - Gain/phase => |chi_y(omega)| and arg chi_y(omega)

3) Reports an FDT-like consistency score at the drive frequency:
   - Compare S_y(omega) to |chi_y(omega)|^2 scaled by an effective temperature-like factor.
   - We estimate Teff from low-frequency band and report residuals.

This is not claiming standard FDT is "true"—it tests whether NCFT exhibits a coherent
noise-response duality that *behaves* like FDT.

Usage
-----
python ncft_fluctuation_dissipation_toy.py --N 25 --dim 2 --T 400 --dt 0.05 --noise 0.05 --omega 1.0 --eps 1e-3

Recommended:
- Increase T to get cleaner spectra (e.g. T=400 or 800)
- Keep eps small for linear response (1e-4 to 1e-3)
"""

from __future__ import annotations
import argparse
import math
import numpy as np
from dataclasses import dataclass
from typing import Dict, Tuple, List


def symmetrize_zero_diag(M: np.ndarray) -> np.ndarray:
    M = 0.5*(M + M.T)
    np.fill_diagonal(M, 0.0)
    return M


def clamp01(M: np.ndarray) -> np.ndarray:
    return np.clip(M, 0.0, 1.0)


def offdiag_mean(C: np.ndarray) -> float:
    N = C.shape[0]
    mask = ~np.eye(N, dtype=bool)
    return float(np.mean(C[mask]))


def init_couplings(N: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    C = rng.random((N, N))
    return clamp01(symmetrize_zero_diag(C))


def init_phases(N: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed + 999)
    return rng.normal(0.0, 1.0, size=(N,))


@dataclass
class Params:
    N: int
    T: float
    dt: float
    steps: int
    seed: int
    noise: float
    target: int
    eps: float
    omega: float
    burn: float
    sample_every: int


def evolve_step(C: np.ndarray, phi: np.ndarray, t: float, p: Params, driven: bool) -> Tuple[np.ndarray, np.ndarray, float]:
    N = p.N

    # phase dynamics
    dphi = np.zeros(N)
    for i in range(N):
        s = 0.0
        for j in range(N):
            if i == j:
                continue
            s += C[i, j] * math.sin(phi[j] - phi[i])
        dphi[i] = 0.05 * s

    # open-noisy bath
    if p.noise > 0:
        dphi += np.random.normal(0.0, p.noise, size=N)

    phi = phi + p.dt * dphi

    # relax couplings toward coherence
    coh = np.cos(phi[:, None] - phi[None, :])
    coh01 = 0.5*(coh + 1.0)
    alpha = 0.15
    C_prop = (1.0 - alpha)*C + alpha*coh01

    # external source (sinusoidal) if driven
    u = 0.0
    if driven and abs(p.eps) > 0:
        u = math.sin(p.omega * t)
        k = p.target
        C_prop[k, :] += p.eps * u
        C_prop[:, k] += p.eps * u

    C_prop = clamp01(symmetrize_zero_diag(C_prop))
    return C_prop, phi, u


def run_timeseries(p: Params, driven: bool) -> Dict[str, np.ndarray]:
    np.random.seed(p.seed + (123 if driven else 0))
    C = init_couplings(p.N, p.seed + (7 if driven else 0))
    phi = init_phases(p.N, p.seed + (11 if driven else 0))

    burn_steps = int(round(p.burn / p.dt))

    y_list: List[float] = []
    u_list: List[float] = []
    t_list: List[float] = []

    for n in range(p.steps + 1):
        t = n * p.dt
        C, phi, u = evolve_step(C, phi, t, p, driven=driven)

        if n >= burn_steps and (n - burn_steps) % p.sample_every == 0:
            y_list.append(offdiag_mean(C))
            u_list.append(u)
            t_list.append(t)

    return {
        "t": np.array(t_list),
        "y": np.array(y_list),
        "u": np.array(u_list),
    }


def fft_psd(y: np.ndarray, dt: float) -> Tuple[np.ndarray, np.ndarray]:
    """
    One-sided PSD-ish estimate using FFT magnitude^2.
    Returns freqs (rad/s) and S(omega) up to Nyquist.
    """
    y0 = y - np.mean(y)
    n = len(y0)
    Y = np.fft.rfft(y0)
    # power ~ |Y|^2 / n
    P = (np.abs(Y)**2) / max(n, 1)
    f_hz = np.fft.rfftfreq(n, d=dt)
    omega = 2*np.pi*f_hz
    return omega, P


def gain_phase_from_projection(t: np.ndarray, y: np.ndarray, u: np.ndarray, omega: float) -> Dict[str, float]:
    s = np.sin(omega*t)
    c = np.cos(omega*t)
    A = np.column_stack([s, c, np.ones_like(t)])

    coef_y, *_ = np.linalg.lstsq(A, y, rcond=None)
    ay, by, y0 = coef_y
    amp_y = float(np.sqrt(ay*ay + by*by))
    phase_y = float(np.arctan2(by, ay))

    coef_u, *_ = np.linalg.lstsq(A, u, rcond=None)
    au, bu, _ = coef_u
    amp_u = float(np.sqrt(au*au + bu*bu))
    phase_u = float(np.arctan2(bu, au))

    gain = amp_y / (amp_u if amp_u > 1e-12 else 1e-12)
    phase = phase_y - phase_u
    phase = float((phase + np.pi) % (2*np.pi) - np.pi)

    return {
        "amp_y": amp_y,
        "amp_u": amp_u,
        "gain": gain,
        "phase_rad": phase,
        "phase_deg": float(phase*180/np.pi),
        "offset": float(y0),
    }


def nearest_index(x: np.ndarray, x0: float) -> int:
    return int(np.argmin(np.abs(x - x0)))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--N", type=int, default=25)
    ap.add_argument("--T", type=float, default=400.0)
    ap.add_argument("--dt", type=float, default=0.05)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--noise", type=float, default=0.05)

    ap.add_argument("--target", type=int, default=0)
    ap.add_argument("--eps", type=float, default=1e-3)
    ap.add_argument("--omega", type=float, default=1.0)

    ap.add_argument("--burn", type=float, default=10.0)
    ap.add_argument("--sample_every", type=int, default=2)

    args = ap.parse_args()
    steps = int(round(args.T / args.dt))

    p = Params(
        N=args.N, T=args.T, dt=args.dt, steps=steps, seed=args.seed,
        noise=args.noise, target=args.target, eps=args.eps, omega=args.omega,
        burn=args.burn, sample_every=args.sample_every
    )

    print("\n" + "="*90)
    print("NCFT FLUCTUATION–DISSIPATION (NOISE–RESPONSE) TOY")
    print("="*90)
    print(f"N={p.N} noise={p.noise} omega={p.omega} eps={p.eps} T={p.T} dt={p.dt} "
          f"steps={p.steps} burn={p.burn} sample_every={p.sample_every}")

    # 1) Spontaneous fluctuations (undriven)
    und = run_timeseries(p, driven=False)
    dt_eff = p.dt * p.sample_every
    w, S = fft_psd(und["y"], dt_eff)

    # 2) Driven response
    drv = run_timeseries(p, driven=True)
    fr = gain_phase_from_projection(drv["t"], drv["y"], drv["u"], p.omega)
    chi_amp = fr["gain"]  # response amplitude of y per unit drive amplitude

    # compare at omega
    k = nearest_index(w, p.omega)
    S_w = float(S[k])
    w_k = float(w[k])

    # FDT-like check: S(omega) ~ Teff * |chi(omega)|^2
    # Estimate Teff from a low-frequency band (avoid DC and avoid high freq)
    band = (w > 0.2*p.omega) & (w < 0.6*p.omega)
    if np.sum(band) < 3:
        Teff = S_w / max(chi_amp*chi_amp, 1e-18)
    else:
        ratios = S[band] / np.maximum(chi_amp*chi_amp, 1e-18)
        Teff = float(np.median(ratios))

    pred = Teff * (chi_amp*chi_amp)
    rel_err = (S_w - pred) / (abs(pred) + 1e-18)

    print("\n" + "-"*90)
    print("FLUCTUATIONS (UND RIVEN)")
    print(f"PSD sample dt_eff={dt_eff}")
    print(f"Nearest omega bin: omega≈{w_k:.6f}  S(omega)={S_w:.6e}")

    print("\n" + "-"*90)
    print("RESPONSE (DRIVEN)")
    print(f"gain(|chi_y|)={chi_amp:.6e}  phase={fr['phase_deg']:.3f} deg  offset={fr['offset']:.6e}")

    print("\n" + "-"*90)
    print("FDT-LIKE CONSISTENCY")
    print(f"Estimated Teff={Teff:.6e}")
    print(f"Predicted S(omega)=Teff*|chi|^2 = {pred:.6e}")
    print(f"Relative error at omega: {rel_err:.6e}")

    score = float(np.exp(-abs(rel_err)))  # simple bounded score in (0,1]
    print(f"Consistency score exp(-|rel_err|) = {score:.6f}")

    print("\n" + "="*90)
    print("SUGGESTED SUMMARY LINE (COPY/PASTE)")
    print("="*90)
    print(
        "ncft_fluctuation_dissipation_toy.py\n"
        f"RESULT: Open-noisy fluctuations S(ω) measured and compared to driven linear response |χ(ω)|; "
        f"Teff-estimate={Teff:.3e}, rel_err@ω={rel_err:.3e}, consistency_score={score:.3f}\n"
        "STATUS: ⭐ Noise–response duality (FDT-style) tested for physical bath consistency"
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
