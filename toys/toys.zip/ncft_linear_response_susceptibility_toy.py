#!/usr/bin/env python3
"""
ncft_linear_response_susceptibility_toy.py

NCFT Linear Response / Susceptibility Toy (Kubo-style)

Goal
----
Apply a weak external "source" drive to one species (or a subset) and measure how the
NCFT coupling matrix responds. This yields an empirical susceptibility/response object
that behaves like a Green's function / propagator over your chosen embedding dimension.

What it outputs
---------------
- Baseline coupling stats (no drive)
- Driven coupling stats (with drive)
- Linear-response estimate: chi_ij = ( <C_ij>_drive - <C_ij>_base ) / eps
- Distance-binned response profiles if dim>0 embedding is enabled
- Reciprocity diagnostics:
    * chi symmetry score: ||chi - chi^T|| / ||chi||
    * sign / magnitude summaries
- Frequency response (optional sinusoidal drive): gain/phase for selected observables

Design philosophy
-----------------
This is deliberately "comprehensive":
- multiple drive modes: DC step, pulse, sinusoid
- multiple environments: unitary-ish, open_noisy
- multiple measurements: global mean, per-row influence, distance bins, spectral summaries

Usage examples
--------------
# Simple DC drive on species 0
python ncft_linear_response_susceptibility_toy.py --N 25 --dim 2 --T 50 --dt 0.05 --mode dc --target 0 --eps 1e-3

# Sinusoidal drive and estimate gain/phase in mean coupling response
python ncft_linear_response_susceptibility_toy.py --N 25 --dim 2 --T 200 --dt 0.05 --mode sinusoid --omega 1.0 --target 0 --eps 1e-3

# Open/noisy environment
python ncft_linear_response_susceptibility_toy.py --N 25 --dim 2 --T 200 --dt 0.05 --env open_noisy --noise 0.05 --mode sinusoid --omega 1.0 --target 0 --eps 1e-3
"""

from __future__ import annotations

import argparse
import math
import sys
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np


# -----------------------------
# Helpers / numerics
# -----------------------------

def set_seed(seed: int) -> None:
    np.random.seed(seed)


def symmetrize_zero_diag(M: np.ndarray) -> np.ndarray:
    M = 0.5 * (M + M.T)
    np.fill_diagonal(M, 0.0)
    return M


def clamp01(M: np.ndarray) -> np.ndarray:
    return np.clip(M, 0.0, 1.0)


def offdiag_stats(C: np.ndarray) -> Dict[str, float]:
    N = C.shape[0]
    mask = ~np.eye(N, dtype=bool)
    x = C[mask]
    return {
        "min_offdiag": float(np.min(x)),
        "mean_offdiag": float(np.mean(x)),
        "max_offdiag": float(np.max(x)),
        "sigma_offdiag": float(np.std(x)),
    }


def fro_norm(M: np.ndarray) -> float:
    return float(np.linalg.norm(M, ord="fro"))


def safe_div(a: float, b: float, eps: float = 1e-12) -> float:
    return a / (b if abs(b) > eps else (eps if b >= 0 else -eps))


def pairwise_sum_i_lt_j(C: np.ndarray) -> float:
    triu = np.triu(C, k=1)
    return float(np.sum(triu))


def bounded_pairwise_sum_bound(N: int) -> float:
    # Max sum if all off-diagonal entries are 1: N*(N-1)/2
    return float(N * (N - 1) / 2)


def spectral_summary(C: np.ndarray) -> Dict[str, float]:
    # symmetric => real eigenvalues
    w = np.linalg.eigvalsh(C)
    return {
        "eig_min": float(np.min(w)),
        "eig_max": float(np.max(w)),
        "eig_mean": float(np.mean(w)),
        "eig_std": float(np.std(w)),
    }


# -----------------------------
# Embedding / distances
# -----------------------------

def embed_positions(N: int, dim: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed + 12345)
    if dim <= 0:
        return np.zeros((N, 1), dtype=float)

    # Put points in [0,1)^dim
    return rng.random((N, dim), dtype=float)


def pairwise_distances(pos: np.ndarray) -> np.ndarray:
    # pos: (N,dim)
    diffs = pos[:, None, :] - pos[None, :, :]
    D = np.sqrt(np.sum(diffs * diffs, axis=-1))
    return D


def distance_bins(D: np.ndarray, nbins: int = 10) -> Tuple[np.ndarray, np.ndarray]:
    # return bin_edges, bin_centers
    # ignore diagonal
    N = D.shape[0]
    mask = ~np.eye(N, dtype=bool)
    dvals = D[mask]
    dmin, dmax = float(np.min(dvals)), float(np.max(dvals))
    if dmax <= dmin + 1e-12:
        edges = np.linspace(dmin, dmin + 1e-6, nbins + 1)
    else:
        edges = np.linspace(dmin, dmax, nbins + 1)
    centers = 0.5 * (edges[:-1] + edges[1:])
    return edges, centers


def binned_mean_response(chi: np.ndarray, D: np.ndarray, edges: np.ndarray) -> np.ndarray:
    N = chi.shape[0]
    out = np.zeros(len(edges) - 1, dtype=float)
    counts = np.zeros(len(edges) - 1, dtype=int)
    for i in range(N):
        for j in range(N):
            if i == j:
                continue
            d = D[i, j]
            k = int(np.searchsorted(edges, d, side="right") - 1)
            if 0 <= k < len(out):
                out[k] += chi[i, j]
                counts[k] += 1
    with np.errstate(divide="ignore", invalid="ignore"):
        out = np.where(counts > 0, out / counts, 0.0)
    return out


# -----------------------------
# NCFT-ish core dynamics (toy-level)
# -----------------------------

@dataclass
class Params:
    N: int
    dim: int
    T: float
    dt: float
    steps: int
    seed: int

    # environment
    env: str
    noise: float

    # drive
    mode: str
    target: int
    eps: float
    omega: float
    pulse_t0: float
    pulse_t1: float

    # measurement
    burn: float
    sample_every: int
    bins: int


def init_couplings(N: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    # Start with a symmetric random matrix in [0,1), zero diagonal.
    C = rng.random((N, N), dtype=float)
    C = symmetrize_zero_diag(C)
    return C


def init_phases(N: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed + 999)
    # internal "field" per species (phase-like)
    return rng.normal(0.0, 1.0, size=(N,))


def drive_signal(t: float, p: Params) -> float:
    if p.mode == "dc":
        return 1.0
    if p.mode == "pulse":
        return 1.0 if (p.pulse_t0 <= t <= p.pulse_t1) else 0.0
    if p.mode == "sinusoid":
        return math.sin(p.omega * t)
    raise ValueError(f"Unknown drive mode: {p.mode}")


def evolve_step(C: np.ndarray, phi: np.ndarray, t: float, p: Params,
                positions: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray]:
    """
    Toy evolution with an "axiom-friendly" projection:
    - update phi (internal states)
    - propose coupling update based on phase coherence + (optional) drive
    - enforce symmetry, zero diagonal, clamp [0,1]
    """
    N = p.N

    # internal dynamics: weakly coupled oscillators through current couplings
    # dphi_i = sum_j C_ij * sin(phi_j - phi_i) dt + noise
    dphi = np.zeros(N, dtype=float)
    for i in range(N):
        s = 0.0
        for j in range(N):
            if i == j:
                continue
            s += C[i, j] * math.sin(phi[j] - phi[i])
        dphi[i] = 0.05 * s

    if p.env == "open_noisy" and p.noise > 0:
        dphi += np.random.normal(0.0, p.noise, size=N)

    phi = phi + p.dt * dphi

    # Proposed coupling update: "coherence" term wants C_ij ~ cos(phi_i - phi_j) mapped to [0,1]
    # plus optional drive on the target species: add a small bias to edges incident to target.
    # This is purposely mild so linear-response holds for small eps.
    # coherence in [-1,1]
    coh = np.cos(phi[:, None] - phi[None, :])
    coh01 = 0.5 * (coh + 1.0)  # in [0,1]

    # Relax couplings towards coherence
    alpha = 0.15  # relaxation rate
    C_prop = (1.0 - alpha) * C + alpha * coh01

    # Apply external source
    s = drive_signal(t, p)
    if abs(p.eps) > 0:
        k = p.target
        # Bias couplings touching target by eps*s, then project.
        C_prop[k, :] = C_prop[k, :] + p.eps * s
        C_prop[:, k] = C_prop[:, k] + p.eps * s

    # Project / enforce axioms (toy-level)
    C_prop = symmetrize_zero_diag(C_prop)
    C_prop = clamp01(C_prop)

    return C_prop, phi


def run_simulation(p: Params, driven: bool) -> Dict[str, object]:
    C = init_couplings(p.N, p.seed + (123 if driven else 0))
    phi = init_phases(p.N, p.seed + (456 if driven else 0))

    pos = embed_positions(p.N, p.dim, p.seed)
    D = pairwise_distances(pos) if p.dim > 0 else None

    burn_steps = int(round(p.burn / p.dt))
    sample_idx = []

    C_accum = np.zeros_like(C)
    count = 0

    # Track observable time series for freq response (mean offdiag)
    obs_ts: List[float] = []
    t_ts: List[float] = []
    drive_ts: List[float] = []

    for n in range(p.steps + 1):
        t = n * p.dt

        # For baseline (undriven), temporarily set eps=0 by overriding p.eps via a local
        if not driven:
            eps_saved = p.eps
            p_local = p
            p_local = Params(**{**p.__dict__, "eps": 0.0})
            C, phi = evolve_step(C, phi, t, p_local, positions=pos)
        else:
            C, phi = evolve_step(C, phi, t, p, positions=pos)

        if n >= burn_steps and (n - burn_steps) % p.sample_every == 0:
            C_accum += C
            count += 1
            sample_idx.append(n)

        # time series sampling (same cadence as sample_every, but start immediately)
        if n % p.sample_every == 0:
            st = offdiag_stats(C)
            obs_ts.append(st["mean_offdiag"])
            t_ts.append(t)
            drive_ts.append(drive_signal(t, p) if driven else 0.0)

    C_mean = C_accum / max(count, 1)

    result: Dict[str, object] = {
        "C_mean": C_mean,
        "stats": offdiag_stats(C_mean),
        "pairwise_sum": {
            "total_i_lt_j": pairwise_sum_i_lt_j(C_mean),
            "bound": bounded_pairwise_sum_bound(p.N),
        },
        "spectral": spectral_summary(C_mean),
        "pos": pos,
        "D": D,
        "t_ts": np.array(t_ts),
        "obs_ts": np.array(obs_ts),
        "drive_ts": np.array(drive_ts),
        "count_samples": count,
    }
    return result


def estimate_gain_phase(t: np.ndarray, y: np.ndarray, u: np.ndarray, omega: float) -> Dict[str, float]:
    """
    Estimate gain/phase of y relative to u at frequency omega using least-squares projection onto sin/cos.
    Works best when u is sinusoid and enough cycles are present.
    """
    # Fit y(t) ~ a*sin(omega t) + b*cos(omega t) + c
    s = np.sin(omega * t)
    c = np.cos(omega * t)
    A = np.column_stack([s, c, np.ones_like(t)])
    coef, *_ = np.linalg.lstsq(A, y, rcond=None)
    a, b, c0 = coef

    amp_y = float(np.sqrt(a * a + b * b))
    phase_y = float(np.arctan2(b, a))  # because a*sin + b*cos = R*sin(omega t + phi), phi=atan2(b,a)

    # For u, fit similarly (to allow arbitrary amplitude)
    coef_u, *_ = np.linalg.lstsq(A, u, rcond=None)
    au, bu, _ = coef_u
    amp_u = float(np.sqrt(au * au + bu * bu))
    phase_u = float(np.arctan2(bu, au))

    gain = safe_div(amp_y, amp_u)
    phase = phase_y - phase_u
    # wrap to [-pi, pi]
    phase = float((phase + np.pi) % (2 * np.pi) - np.pi)

    return {
        "amp_y": amp_y,
        "amp_u": amp_u,
        "gain": gain,
        "phase_rad": phase,
        "phase_deg": float(phase * 180.0 / np.pi),
        "offset": float(c0),
    }


def print_header(title: str) -> None:
    print("\n" + "=" * 90)
    print(title)
    print("=" * 90)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--N", type=int, default=25)
    ap.add_argument("--dim", type=int, default=2)
    ap.add_argument("--T", type=float, default=200.0)
    ap.add_argument("--dt", type=float, default=0.05)
    ap.add_argument("--seed", type=int, default=7)

    ap.add_argument("--env", type=str, default="unitary", choices=["unitary", "open_noisy"])
    ap.add_argument("--noise", type=float, default=0.05)

    ap.add_argument("--mode", type=str, default="sinusoid", choices=["dc", "pulse", "sinusoid"])
    ap.add_argument("--target", type=int, default=0)
    ap.add_argument("--eps", type=float, default=1e-3)
    ap.add_argument("--omega", type=float, default=1.0)
    ap.add_argument("--pulse_t0", type=float, default=10.0)
    ap.add_argument("--pulse_t1", type=float, default=20.0)

    ap.add_argument("--burn", type=float, default=10.0)
    ap.add_argument("--sample_every", type=int, default=2)
    ap.add_argument("--bins", type=int, default=10)

    args = ap.parse_args()

    steps = int(round(args.T / args.dt))
    if args.target < 0 or args.target >= args.N:
        print(f"ERROR: --target must be in [0, N-1]. Got {args.target} for N={args.N}", file=sys.stderr)
        return 2

    p = Params(
        N=args.N,
        dim=args.dim,
        T=args.T,
        dt=args.dt,
        steps=steps,
        seed=args.seed,
        env=args.env,
        noise=args.noise,
        mode=args.mode,
        target=args.target,
        eps=args.eps,
        omega=args.omega,
        pulse_t0=args.pulse_t0,
        pulse_t1=args.pulse_t1,
        burn=args.burn,
        sample_every=args.sample_every,
        bins=args.bins,
    )

    print_header("NCFT LINEAR RESPONSE / SUSCEPTIBILITY TOY")
    print(f"N={p.N} dim={p.dim} env={p.env} mode={p.mode} target={p.target} eps={p.eps} "
          f"T={p.T} dt={p.dt} steps={p.steps} burn={p.burn} sample_every={p.sample_every}")

    base = run_simulation(p, driven=False)
    driv = run_simulation(p, driven=True)

    Cb: np.ndarray = base["C_mean"]  # type: ignore[assignment]
    Cd: np.ndarray = driv["C_mean"]  # type: ignore[assignment]

    chi = (Cd - Cb) / (p.eps if abs(p.eps) > 0 else 1.0)
    chi = symmetrize_zero_diag(chi)  # for clean reciprocity diagnostic

    # Diagnostics
    base_stats = base["stats"]  # type: ignore[assignment]
    driv_stats = driv["stats"]  # type: ignore[assignment]

    print_header("BASELINE (NO DRIVE) SUMMARY")
    print("Offdiag stats:", base_stats)
    print("Pairwise sum:", base["pairwise_sum"])   # type: ignore[arg-type]
    print("Spectral:", base["spectral"])           # type: ignore[arg-type]

    print_header("DRIVEN SUMMARY")
    print("Offdiag stats:", driv_stats)
    print("Pairwise sum:", driv["pairwise_sum"])   # type: ignore[arg-type]
    print("Spectral:", driv["spectral"])           # type: ignore[arg-type]

    print_header("LINEAR RESPONSE ESTIMATE (CHI)")
    chi_stats = offdiag_stats(chi)
    print("chi offdiag stats:", chi_stats)

    # Reciprocity (Onsager-ish) symmetry score
    asym = chi - chi.T
    sym_score = safe_div(fro_norm(asym), fro_norm(chi) + 1e-12)
    print(f"chi reciprocity symmetry score ||chi-chi^T||/||chi|| = {sym_score:.6e}")

    # "Influence vector": response of target to others and others to target (row/col)
    k = p.target
    infl_out = chi[k, :].copy()
    infl_in = chi[:, k].copy()
    infl_out[k] = 0.0
    infl_in[k] = 0.0

    # Rank top responders
    top = min(10, p.N - 1)
    idx_out = np.argsort(-np.abs(infl_out))[:top]
    idx_in = np.argsort(-np.abs(infl_in))[:top]

    print("\nTop |chi[target,j]| responders (outgoing influence):")
    for j in idx_out:
        print(f"  j={int(j):3d}  chi={float(chi[k,j]): .6e}")

    print("\nTop |chi[i,target]| responders (incoming sensitivity):")
    for i in idx_in:
        print(f"  i={int(i):3d}  chi={float(chi[i,k]): .6e}")

    # Distance-binned response if embedding exists
    if p.dim > 0:
        D = base["D"]  # type: ignore[assignment]
        assert D is not None
        edges, centers = distance_bins(D, nbins=p.bins)
        prof = binned_mean_response(chi, D, edges)

        print_header("DISTANCE-BINNED MEAN RESPONSE <chi_ij> vs distance")
        for c, v in zip(centers, prof):
            print(f"r~{float(c):.4f} : <chi>={float(v): .6e}")

    # Frequency response (only meaningful for sinusoid mode)
    if p.mode == "sinusoid":
        t = driv["t_ts"]  # type: ignore[assignment]
        y = driv["obs_ts"]  # type: ignore[assignment]
        u = driv["drive_ts"]  # type: ignore[assignment]

        # discard burn portion
        mask = t >= p.burn
        t2 = t[mask]
        y2 = y[mask]
        u2 = u[mask]

        fr = estimate_gain_phase(t2, y2, u2, p.omega)

        print_header("FREQUENCY RESPONSE (mean_offdiag vs drive)")
        print(f"omega={p.omega}")
        print(f"amp_y={fr['amp_y']:.6e}  amp_u={fr['amp_u']:.6e}")
        print(f"gain={fr['gain']:.6e}")
        print(f"phase={fr['phase_rad']:.6e} rad  ({fr['phase_deg']:.3f} deg)")
        print(f"offset={fr['offset']:.6e}")

    print_header("SUGGESTED SUMMARY LINE (COPY/PASTE)")
    # Compact, summary-friendly line
    print(
        f"ncft_linear_response_susceptibility_toy.py\n"
        f"RESULT: Linear response χ=(⟨C⟩drive-⟨C⟩base)/ε measured "
        f"(mode={p.mode}, target={p.target}, ε={p.eps}); "
        f"χ reciprocity score={sym_score:.2e}; "
        f"baseline ⟨C⟩={base_stats['mean_offdiag']:.4f} → driven ⟨C⟩={driv_stats['mean_offdiag']:.4f}\n"
        f"STATUS: ⭐ Effective propagator / susceptibility extracted (physics-observable layer)"
    )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
