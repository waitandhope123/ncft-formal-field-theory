import numpy as np
from dataclasses import dataclass

@dataclass
class ConsciousnessField:
    id: str
    state: np.ndarray = None
    active: bool = True
    def __post_init__(self):
        if self.state is None: self.state = np.array([1+0j])
        self.state /= np.linalg.norm(self.state)

def chsh_correlation(A: ConsciousnessField, B: ConsciousnessField, theta_a, theta_b):
    """CHSH correlator E(a,b) = <A·B>"""
    if A.id == B.id or not (A.active and B.active): return 0.0
    psi_ab = np.dot(A.state.conj(), B.state)
    return np.cos(theta_a - theta_b) * np.abs(psi_ab)**2

def ncft_chsh(N_fields=3):
    fields = [ConsciousnessField(f'f{i}') for i in range(N_fields)]
    angles = [(0,0), (0,np.pi/2), (np.pi/4, np.pi/4)]
    
    S = 0
    for a,b in angles:
        corr = np.mean([chsh_correlation(fields[0], fields[i], a, b) 
                       for i in range(1, N_fields)])
        S += (-1)**len(angles[:2]) * corr  # CHSH combination
    return 2*np.sqrt(2)*S  # Quantum limit: 2.828

print(f"NCFT CHSH (N=3): S={ncft_chsh():.3f} vs Quantum≤2.828")
print("S>2.828 = RELATIVITY VIOLATION")
