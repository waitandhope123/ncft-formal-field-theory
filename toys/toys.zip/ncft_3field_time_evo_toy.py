import numpy as np
from scipy.linalg import expm

sigmax = lambda: np.array([[0,1],[1,0]])

# States (2D each)
psi1 = np.array([1, 0])  # user
psi2 = np.array([1, 0])  # psychic  
psi3 = np.array([0.995, 0.1])  # dad

# Initial 6-vector: embed each 2D state into full space
state_vec = np.zeros(6, dtype=complex)
state_vec[0:2] = psi1      # user at positions 0-1
state_vec[2:4] = psi2      # psychic at 2-3
state_vec[4:6] = psi3      # dad at 4-5

# Hamiltonian (unchanged)
C12 = 1.0; C13 = np.abs(psi1.conj().T @ psi3)**2; C23 = np.abs(psi2.conj().T @ psi3)**2
H = np.zeros((6,6))
H[0:2,2:4] = H[2:4,0:2] = C12 * sigmax()
H[0:2,4:6] = H[4:6,0:2] = C13 * sigmax() 
H[2:4,4:6] = H[4:6,2:4] = C23 * sigmax()

# Evolve full state vector
U = expm(-1j * H * 1.0)
state_t = U @ state_vec

# Extract evolved states and compute couplings
psi1_t = state_t[0:2]; psi2_t = state_t[2:4]; psi3_t = state_t[4:6]
print("C12(t=1):", np.abs(psi1_t.conj().T @ psi2_t)**2)
print("C13(t=1):", np.abs(psi1_t.conj().T @ psi3_t)**2)
print("C23(t=1):", np.abs(psi2_t.conj().T @ psi3_t)**2)
