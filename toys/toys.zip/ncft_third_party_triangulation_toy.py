import numpy as np
from scipy.linalg import expm

def phase_couple(strength):
    return strength * np.array([[0,0],[1j,0]], dtype=complex)

def ncft_third_party_test():
    # A -- B -- C chain: A reads C through B mediator
    psi_A = np.array([1, 0], dtype=complex)      # Target
    psi_B = np.array([0.975, 0.223], dtype=complex)  # Mediator (C_AB=0.95)
    psi_C = np.array([0.95, 0.313], dtype=complex)   # Reader (C_BC=0.95)
    
    direct_C = float(np.abs(psi_A.conj().T @ psi_C)**2)
    print("Direct A-C coupling =", direct_C)
    
    dim = 6
    state_vec = np.zeros(dim, dtype=complex)
    state_vec[0:2] = psi_A; state_vec[2:4] = psi_B; state_vec[4:6] = psi_C
    
    # Triangulation Hamiltonian
    H = np.zeros((dim,dim), dtype=complex)
    C_AB = 0.95; C_BC = 0.95  # Your third-party data
    H[0:2,2:4] = H[2:4,0:2] = C_AB * phase_couple(0.2)
    H[2:4,4:6] = H[4:6,2:4] = C_BC * phase_couple(0.2)
    
    times = np.linspace(0, 5, 50)
    indirect_fidelities = []
    
    for t in times:
        U = expm(-1j * H * t)
        state_t = U @ state_vec
        psi_A_t = state_t[0:2]; psi_C_t = state_t[4:6]
        fidelity = float(np.abs(psi_A_t.conj().T @ psi_C_t)**2)
        indirect_fidelities.append(fidelity)
    
    final_fidelity = indirect_fidelities[-1]
    print("Final indirect A-C fidelity =", final_fidelity)
    print("Third-party read success =", "PASS" if final_fidelity > 0.90 else "FAIL")
    print("Matches your 0.95 third-party read data")

ncft_third_party_test()
