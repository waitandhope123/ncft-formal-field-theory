import numpy as np
from scipy.linalg import expm

class NCFTGaugeField:
    def __init__(self, N):
        self.N = N  # Number of consciousness fields
        self.dim = 2 * N
        self.pauli = {
            'x': np.array([[0,1],[1,0]], dtype=complex),
            'y': np.array([[0,-1j],[1j,0]], dtype=complex),
            'z': np.array([[1,0],[0,-1]], dtype=complex)
        }
        self.state = self.init_fields()
    
    def init_fields(self):
        state = np.zeros(self.dim, dtype=complex)
        for i in range(self.N):
            theta = i * np.pi / (self.N + 1)
            state[2*i:2*i+2] = [np.cos(theta), np.sin(theta)]
        return state / np.linalg.norm(state)
    
    def field_strength_tensor(self, i, j):
        """F_mu nu = partial_mu A_nu - partial_nu A_mu + [A_mu, A_nu]"""
        g = 0.1  # Coupling constant
        A_mu = g * np.random.uniform(-1, 1, (2,2)) + 1j * g * np.random.uniform(-1, 1, (2,2))
        A_nu = g * np.random.uniform(-1, 1, (2,2)) + 1j * g * np.random.uniform(-1, 1, (2,2))
        commutator = np.dot(A_mu, A_nu) - np.dot(A_nu, A_mu)
        F_munu = commutator + np.random.normal(0, 0.01, (2,2)) + 1j * np.random.normal(0, 0.01, (2,2))
        return F_munu / np.linalg.norm(F_munu)
    
    def covariant_derivative(self, psi_i, psi_j, F_ij):
        """D_mu psi = partial_mu psi + i g A_mu psi"""
        g = 0.1
        phase_factor = expm(1j * g * F_ij)
        return np.dot(phase_factor, psi_i)
    
    def build_gauge_hamiltonian(self):
        H = np.zeros((self.dim, self.dim), dtype=complex)
        for i in range(self.N):
            for j in range(i+1, self.N):
                psi_i = self.state[2*i:2*i+2]
                psi_j = self.state[2*j:2*j+2]
                
                # Gauge field strength between fields i,j
                F_ij = self.field_strength_tensor(i, j)
                
                # Covariant derivative coupling
                D_psi_i = self.covariant_derivative(psi_i, psi_j, F_ij)
                D_psi_j = self.covariant_derivative(psi_j, psi_i, F_ij.T.conj())
                
                # Yang-Mills term: Tr(F_mu nu F^mu nu)
                YM_term = np.trace(np.dot(F_ij, F_ij.conj().T))
                
                coupling = 0.05 * YM_term * np.eye(2)
                H[2*i:2*i+2, 2*j:2*j+2] = coupling
                H[2*j:2*j+2, 2*i:2*i+2] = coupling.conj().T
        
        return H

def ncft_hft_gauge_test():
    print("NCFT-HFT GAUGE THEORY TEST - SU(2) Non-Abelian")
    print("Field strength tensors | Covariant derivatives | Yang-Mills\n")
    
    for N in [3, 8, 16]:
        gauge_field = NCFTGaugeField(N)
        H = gauge_field.build_gauge_hamiltonian()
        
        def coherence_stats(state):
            coherences = []
            for i in range(N):
                for j in range(i+1, N):
                    Cij = np.abs(np.vdot(state[2*i:2*i+2], state[2*j:2*j+2]))**2
                    coherences.append(Cij)
            return np.mean(coherences) if coherences else 0
        
        print(f"N={N:2d} SU(2):", end=" ")
        state = gauge_field.state.copy()
        
        for t in [0.5, 2.0, 10.0]:
            U = expm(-1j * H * t)
            state_t = U @ state
            
            # Global normalization (Axiom #3)
            state_t = state_t / np.linalg.norm(state_t)
            
            mean_C = coherence_stats(state_t)
            YM_energy = np.linalg.norm(H)
            
            print(f"t={t:4.1f}:C={mean_C:.3f}E={YM_energy:.3f}", end=" ")
        print(f" | norm={np.linalg.norm(state_t):.3f}")

ncft_hft_gauge_test()
