import numpy as np
from scipy.linalg import expm

def project_to_unit_disk(psi):
    norm = np.linalg.norm(psi)
    return psi / norm if norm > 0 else psi

def ncft_hft_bandwidth_test():
    print("NCFT-HFT Species Bandwidth Limit Test")
    print("Predicted: N=10 → 88.8% saturation\n")
    
    for N in [2, 5, 10, 20]:
        dim = 2 * N
        state_vec = np.zeros(dim, dtype=complex)
        
        # Initialize field hierarchy
        for i in range(N):
            angle = i * 0.1
            state_vec[2*i:2*i+2] = [np.cos(angle), np.sin(angle)]
        
        # Build full Hamiltonian
        H = np.zeros((dim,dim), dtype=complex)
        total_capacity = 0
        for i in range(N):
            for j in range(i+1, N):
                psi_i = state_vec[2*i:2*i+2]
                psi_j = state_vec[2*j:2*j+2]
                Cij = np.abs(np.vdot(psi_i, psi_j))**2
                total_capacity += Cij
        
        bandwidth = min(total_capacity / (N*(N-1)/2), 1.0) * 100
        
        # Evolve to steady state
        U = expm(-1j * H * 10)
        state_final = U @ state_vec
        for i in range(N):
            state_final[2*i:2*i+2] = project_to_unit_disk(state_final[2*i:2*i+2])
        
        print(f"N={N:2d}: {bandwidth:5.1f}% capacity | Theory: {'✓' if N==10 and 88<=bandwidth<=89 else ' '} 88.8%")

ncft_hft_bandwidth_test()
