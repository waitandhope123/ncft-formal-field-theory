import numpy as np
from scipy.linalg import expm

def phase_couple(strength):
    return strength * np.array([[0,0],[1j,0]], dtype=complex)

def project_to_unit_disk(psi):
    """NCFT Axiom #2: Enforce 0 ≤ C ≤ 1 via projection"""
    norm = np.linalg.norm(psi)
    if norm > 0:
        return psi / norm
    return psi

def ncft_projection_test():
    # Reuse your shielding case (produced C=52.56)
    psi_A = np.array([1, 0], dtype=complex)
    psi_B = np.array([1, 0], dtype=complex)
    
    dim = 4
    state_vec = np.zeros(dim, dtype=complex)
    state_vec[0:2] = psi_A; state_vec[2:4] = psi_B
    
    H = np.zeros((dim,dim), dtype=complex)
    C_shield = 1.00
    H[0:2,2:4] = H[2:4,0:2] = C_shield * phase_couple(0.5)
    
    times = np.linspace(0, 5, 20)
    
    for t in times:
        U = expm(-1j * H * t)
        state_t = U @ state_vec
        
        # NCFT Projection: Normalize each field
        for i in [0, 2]:
            state_t[i:i+2] = project_to_unit_disk(state_t[i:i+2])
        
        psi_A_t = state_t[0:2]; psi_B_t = state_t[2:4]
        C_raw = np.abs(psi_A_t.conj().T @ psi_B_t)**2
        C_projected = min(float(C_raw), 1.0)  # Hard clamp
        
        print(f"t={t:.1f}: C_raw={C_raw:.2f} → C_projected={C_projected:.2f}")

ncft_projection_test()
