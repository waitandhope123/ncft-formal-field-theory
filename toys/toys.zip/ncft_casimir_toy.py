import numpy as np  # ADDED - fixes NameError

def ncft_casimir_pressure(N: int, d=1e-6):  # 1μm plates
    """NCFT modulation of Casimir P=1.3×10⁻¹² Pa"""
    P_standard = 1.3e-12 * (1/d)**4  # Lamoreaux 2011
    C_total = N*(N-1)/2
    P_ncft = P_standard * (1 + 0.1 * C_total * np.exp(-d*1e6))  # μm scale
    anomaly = (P_ncft - P_standard)/P_standard * 100
    return P_ncft, anomaly

for N in [2, 7, 25]:
    P, anomaly = ncft_casimir_pressure(N)
    print(f"N={N}: P={P:.1e} Pa, anomaly={anomaly:.1f}%")
