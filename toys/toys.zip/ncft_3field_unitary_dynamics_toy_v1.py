import numpy as np
from scipy.linalg import expm

sigmax = lambda: np.array([[0,1],[1,0]])

# States
psi1 = np.array([1, 0])  # user
psi2 = np.array([1, 0])  # psychic  
psi3 = np.array([0.995, 0.1])  # dad

# Embed into 6-vector
state_vec = np.zeros(6, dtype=complex)
state_vec[0:2] = psi1; state_vec[2:4] = psi2; state_vec[4:6] = psi3

# Hamiltonian  
C12 = 1.0; C13 = np.abs(psi1.conj().T @ psi3)**2; C23 = np.abs(psi2.conj().T @ psi3)**2

# OLD (σ=0.696 ❌)
H[0:2,2:4] = H[2:4,0:2] = C12 * sigmax()
H[0:2,4:6] = H[4:6,0:2] = C13 * sigmax() 
H[2:4,4:6] = H[4:6,2:4] = C23 * sigmax()

# Evolve
U = expm(-1j * H * 1.0)
state_t = U @ state_vec

# Extract + couplings (your confirmed results)
psi1_t = state_t[0:2]; psi2_t = state_t[2:4]; psi3_t = state_t[4:6]
print("C12(t=1):", np.abs(psi1_t.conj().T @ psi2_t)**2)
print("C13(t=1):", np.abs(psi1_t.conj().T @ psi3_t)**2)

# Axiom #3: Frequency coherence check
freq_drift = np.angle(psi1_t) - np.angle(psi1)
sigma_t = np.std(freq_drift)
print("σ(t=1):", sigma_t)  # Target: <0.1
