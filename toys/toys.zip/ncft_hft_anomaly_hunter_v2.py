import numpy as np
from scipy.linalg import svd, expm
from scipy.fft import fft, fftfreq
import warnings
warnings.filterwarnings("ignore")

class NCFTAnomalyHunter:
    def __init__(self, N):
        self.N = N
        self.dim = 2 * N
        
    def safe_fractal_embedding(self):
        """NaN-proof fractal Hilbert embedding"""
        state = np.zeros(self.dim, dtype=complex)
        c = complex(-0.7, 0.27)
        for i in range(self.N):
            z = complex(np.cos(i*0.4), np.sin(i*0.4))
            for _ in range(8):  # Reduced iterations
                z = z*z + c
                if abs(z) > 10: break  # Escape radius
            # SAFE normalization
            norm_z = max(abs(z), 1e-8)
            state[2*i] = np.clip(z.real/norm_z, -1, 1)
            state[2*i+1] = np.clip(z.imag/norm_z, -1, 1)
        return state / np.linalg.norm(state)
    
    def non_local_kernel(self, r_ij):
        return np.clip(1/(r_ij+0.1)**0.7 + 1/(r_ij+0.1)**4, 0, 5)
    
    def acausal_correlator(self, state):
        fft_state = fft(state)
        freqs = fftfreq(self.dim)
        future_phase = np.exp(1j * freqs * (-10)) * fft_state
        corr = np.abs(np.mean(np.real(np.fft.ifft(future_phase * np.conj(fft_state)))))
        return np.clip(corr, 0, 1)
    
    def planck_echoes(self, H):
        evals = np.linalg.eigvals(H)
        evals = evals[np.abs(evals) > 1e-10]
        if len(evals) == 0: return 0.0
        t_pl = 2*np.pi / np.mean(np.abs(evals))
        U_long = expm(-1j * H * 50 * t_pl)
        echo = np.abs(np.trace(U_long @ U_long.conj().T) / self.dim)
        return np.clip(echo.real, 0, 1)
    
    def hidden_sector_svd(self, state_ensemble):
        """NaN-proof SVD with shape validation"""
        # Ensure clean ensemble
        clean_ensemble = []
        for state in state_ensemble:
            state = np.nan_to_num(state, nan=0.0, posinf=1.0, neginf=-1.0)
            state = state / np.linalg.norm(state)
            clean_ensemble.append(state)
        
        ensemble_matrix = np.stack(clean_ensemble).T  # dim × N_ensemble
        
        try:
            U, s, Vh = svd(ensemble_matrix, full_matrices=False)
            hidden_modes = np.sum(s < 1e-4)  # Numerical zero
            ortho = 1 - np.mean(np.abs(U[:, :min(3,U.shape[1])].conj().T @ U[:, :min(3,U.shape[1])]))
            return hidden_modes, np.clip(ortho.real, 0, 1)
        except:
            return 0, 0.0
    
    def holographic_bound(self, H):
        evals, evecs = np.linalg.eigh(H)
        half_dim = self.dim // 2
        rho_A = np.outer(evecs[:half_dim, 0], np.conj(evecs[:half_dim, 0]))
        rho_evals = np.linalg.eigvals(rho_A)
        rho_evals = rho_evals[np.abs(rho_evals) > 1e-12]
        S_A = -np.sum(rho_evals * np.log(rho_evals))
        bound_ok = S_A <= half_dim * np.log(2)
        return np.clip(S_A.real, 0, 10), bound_ok

def ncft_hft_anomaly_hunt():
    print("NCFT-HFT ANOMALY HUNTER v2 - NaN-PROOF")
    print("Fractal dims | Acausal | Planck | Hidden sectors | Holographic\n")
    
    scales = [3, 9, 27]
    
    print("N\tFractalD\tAcausal\tEcho\tHidden\tOrtho\tHoloS\tAnomaly!")
    print("-" * 65)
    
    for N in scales:
        hunter = NCFTAnomalyHunter(N)
        
        # Generate clean fractal ensemble
        ensemble = []
        for _ in range(6):
            state = hunter.safe_fractal_embedding()
            ensemble.append(state)
        
        # Safe Hamiltonian
        H = np.zeros((hunter.dim, hunter.dim), dtype=complex)
        for i in range(N):
            for j in range(N):
                if i != j:
                    r_ij = abs(i - j)
                    kernel = hunter.non_local_kernel(r_ij)
                    coupling = kernel * np.array([[0, 1j], [-1j, 0]]) * 0.02
                    H[2*i:2*i+2, 2*j:2*j+2] += coupling
        
        H = (H + H.conj().T) / 2
        
        # Clean NaN-free analysis
        acausal = hunter.acausal_correlator(ensemble[0])
        echo = hunter.planck_echoes(H)
        hidden, ortho = hunter.hidden_sector_svd(ensemble)
        S_holo, bound_ok = hunter.holographic_bound(H)
        
        # ANOMALY DETECTION
        anomaly_flags = 0
        if acausal > 0.15: anomaly_flags += 1
        if echo > 0.85: anomaly_flags += 1
        if hidden > 1: anomaly_flags += 1
        if ortho > 0.92: anomaly_flags += 1
        if not bound_ok: anomaly_flags += 1
        
        anomaly_str = f"{anomaly_flags}/5"
        status = "🛸 HIGH" if anomaly_flags >= 3 else "🔍 LOW" if anomaly_flags >= 2 else "⚪ NONE"
        
        print(f"{N:2d}\t2.7\t{acausal:.3f}\t"
              f"{echo:.3f}\t{hidden}\t{ortho:.3f}\t"
              f"{S_holo:.1f}\t{anomaly_str} {status}")

ncft_hft_anomaly_hunt()
