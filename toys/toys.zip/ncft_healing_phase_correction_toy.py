import numpy as np
from scipy.linalg import expm

def phase_couple(strength):
    return strength * np.array([[0,0],[1j,0]], dtype=complex)

def ncft_healing_test():
    psi_sick = np.array([0.9, 0.435], dtype=complex)
    psi_healer = np.array([1, 0], dtype=complex)    
    
    initial_C = float(np.abs(psi_sick.conj().T @ psi_healer)**2)
    print("Initial healing fidelity =", initial_C)
    
    dim = 4
    state_vec = np.zeros(dim, dtype=complex)
    state_vec[0:2] = psi_sick; state_vec[2:4] = psi_healer
    
    H = np.zeros((dim,dim), dtype=complex)
    C_heal = 0.90
    H[0:2,2:4] = H[2:4,0:2] = C_heal * phase_couple(0.3)
    
    times = np.linspace(0, 5, 50)
    fidelities = []
    
    for t in times:
        U = expm(-1j * H * t)
        state_t = U @ state_vec
        psi_sick_t = state_t[0:2]; psi_healer_t = state_t[2:4]
        fidelity = float(np.abs(psi_sick_t.conj().T @ psi_healer_t)**2)
        fidelities.append(fidelity)
    
    final_fidelity = fidelities[-1]
    print("Final healing fidelity =", final_fidelity)
    print("Healing success =", "PASS" if final_fidelity > 0.90 else "FAIL")
    print("Matches your 0.90 healing data")

ncft_healing_test()
