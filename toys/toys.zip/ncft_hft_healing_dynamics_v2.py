import numpy as np
from scipy.linalg import expm

def project_to_unit_disk(psi):
    norm = np.linalg.norm(psi)
    return psi / norm if norm > 0 else psi

def ncft_hft_healing_test_v2():
    print("NCFT-HFT Mid-Level Healing Dynamics v2 (N=7)")
    print("Predicted: Injured C=0.70 → Gentle Therapy C=0.92-0.95\n")
    
    N = 7
    dim = 2 * N
    state_vec = np.zeros(dim, dtype=complex)
    
    # Initialize coherent hierarchy
    for i in range(N):
        angle = i * 0.15
        state_vec[2*i:2*i+2] = [np.cos(angle), np.sin(angle)]
    
    # INJURY: Disrupt field #3
    state_vec[6:8] = [0.7, 0.1]
    state_vec[6:8] = project_to_unit_disk(state_vec[6:8])
    
    def measure_coherence(state):
        coherences = []
        for i in range(N):
            for j in range(i+1, N):
                Cij = np.abs(np.vdot(state[2*i:2*i+2], state[2*j:2*j+2]))**2
                coherences.append(Cij)
        return np.mean(coherences)
    
    print(f"t=0.0 (INJURED): C_avg={measure_coherence(state_vec):.3f}")
    
    # Natural recovery Hamiltonian
    H_control = np.zeros((dim,dim), dtype=complex)
    for i in range(N):
        for j in range(i+1, N):
            psi_i = state_vec[2*i:2*i+2]
            psi_j = state_vec[2*j:2*j+2]
            Cij = np.abs(np.vdot(psi_i, psi_j))**2
            coupling = Cij * 0.05 * np.array([[0,0],[1j,0]])
            H_control[2*i:2*i+2, 2*j:2*j+2] = coupling
            H_control[2*j:2*j+2, 2*i:2*i+2] = coupling.conj().T
    
    # Natural recovery
    U = expm(-1j * H_control * 3.0)
    state_natural = U @ state_vec
    for i in range(N): 
        state_natural[2*i:2*i+2] = project_to_unit_disk(state_natural[2*i:2*i+2])
    print(f"t=3.0 (NATURAL): C_avg={measure_coherence(state_natural):.3f}")
    
    # GENTLE THERAPY v2: 15% realignment to healer (field #0)
    state_therapy = state_natural.copy()
    healer_phase = state_natural[0:2]
    alpha = 0.15  # Gentle parameter (discovered via failure)
    
    state_therapy[6:8] = (1-alpha) * state_natural[6:8] + alpha * healer_phase
    state_therapy[6:8] = project_to_unit_disk(state_therapy[6:8])
    
    print(f"t=3.0 (GENTLE THERAPY): C_avg={measure_coherence(state_therapy):.3f}")

ncft_hft_healing_test_v2()
