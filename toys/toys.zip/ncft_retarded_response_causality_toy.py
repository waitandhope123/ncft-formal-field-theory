#!/usr/bin/env python3
# ncft_retarded_response_causality_toy.py
#
# NCFT Retarded Response / Causality Toy
# -------------------------------------
# Goal:
#   Measure time-domain retarded response kernels G^R_{ij}(t) from a localized "impulse"
#   perturbation applied at t0, and test causality / time-ordering properties.
#
# What it does:
#   1) Builds an NCFT coupling matrix C(t) from a set of unit vectors f_i(t) on S^(dim-1)
#      with Axiom-like constraints: symmetry, zero diagonal, 0<=C_ij<=1.
#   2) Evolves f_i(t) under a stable "alignment + noise" flow.
#   3) Applies a short impulse to ONE target index k at time t0 in a chosen direction.
#   4) Runs a baseline and a perturbed simulation with identical RNG seeds.
#   5) Computes deltaC_ij(t) = C_ij^pert(t) - C_ij^base(t)
#      and estimates retarded kernel amplitude:
#         G_ij(t) ~ deltaC_ij(t) / eps
#   6) Extracts response onset times, builds a causal adjacency graph, and reports
#      if any "pre-response" appears before t0 (should be ~0).
#
# Usage examples:
#   python ncft_retarded_response_causality_toy.py --N 25 --dim 2 --T 200 --dt 0.05 --target 0 --eps 1e-3 --impulse_steps 2
#   python ncft_retarded_response_causality_toy.py --N 25 --dim 3 --T 300 --dt 0.05 --target 7 --eps 5e-4 --noise 0.02
#
# Notes:
#   - This is intentionally "physics-observable": it measures *time ordered* effect after cause.
#   - It is a comprehensive single toy: response kernels, causality checks, and emergent causal graph.
#
import argparse
import math
import sys
from dataclasses import dataclass
from typing import Dict, Tuple, List

import numpy as np


# -------------------------
# Utilities
# -------------------------

def unit_normalize(v: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    n = np.linalg.norm(v)
    if n < eps:
        # If degenerate, reinitialize randomly
        v = np.random.normal(size=v.shape)
        n = np.linalg.norm(v) + eps
    return v / n

def make_random_unit_vectors(N: int, dim: int, rng: np.random.Generator) -> np.ndarray:
    X = rng.normal(size=(N, dim))
    X /= (np.linalg.norm(X, axis=1, keepdims=True) + 1e-12)
    return X

def coupling_from_vectors(F: np.ndarray) -> np.ndarray:
    # C_ij = max(0, dot(f_i, f_j)) with zero diagonal; symmetric by construction
    G = F @ F.T
    C = np.clip(G, 0.0, 1.0)
    np.fill_diagonal(C, 0.0)
    # Force perfect symmetry (numerical)
    C = 0.5 * (C + C.T)
    return C

def offdiag_stats(C: np.ndarray) -> Dict[str, float]:
    N = C.shape[0]
    mask = ~np.eye(N, dtype=bool)
    x = C[mask]
    return {
        "min_offdiag": float(np.min(x)),
        "mean_offdiag": float(np.mean(x)),
        "max_offdiag": float(np.max(x)),
        "sigma_offdiag": float(np.std(x)),
    }

def spectral_stats(C: np.ndarray) -> Dict[str, float]:
    # Real symmetric => real eigenvalues
    w = np.linalg.eigvalsh(C)
    return {
        "eig_min": float(np.min(w)),
        "eig_max": float(np.max(w)),
        "eig_mean": float(np.mean(w)),
        "eig_std": float(np.std(w)),
    }

def pairwise_sum(C: np.ndarray) -> Dict[str, float]:
    N = C.shape[0]
    triu = np.triu_indices(N, k=1)
    total = float(np.sum(C[triu]))
    bound = float(N * (N - 1) / 2)  # since 0<=C_ij<=1
    return {"total_i_lt_j": total, "bound": bound}

def frob_norm(A: np.ndarray) -> float:
    return float(np.linalg.norm(A, ord="fro"))

def reciprocity_score(G: np.ndarray) -> float:
    # ||G - G^T|| / ||G|| (should be small if reciprocity holds; time-domain can still be symmetric in ij)
    denom = frob_norm(G) + 1e-30
    return frob_norm(G - G.T) / denom

def pretty_float(x: float, fmt: str = ".6e") -> str:
    return format(x, fmt)

def time_to_index(t: float, dt: float) -> int:
    return int(round(t / dt))

@dataclass
class RunResult:
    times: np.ndarray
    C_series: np.ndarray  # shape (steps+1, N, N)
    stats_series: Dict[str, np.ndarray]  # mean_offdiag etc.


# -------------------------
# Dynamics
# -------------------------

def evolve_ncft(
    N: int,
    dim: int,
    T: float,
    dt: float,
    rng_seed: int,
    mode: str,
    noise: float,
    alpha: float,
    beta: float,
    target: int,
    t0: float,
    eps: float,
    impulse_steps: int,
    impulse_dir: str,
    sample_every: int,
) -> RunResult:
    """
    Stable alignment flow:
        f_i <- f_i + dt * [ alpha * sum_j C_ij (f_j - f_i)  - beta * f_i ] + sqrt(dt)*noise*eta
    Then renormalize each f_i to unit length.

    Impulse:
        For i=target and for a small window after t0,
        add eps * u (or eps * random unit dir) to f_target before renorm.

    Modes:
        - "unitary": no noise
        - "noisy": Gaussian noise on f_i update
    """
    steps = int(round(T / dt))
    times = np.linspace(0.0, T, steps + 1)

    rng = np.random.default_rng(rng_seed)
    F = make_random_unit_vectors(N, dim, rng)

    # Pick impulse direction
    if impulse_dir == "basis":
        u = np.zeros(dim, dtype=float)
        u[0] = 1.0
        u = unit_normalize(u)
    elif impulse_dir == "random":
        u = unit_normalize(rng.normal(size=(dim,)))
    else:
        raise ValueError("impulse_dir must be 'basis' or 'random'")

    C0 = coupling_from_vectors(F)

    # Store sampled series (dense by default, but can thin out with sample_every)
    # We'll store every step for kernel extraction; user can reduce with sample_every if needed
    C_series = np.zeros((steps + 1, N, N), dtype=float)
    C_series[0] = C0

    mean_offdiag = np.zeros(steps + 1, dtype=float)
    sigma_offdiag = np.zeros(steps + 1, dtype=float)
    mean_offdiag[0] = offdiag_stats(C0)["mean_offdiag"]
    sigma_offdiag[0] = offdiag_stats(C0)["sigma_offdiag"]

    t0_idx = time_to_index(t0, dt)
    imp_end = min(steps, t0_idx + max(0, impulse_steps) - 1)

    for s in range(1, steps + 1):
        C = C_series[s - 1]

        # Alignment term
        # drift_i = alpha * sum_j C_ij (f_j - f_i) - beta f_i
        # Compute sum_j C_ij f_j efficiently
        CF = C @ F
        row_sum = np.sum(C, axis=1, keepdims=True)  # sum_j C_ij
        drift = alpha * (CF - row_sum * F) - beta * F

        # Noise
        if mode == "unitary":
            eta = 0.0
        else:
            eta = rng.normal(size=(N, dim))

        F = F + dt * drift + math.sqrt(dt) * noise * eta

        # Impulse injection (only for the "perturbed" run; caller handles eps=0 for baseline)
        if eps != 0.0 and (s >= t0_idx) and (s <= imp_end):
            F[target] = F[target] + eps * u

        # Renormalize
        norms = np.linalg.norm(F, axis=1, keepdims=True) + 1e-12
        F = F / norms

        # Update coupling
        Cn = coupling_from_vectors(F)
        C_series[s] = Cn

        if s % sample_every == 0 or s == steps:
            st = offdiag_stats(Cn)
            mean_offdiag[s] = st["mean_offdiag"]
            sigma_offdiag[s] = st["sigma_offdiag"]
        else:
            # carry forward for convenience
            mean_offdiag[s] = mean_offdiag[s - 1]
            sigma_offdiag[s] = sigma_offdiag[s - 1]

    return RunResult(
        times=times,
        C_series=C_series,
        stats_series={
            "mean_offdiag": mean_offdiag,
            "sigma_offdiag": sigma_offdiag,
        },
    )


# -------------------------
# Kernel extraction & causality tests
# -------------------------

def extract_retarded_kernel(
    C_base: np.ndarray,
    C_pert: np.ndarray,
    eps: float,
) -> np.ndarray:
    # Kernel estimate per-time-slice
    # G(t) = (C_pert(t) - C_base(t)) / eps
    return (C_pert - C_base) / (eps if eps != 0 else 1.0)

def onset_times(
    G_series: np.ndarray,
    times: np.ndarray,
    t0: float,
    threshold: float,
    aggregate: str = "row_target",
    target: int = 0,
) -> Dict[int, float]:
    """
    Determine earliest time after t0 where response crosses threshold.
    aggregate modes:
      - "row_target": use max_j |G[target, j]|
      - "col_target": use max_i |G[i, target]|
      - "pairwise": for each j compute first crossing of |G[target, j]|
    Returns dict mapping index -> onset_time
    """
    tmask = times >= t0
    idxs = np.where(tmask)[0]
    if len(idxs) == 0:
        return {}

    onsets: Dict[int, float] = {}

    if aggregate == "pairwise":
        N = G_series.shape[1]
        for j in range(N):
            if j == target:
                continue
            g = np.abs(G_series[idxs, target, j])
            hit = np.where(g >= threshold)[0]
            if len(hit) > 0:
                onsets[j] = float(times[idxs[hit[0]]])
        return onsets

    if aggregate == "row_target":
        g = np.max(np.abs(G_series[idxs, target, :]), axis=1)
        hit = np.where(g >= threshold)[0]
        if len(hit) > 0:
            onsets[target] = float(times[idxs[hit[0]]])
        return onsets

    if aggregate == "col_target":
        g = np.max(np.abs(G_series[idxs, :, target]), axis=1)
        hit = np.where(g >= threshold)[0]
        if len(hit) > 0:
            onsets[target] = float(times[idxs[hit[0]]])
        return onsets

    raise ValueError("Unknown aggregate mode")

def pre_causality_leakage(
    G_series: np.ndarray,
    times: np.ndarray,
    t0: float,
) -> Dict[str, float]:
    """
    Measure whether any significant response appears before t0.
    Ideally should be ~0 (up to numerical noise), since we use identical seeds and impulse after t0.
    """
    idxs = np.where(times < t0)[0]
    if len(idxs) == 0:
        return {"pre_max_abs": 0.0, "pre_mean_abs": 0.0, "pre_rms": 0.0}
    Gpre = G_series[idxs]
    a = np.abs(Gpre)
    return {
        "pre_max_abs": float(np.max(a)),
        "pre_mean_abs": float(np.mean(a)),
        "pre_rms": float(np.sqrt(np.mean(Gpre * Gpre))),
    }

def build_causal_adjacency(
    pair_onsets: Dict[int, float],
    N: int,
    t0: float,
    max_delay: float,
) -> np.ndarray:
    """
    Build a simple adjacency vector from target -> j where onset within max_delay.
    Returns adjacency array length N with 1 if connected else 0.
    """
    adj = np.zeros(N, dtype=int)
    for j, tj in pair_onsets.items():
        if (tj - t0) <= max_delay:
            adj[j] = 1
    return adj


# -------------------------
# Main
# -------------------------

def main():
    ap = argparse.ArgumentParser(description="NCFT Retarded Response / Causality Toy")
    ap.add_argument("--N", type=int, default=25)
    ap.add_argument("--dim", type=int, default=2)
    ap.add_argument("--T", type=float, default=200.0)
    ap.add_argument("--dt", type=float, default=0.05)
    ap.add_argument("--mode", type=str, default="unitary", choices=["unitary", "noisy"])
    ap.add_argument("--noise", type=float, default=0.02, help="noise amplitude (only in noisy mode)")
    ap.add_argument("--alpha", type=float, default=0.30, help="alignment strength")
    ap.add_argument("--beta", type=float, default=0.02, help="damping")
    ap.add_argument("--target", type=int, default=0, help="index of impulsed field")
    ap.add_argument("--t0", type=float, default=10.0, help="impulse start time")
    ap.add_argument("--eps", type=float, default=1e-3, help="impulse amplitude")
    ap.add_argument("--impulse_steps", type=int, default=2, help="number of integration steps impulse lasts")
    ap.add_argument("--impulse_dir", type=str, default="random", choices=["random", "basis"])
    ap.add_argument("--seed", type=int, default=1234, help="RNG seed (shared baseline/perturbed)")
    ap.add_argument("--sample_every", type=int, default=1, help="stats sampling cadence (series still stored)")
    ap.add_argument("--threshold", type=float, default=1e-4, help="onset threshold for |G|")
    ap.add_argument("--max_delay", type=float, default=5.0, help="max delay window for adjacency")
    ap.add_argument("--topK", type=int, default=10, help="top responders to print")
    args = ap.parse_args()

    if args.target < 0 or args.target >= args.N:
        print("ERROR: target must be in [0, N-1]")
        sys.exit(2)

    # For unitary mode, enforce noise=0 for reproducibility
    noise = 0.0 if args.mode == "unitary" else args.noise

    print("\n" + "=" * 90)
    print("NCFT RETARDED RESPONSE / CAUSALITY TOY")
    print("=" * 90)
    print(
        f"N={args.N} dim={args.dim} mode={args.mode} T={args.T} dt={args.dt} steps={int(round(args.T/args.dt))} "
        f"target={args.target} t0={args.t0} eps={args.eps} impulse_steps={args.impulse_steps} seed={args.seed}"
    )
    print(f"alpha={args.alpha} beta={args.beta} noise={noise} impulse_dir={args.impulse_dir}")
    print("=" * 90)

    # Baseline run (eps=0)
    base = evolve_ncft(
        N=args.N,
        dim=args.dim,
        T=args.T,
        dt=args.dt,
        rng_seed=args.seed,
        mode=args.mode,
        noise=noise,
        alpha=args.alpha,
        beta=args.beta,
        target=args.target,
        t0=args.t0,
        eps=0.0,
        impulse_steps=args.impulse_steps,
        impulse_dir=args.impulse_dir,
        sample_every=args.sample_every,
    )

    # Perturbed run (eps != 0)
    pert = evolve_ncft(
        N=args.N,
        dim=args.dim,
        T=args.T,
        dt=args.dt,
        rng_seed=args.seed,  # identical seed
        mode=args.mode,
        noise=noise,
        alpha=args.alpha,
        beta=args.beta,
        target=args.target,
        t0=args.t0,
        eps=args.eps,
        impulse_steps=args.impulse_steps,
        impulse_dir=args.impulse_dir,
        sample_every=args.sample_every,
    )

    # Summaries (final time)
    Cb0 = base.C_series[0]
    Cp0 = pert.C_series[0]
    CbT = base.C_series[-1]
    CpT = pert.C_series[-1]

    print("\n" + "-" * 90)
    print("BASELINE SUMMARY (t=0 and t=T)")
    print("-" * 90)
    print("t=0  offdiag:", offdiag_stats(Cb0))
    print("t=0  sum   :", pairwise_sum(Cb0))
    print("t=0  spec  :", spectral_stats(Cb0))
    print("t=T  offdiag:", offdiag_stats(CbT))
    print("t=T  sum   :", pairwise_sum(CbT))
    print("t=T  spec  :", spectral_stats(CbT))

    print("\n" + "-" * 90)
    print("PERTURBED SUMMARY (t=0 and t=T)")
    print("-" * 90)
    print("t=0  offdiag:", offdiag_stats(Cp0))
    print("t=0  sum   :", pairwise_sum(Cp0))
    print("t=0  spec  :", spectral_stats(Cp0))
    print("t=T  offdiag:", offdiag_stats(CpT))
    print("t=T  sum   :", pairwise_sum(CpT))
    print("t=T  spec  :", spectral_stats(CpT))

    # Extract kernel series G(t)
    G_series = extract_retarded_kernel(base.C_series, pert.C_series, args.eps)

    # Pre-causality leakage
    leak = pre_causality_leakage(G_series, base.times, args.t0)

    # Instant slice right after t0 for "top responders"
    t0_idx = time_to_index(args.t0, args.dt)
    t_post_idx = min(len(base.times) - 1, t0_idx + max(1, args.impulse_steps))
    G_post = G_series[t_post_idx]

    # Pairwise onsets from target -> j
    pair_on = onset_times(
        G_series=G_series,
        times=base.times,
        t0=args.t0,
        threshold=args.threshold,
        aggregate="pairwise",
        target=args.target,
    )

    # Build simple adjacency vector (within max_delay)
    adj = build_causal_adjacency(pair_on, args.N, args.t0, args.max_delay)

    # Print causality diagnostics
    print("\n" + "-" * 90)
    print("CAUSALITY / RETARDED RESPONSE DIAGNOSTICS")
    print("-" * 90)
    print("Pre-t0 leakage (should be ~0):")
    print(
        f"  pre_max_abs={pretty_float(leak['pre_max_abs'])}  "
        f"pre_mean_abs={pretty_float(leak['pre_mean_abs'])}  "
        f"pre_rms={pretty_float(leak['pre_rms'])}"
    )

    # Reciprocity check at a representative time slice after t0
    rec = reciprocity_score(G_post)
    print(f"Retarded kernel reciprocity score ||G-G^T||/||G|| at t~{base.times[t_post_idx]:.3f}: {pretty_float(rec)}")

    # Top responders (target row and column at t_post_idx)
    row = G_post[args.target, :].copy()
    col = G_post[:, args.target].copy()
    row_abs = np.abs(row)
    col_abs = np.abs(col)

    row_order = np.argsort(-row_abs)
    col_order = np.argsort(-col_abs)

    print("\nTop |G[target,j]| responders (outgoing influence) at first post-impulse slice:")
    printed = 0
    for j in row_order:
        if j == args.target:
            continue
        print(f"  j={j:3d}  G={pretty_float(row[j])}")
        printed += 1
        if printed >= args.topK:
            break

    print("\nTop |G[i,target]| responders (incoming sensitivity) at first post-impulse slice:")
    printed = 0
    for i in col_order:
        if i == args.target:
            continue
        print(f"  i={i:3d}  G={pretty_float(col[i])}")
        printed += 1
        if printed >= args.topK:
            break

    # Onset time stats
    if len(pair_on) == 0:
        print("\nOnset times: no pairs exceeded threshold (try lowering --threshold or increasing --eps).")
    else:
        delays = np.array([t - args.t0 for t in pair_on.values()], dtype=float)
        print("\nOnset time stats for pairs (target -> j) with |G| >= threshold:")
        print(f"  count={len(delays)}  min_delay={delays.min():.6f}  median_delay={np.median(delays):.6f}  max_delay={delays.max():.6f}")

    # Adjacency summary
    num_edges = int(np.sum(adj))
    print(f"\nCausal adjacency (target -> j) within max_delay={args.max_delay}: edges={num_edges}/{args.N-1}")
    if num_edges > 0:
        js = np.where(adj == 1)[0]
        js = js[js != args.target]
        print("  connected js:", js.tolist())

    # Suggested summary line
    # Provide a robust, copy/paste summary that includes the key causality test outcomes
    print("\n" + "=" * 90)
    print("SUGGESTED SUMMARY LINE (COPY/PASTE)")
    print("=" * 90)
    # Make a concise causality verdict from leakage + onsets
    verdict = "PASS" if leak["pre_max_abs"] < (10.0 * args.threshold) else "CHECK"
    # If onsets are empty, call that out
    onset_note = (
        f"{len(pair_on)} pair onsets (thr={args.threshold:g})"
        if len(pair_on) > 0
        else f"no onsets above thr={args.threshold:g}"
    )
    print("ncft_retarded_response_causality_toy.py")
    print(
        "RESULT: Retarded kernel G^R_ij(t)=(C_pert-C_base)/ε extracted from localized impulse at t0; "
        f"pre-t0 leakage max|G|={leak['pre_max_abs']:.3e}; {onset_note}; "
        f"adjacency edges(within Δt<={args.max_delay:g})={num_edges}/{args.N-1}; "
        f"reciprocity score={rec:.3e}"
    )
    print(f"STATUS: ⭐ Time-ordered causality / retarded propagator test ({verdict}) – emergent causal graph extracted")
    print("=" * 90)


if __name__ == "__main__":
    main()
