"""
ncft_axiomatic_closure_operator.py

NCFT — Axiomatic Closure Operator (ACO)
Deterministic, structured listing of pairwise couplings, coupling matrix,
ranked views, and CSV exports. Hard-fails on axiom violations.

This file is intended to be the single formal core object of NCFT.
"""

import numpy as np
from itertools import combinations
from dataclasses import dataclass

EPS = 1e-12


# ============================================================
# Core Data Structures
# ============================================================

@dataclass(frozen=True)
class PairwiseResult:
    field_i: str
    field_j: str
    coupling: float


class ConsciousnessField:
    def __init__(self, field_id: str, state: np.ndarray):
        self.id = field_id
        self.state = self._normalize(state)

    @staticmethod
    def _normalize(psi: np.ndarray) -> np.ndarray:
        norm = np.linalg.norm(psi)
        if norm < EPS:
            raise ValueError("Zero-norm state forbidden by axiom")
        return psi / norm


# ============================================================
# Axiomatic Operators
# ============================================================

def coupling(f1: ConsciousnessField, f2: ConsciousnessField) -> float:
    # Axiom I: Universal Exclusion
    if f1.id == f2.id:
        return 0.0

    # Axiom II: Bounded Bilinear Coupling
    c = abs(np.vdot(f1.state, f2.state)) ** 2
    if c < -EPS or c > 1 + EPS:
        raise AssertionError("Coupling bound violated")

    return float(np.clip(c, 0.0, 1.0))


def compute_pairwise_results(fields):
    results = []
    for f1, f2 in combinations(fields, 2):
        results.append(
            PairwiseResult(
                field_i=f1.id,
                field_j=f2.id,
                coupling=coupling(f1, f2)
            )
        )
    # Deterministic ordering (lexicographic)
    return sorted(results, key=lambda r: (r.field_i, r.field_j))


def coupling_matrix(fields):
    ids = [f.id for f in fields]
    index = {fid: i for i, fid in enumerate(ids)}
    M = np.zeros((len(fields), len(fields)))

    for f1, f2 in combinations(fields, 2):
        c = coupling(f1, f2)
        i, j = index[f1.id], index[f2.id]
        M[i, j] = M[j, i] = c

    return ids, M


def total_coupling(pairwise_results):
    # Axiom IV: Pairwise Dominance
    return sum(r.coupling for r in pairwise_results)


# ============================================================
# Axiomatic Closure Test
# ============================================================

def axiomatic_closure_test(N=10, dim=16, seed=0):
    rng = np.random.default_rng(seed)

    fields = [
        ConsciousnessField(
            f"f{i}",
            rng.normal(size=dim) + 1j * rng.normal(size=dim)
        )
        for i in range(N)
    ]

    # Axiom I: Self-exclusion
    for f in fields:
        assert coupling(f, f) == 0.0

    pairwise = compute_pairwise_results(fields)

    # Axiom III: Frequency Coherence (σ bound)
    couplings = np.array([r.coupling for r in pairwise])
    sigma = float(np.std(couplings))
    assert sigma < 0.1, f"Sigma too large: {sigma}"

    # Axiom IV: Pairwise dominance (non-negativity)
    C_total = total_coupling(pairwise)
    assert C_total >= 0.0

    ids, M = coupling_matrix(fields)

    return {
        "N": N,
        "pairs": len(pairwise),
        "pairwise": pairwise,
        "ids": ids,
        "matrix": M,
        "mean": float(np.mean(couplings)) if len(couplings) else 0.0,
        "sigma": sigma,
        "total_coupling": C_total,
        "status": "AXIOMATIC CLOSURE VERIFIED"
    }


# ============================================================
# Reporting + Export
# ============================================================

def report(result, top_k=10, save_csv=True, prefix="ncft_aco"):
    pairwise = result["pairwise"]
    ids = result["ids"]
    M = result["matrix"]

    print("PAIRWISE COUPLINGS")
    print("------------------")
    for r in pairwise:
        print(f"C({r.field_i},{r.field_j}) = {r.coupling:.6f}")

    print("\nCOUPLING MATRIX")
    print("---------------")
    header = "      " + " ".join(f"{i:>8}" for i in ids)
    print(header)
    for fid, row in zip(ids, M):
        print(f"{fid:>4}  " + " ".join(f"{v:8.4f}" for v in row))

    print("\nSUMMARY")
    print("-------")
    print(f"N fields        : {result['N']}")
    print(f"Pairs           : {result['pairs']}")
    print(f"Mean coupling   : {result['mean']:.6f}")
    print(f"Sigma           : {result['sigma']:.6f}")
    print(f"Total coupling  : {result['total_coupling']:.6f}")
    print(f"Status          : {result['status']}")

    # Ranked views
    ranked = sorted(pairwise, key=lambda r: r.coupling, reverse=True)
    k = min(top_k, len(ranked))

    print("\nTOP COUPLINGS")
    print("------------")
    for r in ranked[:k]:
        print(f"C({r.field_i},{r.field_j}) = {r.coupling:.6f}")

    print("\nBOTTOM COUPLINGS")
    print("---------------")
    for r in reversed(ranked[-k:]):
        print(f"C({r.field_i},{r.field_j}) = {r.coupling:.6f}")

    # CSV export
    if save_csv:
        with open(f"{prefix}_pairwise.csv", "w", encoding="utf-8") as f:
            f.write("field_i,field_j,coupling\n")
            for r in pairwise:
                f.write(f"{r.field_i},{r.field_j},{r.coupling:.12f}\n")

        with open(f"{prefix}_matrix.csv", "w", encoding="utf-8") as f:
            f.write("," + ",".join(ids) + "\n")
            for fid, row in zip(ids, M):
                f.write(fid + "," + ",".join(f"{v:.12f}" for v in row) + "\n")

        print(f"\n✅ WROTE FILES: {prefix}_pairwise.csv, {prefix}_matrix.csv")


# ============================================================
# Main
# ============================================================

if __name__ == "__main__":
    result = axiomatic_closure_test(N=12, dim=16, seed=42)
    report(result)
