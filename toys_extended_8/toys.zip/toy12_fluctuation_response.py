# toy12_fluctuation_response.py
import numpy as np
import matplotlib.pyplot as plt
from ncft import *

N, d, eta = 20, 4, 0.2
psi = random_states(N,d,seed=2)

for _ in range(300):
    psi = flow_step(psi, eta)

C0 = coupling_matrix(psi)

rng = np.random.default_rng(0)
v = rng.normal(size=d) + 1j*rng.normal(size=d)
v /= np.linalg.norm(v)

psi_p = psi.copy()
psi_p[0] = project(psi_p[0] + 1e-3*v)

norms = []
for t in range(150):
    C = coupling_matrix(psi_p)
    norms.append(np.linalg.norm(C - C0))
    psi_p = flow_step(psi_p, eta)

plt.semilogy(norms)
plt.title("Toy 12: response decay")
plt.xlabel("t")
plt.ylabel("||ΔC||")
plt.show()
