# ncft.py
import numpy as np

def project(psi, eps=1e-12):
    psi = np.asarray(psi)
    if psi.ndim == 1:
        n = np.linalg.norm(psi)
        return psi / max(n, eps)
    else:
        n = np.linalg.norm(psi, axis=1, keepdims=True)
        return psi / np.maximum(n, eps)

def random_states(N, d, seed=0):
    rng = np.random.default_rng(seed)
    psi = rng.normal(size=(N,d)) + 1j*rng.normal(size=(N,d))
    return project(psi)

def coupling_matrix(psi):
    G = psi @ psi.conj().T
    C = np.abs(G)**2
    np.fill_diagonal(C, 0.0)
    return C

def energy(psi):
    C = coupling_matrix(psi)
    return -0.5 * C.sum()

def rho_density(psi):
    N = psi.shape[0]
    return (psi.conj().T @ psi) / N

def purity(psi):
    rho = rho_density(psi)
    return float(np.real(np.trace(rho @ rho)))

def purity_identity_error(psi):
    N = psi.shape[0]
    C = coupling_matrix(psi)
    lhs = purity(psi)
    rhs = (N + C.sum()) / (N*N)
    return abs(lhs - rhs)

def flow_step(psi, eta, noise=0.0, gamma=0.0, drive=None, rng=None):
    if rng is None:
        rng = np.random.default_rng()

    G = psi @ psi.conj().T
    interaction = (G.T @ psi) - psi
    delta = eta * interaction

    if gamma != 0:
        delta -= gamma * psi
    if drive is not None:
        delta += drive
    if noise > 0:
        delta += noise * (rng.normal(size=psi.shape) + 1j*rng.normal(size=psi.shape))

    return project(psi + delta)
