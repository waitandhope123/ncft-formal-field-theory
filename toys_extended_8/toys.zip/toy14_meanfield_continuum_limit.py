# toy14_meanfield_continuum_limit.py
import numpy as np
import matplotlib.pyplot as plt
from ncft import *

N, d, eta = 200, 2, 0.15
psi = random_states(N,d,seed=3)

rho_err = []
rho_bar = rho_density(psi)

for t in range(200):
    psi = flow_step(psi, eta)
    rho = rho_density(psi)

    A = np.eye(d) + eta*(N*rho_bar - np.eye(d))
    rho_bar = A @ rho_bar @ A.conj().T
    rho_bar /= np.trace(rho_bar)

    rho_err.append(np.linalg.norm(rho - rho_bar))

plt.semilogy(rho_err)
plt.title("Toy 14: micro vs mean-field error")
plt.xlabel("t")
plt.ylabel("||ρ_micro - ρ_macro||")
plt.show()
