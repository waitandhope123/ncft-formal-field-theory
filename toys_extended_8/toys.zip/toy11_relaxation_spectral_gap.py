# toy11_relaxation_spectral_gap.py
import numpy as np
import matplotlib.pyplot as plt
from ncft import *

def jacobian_fd(psi, eta, eps=1e-6):
    N, d = psi.shape
    x0 = np.concatenate([psi.real.ravel(), psi.imag.ravel()])
    f0 = flow_step(psi, eta)
    f0 = np.concatenate([f0.real.ravel(), f0.imag.ravel()])
    J = np.zeros((len(x0), len(x0)))

    for k in range(len(x0)):
        x = x0.copy()
        x[k] += eps
        psi_k = x[:N*d].reshape(N,d) + 1j*x[N*d:].reshape(N,d)
        psi_k = project(psi_k)
        fk = flow_step(psi_k, eta)
        fk = np.concatenate([fk.real.ravel(), fk.imag.ravel()])
        J[:,k] = (fk - f0) / eps
    return J

N, d, eta = 10, 3, 0.25
psi = random_states(N,d,seed=1)

for _ in range(300):
    psi = flow_step(psi, eta)

J = jacobian_fd(psi, eta)
eig = np.linalg.eigvals(J)
lam = np.sort(np.abs(eig))[::-1]

plt.semilogy(lam[:50], 'o-')
plt.title("Toy 11: Jacobian spectrum")
plt.xlabel("mode index")
plt.ylabel("|λ|")
plt.show()
