# toy15_nonequilibrium_drive_dissipation.py
import numpy as np
import matplotlib.pyplot as plt
from ncft import *

N, d, eta = 30, 4, 0.2
gamma, drive_amp = 0.02, 0.02
rng = np.random.default_rng(4)

psi = random_states(N,d,seed=4)
E = []

for t in range(600):
    drive = drive_amp*(rng.normal(size=(N,d)) + 1j*rng.normal(size=(N,d)))
    psi = flow_step(psi, eta, gamma=gamma, drive=drive)
    E.append(energy(psi))

plt.plot(E)
plt.title("Toy 15: driven steady state energy")
plt.xlabel("t")
plt.ylabel("E")
plt.show()
