# toy13_noise_temperature_scaling.py
import numpy as np
import matplotlib.pyplot as plt
from ncft import *

N, d, eta = 25, 4, 0.2
sigmas = [0, 0.005, 0.01, 0.02, 0.05]

purities = []
for s in sigmas:
    psi = random_states(N,d,seed=1)
    for _ in range(400):
        psi = flow_step(psi, eta, noise=s)
    purities.append(purity(psi))

plt.plot(sigmas, purities, 'o-')
plt.xlabel("noise σ")
plt.ylabel("purity")
plt.title("Toy 13: noise-driven decoherence")
plt.show()
