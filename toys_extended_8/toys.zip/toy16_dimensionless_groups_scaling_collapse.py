# toy16_dimensionless_groups_scaling_collapse.py
import numpy as np
import matplotlib.pyplot as plt
from ncft import *

Ns = [10, 20, 40]
etas = [0.05, 0.1, 0.2]
d = 4

for N in Ns:
    ys = []
    xs = []
    for eta in etas:
        psi = random_states(N,d,seed=int(N*eta*100))
        for _ in range(300):
            psi = flow_step(psi, eta)
        xs.append(eta*(N-1))
        ys.append(coupling_matrix(psi).mean())
    plt.plot(xs, ys, 'o-', label=f"N={N}")

plt.xscale("log")
plt.xlabel("g = η(N−1)")
plt.ylabel("⟨C⟩")
plt.legend()
plt.title("Toy 16: scaling collapse attempt")
plt.show()
