#!/usr/bin/env python3
"""
NCFT Toy 021 — Projection Enforcement vs Intrinsic Stability (QUIET + ROBUST)

Purpose:
- Test whether stability in NCFT-style overlap-gradient dynamics is intrinsic or primarily
  enforced by hard projection (normalization).

Variants:
  1) hard_projection     — normalize every step
  2) delayed_projection  — normalize every k steps
  3) soft_penalty        — no hard projection; add norm-penalty term

Design principle:
- Failures are EXPECTED. This toy records failures and exports JSON deterministically.
- We suppress runtime warnings (overflow/invalid) and instead record numerical health in JSON.

Export schema (kept compatible with GR toy protocol):
{
  "toy_id": "string",
  "theory": "string",
  "spacetime": "string",
  "units": { "G": 1, "c": 1 },
  "parameters": {},
  "notes": {},
  "sample_points": [],
  "observables": {}
}
"""

from __future__ import annotations

import argparse
import json
import math
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def safe_norm(x: np.ndarray) -> float:
    return float(np.linalg.norm(x))


def normalize_or_nan(x: np.ndarray) -> np.ndarray:
    """
    Normalize; if norm is non-finite or too small, return NaN vector.
    (We do NOT crash; we let the run fail and record it.)
    """
    n = safe_norm(x)
    if (not math.isfinite(n)) or (n < 1e-12):
        return np.full_like(x, np.nan)
    return x / n


def deterministic_initial_states(N: int, d: int) -> np.ndarray:
    psi = np.zeros((N, d), dtype=float)
    for i in range(N):
        for j in range(d):
            psi[i, j] = math.sin((i + 1) * (j + 1)) + 0.5 * math.cos((i + 2) * (j + 1))
        psi[i] = normalize_or_nan(psi[i])
    return psi


def all_finite(x: np.ndarray) -> bool:
    return bool(np.all(np.isfinite(x)))


def numerical_health(psi: np.ndarray) -> Dict[str, Any]:
    """
    A compact diagnostic block that replaces noisy runtime warnings.
    """
    finite = all_finite(psi)
    if not finite:
        return {
            "all_finite": False,
            "max_abs_value": None,
            "note": "Non-finite entries detected (nan/inf).",
        }
    max_abs = float(np.max(np.abs(psi)))
    return {
        "all_finite": True,
        "max_abs_value": max_abs,
        "note": "OK" if math.isfinite(max_abs) else "Non-finite max detected.",
    }


# ----------------------------
# NCFT quantities (diagnostics)
# ----------------------------

def gram_matrix(psi: np.ndarray) -> np.ndarray:
    # G_ij = <ψ_i, ψ_j>
    with np.errstate(over="ignore", invalid="ignore"):
        return psi @ psi.T


def coupling_matrix_C(psi: np.ndarray) -> np.ndarray:
    G = gram_matrix(psi)
    with np.errstate(over="ignore", invalid="ignore"):
        C = G * G
    np.fill_diagonal(C, 0.0)
    return C


def F_total(psi: np.ndarray) -> Optional[float]:
    if not all_finite(psi):
        return None
    C = coupling_matrix_C(psi)
    if not np.all(np.isfinite(C)):
        return None
    return float(np.sum(C) / 2.0)


def density_matrix_rho(psi: np.ndarray) -> np.ndarray:
    N, d = psi.shape
    rho = np.zeros((d, d), dtype=float)
    with np.errstate(over="ignore", invalid="ignore"):
        for i in range(N):
            v = psi[i].reshape(-1, 1)
            rho += v @ v.T
        rho /= float(N)
    return rho


def purity_gamma(psi: np.ndarray) -> Optional[float]:
    if not all_finite(psi):
        return None
    rho = density_matrix_rho(psi)
    if not np.all(np.isfinite(rho)):
        return None
    with np.errstate(over="ignore", invalid="ignore"):
        val = float(np.trace(rho @ rho))
    return val if math.isfinite(val) else None


def purity_identity_rhs(psi: np.ndarray) -> Optional[float]:
    if not all_finite(psi):
        return None
    N = psi.shape[0]
    F = F_total(psi)
    if F is None:
        return None
    rhs = (N + 2.0 * F) / (N * N)
    return rhs if math.isfinite(rhs) else None


def purity_error(psi: np.ndarray) -> Optional[float]:
    g = purity_gamma(psi)
    rhs = purity_identity_rhs(psi)
    if g is None or rhs is None:
        return None
    return abs(g - rhs)


def norm_stats(psi: np.ndarray) -> Dict[str, Optional[float]]:
    if not all_finite(psi):
        return {
            "norm_min": None,
            "norm_max": None,
            "norm_mean": None,
            "norm_std": None,
            "max_abs_norm_error_from_1": None,
            "note": "Non-finite psi; norms undefined.",
        }
    norms = np.linalg.norm(psi, axis=1)
    return {
        "norm_min": float(np.min(norms)),
        "norm_max": float(np.max(norms)),
        "norm_mean": float(np.mean(norms)),
        "norm_std": float(np.std(norms)),
        "max_abs_norm_error_from_1": float(np.max(np.abs(norms - 1.0))),
        "note": "OK",
    }


# ----------------------------
# Dynamics
# ----------------------------

def grad_E_pairwise(psi: np.ndarray) -> np.ndarray:
    """
    E = - Σ_{i<j} (<ψ_i,ψ_j>)^2
    grad_E_i = -2 Σ_j G_ij ψ_j
    """
    G = gram_matrix(psi)
    grad = np.zeros_like(psi)
    with np.errstate(over="ignore", invalid="ignore"):
        for i in range(psi.shape[0]):
            grad[i] = -2.0 * np.sum(G[i, :, None] * psi, axis=0)
    return grad


def grad_penalty_norms(psi: np.ndarray, lam: float) -> np.ndarray:
    """
    Penalty: λ Σ_i (||ψ_i||^2 - 1)^2
    grad = 4λ (||ψ_i||^2 - 1) ψ_i
    """
    with np.errstate(over="ignore", invalid="ignore"):
        norms2 = np.sum(psi * psi, axis=1)
        coeff = 4.0 * lam * (norms2 - 1.0)
        return coeff[:, None] * psi


@dataclass
class RunConfig:
    N: int = 20
    d: int = 8
    steps: int = 200
    eta: float = 0.05
    delayed_k: int = 10
    penalty_lambda: float = 10.0
    sample_every: int = 20


def run_variant(name: str, psi0: np.ndarray, cfg: RunConfig) -> Dict[str, Any]:
    psi = psi0.copy()
    sample_points: List[Dict[str, Any]] = []

    def record(t: int) -> None:
        sample_points.append({
            "coordinates": {"t_step": t, "variant": name, "N": cfg.N, "d": cfg.d},
            "curvature_invariants": {
                "purity_gamma": purity_gamma(psi),
                "purity_identity_rhs": purity_identity_rhs(psi),
                "purity_error": purity_error(psi),
                "F_total": F_total(psi),
            },
            "local_observables": {
                "norm_stats": norm_stats(psi),
                "numerical_health": numerical_health(psi),
            },
            "causal_structure": {
                "projection_variant": name,
                "note": "NCFT toy: this field stores enforcement flags (not GR causality).",
            },
        })

    for t in range(cfg.steps + 1):
        if (t % cfg.sample_every) == 0 or (t == cfg.steps):
            record(t)

        # If state already non-finite, fail immediately (after recording)
        if not all_finite(psi):
            return {
                "status": "failed",
                "failure_mode": "non_finite_state",
                "failure_step": t,
                "sample_points": sample_points,
            }

        if t == cfg.steps:
            break

        # Gradient
        grad = grad_E_pairwise(psi)
        if name == "soft_penalty":
            grad = grad + grad_penalty_norms(psi, cfg.penalty_lambda)

        # Euler step
        with np.errstate(over="ignore", invalid="ignore"):
            psi_next = psi - cfg.eta * grad

        # Enforcements
        if name == "hard_projection":
            psi_next = np.array([normalize_or_nan(v) for v in psi_next])

        elif name == "delayed_projection":
            if (t + 1) % cfg.delayed_k == 0:
                psi_next = np.array([normalize_or_nan(v) for v in psi_next])

        elif name == "soft_penalty":
            # No hard projection
            pass

        psi = psi_next

    # Completed
    return {
        "status": "completed",
        "final_F_total": F_total(psi),
        "final_purity": purity_gamma(psi),
        "final_norm_stats": norm_stats(psi),
        "sample_points": sample_points,
    }


# ----------------------------
# Build + Export
# ----------------------------

def build_payload(cfg: RunConfig) -> Dict[str, Any]:
    psi0 = deterministic_initial_states(cfg.N, cfg.d)

    results: Dict[str, Any] = {}
    all_samples: List[Dict[str, Any]] = []

    for variant in ("hard_projection", "delayed_projection", "soft_penalty"):
        out = run_variant(variant, psi0, cfg)
        results[variant] = {k: v for k, v in out.items() if k != "sample_points"}
        all_samples.extend(out.get("sample_points", []))

    return {
        "toy_id": "NCFT-021",
        "theory": "NCFT-core (pairwise overlap objective; enforcement sensitivity test)",
        "spacetime": "State space: (S^{d-1})^N (real surrogate)",
        "units": {"G": 1, "c": 1},
        "parameters": {
            "N": cfg.N,
            "d": cfg.d,
            "steps": cfg.steps,
            "eta": cfg.eta,
            "delayed_k": cfg.delayed_k,
            "penalty_lambda": cfg.penalty_lambda,
            "sample_every": cfg.sample_every,
        },
        "notes": {
            "assumptions": [
                "Deterministic initial conditions (no randomness).",
                "Real-vector surrogate for C^d.",
                "Energy E = -Σ_{i<j}(<ψ_i,ψ_j>)^2; Euler step on gradient flow.",
                "Variants isolate the role of projection enforcement.",
            ],
            "pressure_point": (
                "If stability depends on hard projection, delayed/soft enforcement should develop norm drift, "
                "non-finite states, or qualitatively different invariant behavior."
            ),
            "interpretation": (
                "Warnings are suppressed; numerical issues are recorded in sample_points.local_observables.numerical_health "
                "and variant status."
            ),
        },
        "sample_points": all_samples,
        "observables": {
            "run_summaries_by_variant": results,
        },
    }


def export_json(payload: Dict[str, Any], out_path: Optional[str] = None) -> str:
    if out_path is None:
        out_path = py_to_json_name(__file__)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True)
    return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="NCFT Toy 021: Projection enforcement vs intrinsic stability (quiet).")
    ap.add_argument("--N", type=int, default=20)
    ap.add_argument("--d", type=int, default=8)
    ap.add_argument("--steps", type=int, default=200)
    ap.add_argument("--eta", type=float, default=0.05)
    ap.add_argument("--k", type=int, default=10)
    ap.add_argument("--lam", type=float, default=10.0)
    ap.add_argument("--sample_every", type=int, default=20)
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    cfg = RunConfig(
        N=int(args.N),
        d=int(args.d),
        steps=int(args.steps),
        eta=float(args.eta),
        delayed_k=int(args.k),
        penalty_lambda=float(args.lam),
        sample_every=int(args.sample_every),
    )

    payload = build_payload(cfg)
    out_path = args.out.strip() or None
    json_path = export_json(payload, out_path=out_path)

    print(f"Wrote {json_path}")
    for variant, summary in payload["observables"]["run_summaries_by_variant"].items():
        print(f"{variant} -> {summary.get('status')}")

if __name__ == "__main__":
    main()
