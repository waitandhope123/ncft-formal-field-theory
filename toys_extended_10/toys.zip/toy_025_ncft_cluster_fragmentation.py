#!/usr/bin/env python3
"""
NCFT Toy 025 — Cluster Fragmentation Under Incoherence

Purpose:
- Detect whether NCFT develops *cluster structure* (multiple internally aligned groups)
  when frequency coherence fails, rather than always collapsing to global alignment.

Builds on:
- Toy 024 (ψ + ω co-evolution via coupling backreaction)
- Adds graph/cluster diagnostics on the coupling matrix C_ij.

Model:
- States: ψ_i ∈ R^d, hard-projected (normalized) every step.
- Coupling: C_ij = (<ψ_i, ψ_j>)^2, with C_ii = 0.
- ψ update: ψ <- ψ - η*(ω_i * grad_E_i), then normalize.
  where E = -Σ_{i<j} C_ij (so descending E increases alignment).
- ω update (backreaction):
    ω_i <- clip( ω_i + ε*(c_i - mean(c)), [omega_min, omega_max] )
  where c_i = mean_{j≠i} C_ij.

Cluster diagnostics:
- Build adjacency A_ij = 1 if C_ij >= tau (for i≠j).
- Compute connected components (clusters) from A.
- Report:
    - num_clusters
    - largest_cluster_frac
    - modularity_proxy = mean_intra(C) - mean_inter(C)
    - coherence flag (Axiom-3 style): sigma_omega < 0.1*mean_omega

Determinism:
- No randomness (ψ and ω init deterministic).

Output:
- JSON written to <script>.json with per-run results and time samples.

Recommended filename:
  toy_025_ncft_cluster_fragmentation.py
"""

from __future__ import annotations

import argparse
import json
import math
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def normalize(x: np.ndarray) -> np.ndarray:
    n = float(np.linalg.norm(x))
    if (not math.isfinite(n)) or (n < 1e-12):
        return np.full_like(x, np.nan)
    return x / n


def all_finite(x: np.ndarray) -> bool:
    return bool(np.all(np.isfinite(x)))


def deterministic_initial_states(N: int, d: int) -> np.ndarray:
    psi = np.zeros((N, d), dtype=float)
    for i in range(N):
        for j in range(d):
            psi[i, j] = math.sin((i + 1) * (j + 1)) + 0.25 * math.cos((i + 2) * (j + 1))
        psi[i] = normalize(psi[i])
    return psi


def deterministic_frequencies(N: int, omega_mean: float, sigma: float) -> np.ndarray:
    if N == 1:
        return np.array([omega_mean], dtype=float)
    return np.linspace(omega_mean - sigma, omega_mean + sigma, N).astype(float)


# ----------------------------
# Core NCFT quantities
# ----------------------------

def gram_matrix(psi: np.ndarray) -> np.ndarray:
    return psi @ psi.T


def coupling_matrix(psi: np.ndarray) -> np.ndarray:
    G = gram_matrix(psi)
    C = G * G
    np.fill_diagonal(C, 0.0)
    return C


def F_total(C: np.ndarray) -> float:
    return float(np.sum(C) / 2.0)


def node_mean_coupling(C: np.ndarray) -> np.ndarray:
    N = C.shape[0]
    if N <= 1:
        return np.zeros((N,), dtype=float)
    return np.sum(C, axis=1) / float(N - 1)


def density_matrix(psi: np.ndarray) -> np.ndarray:
    N, d = psi.shape
    rho = np.zeros((d, d), dtype=float)
    for i in range(N):
        v = psi[i].reshape(-1, 1)
        rho += v @ v.T
    return rho / float(N)


def purity(psi: np.ndarray) -> Optional[float]:
    if not all_finite(psi):
        return None
    rho = density_matrix(psi)
    val = float(np.trace(rho @ rho))
    return val if math.isfinite(val) else None


def omega_stats(omega: np.ndarray) -> Dict[str, Optional[float]]:
    if not all_finite(omega):
        return {"mean": None, "sigma": None, "delta": None, "coherent": None}
    m = float(np.mean(omega))
    s = float(np.std(omega))
    delta = 0.1 * m
    coherent = (s < delta) if math.isfinite(delta) else None
    return {"mean": m, "sigma": s, "delta": delta, "coherent": bool(coherent) if coherent is not None else None}


# ----------------------------
# Gradient
# ----------------------------

def grad_E_pairwise(psi: np.ndarray) -> np.ndarray:
    """
    E = - Σ_{i<j} (<ψ_i,ψ_j>)^2
    grad_E_i = -2 Σ_j G_ij ψ_j
    """
    G = gram_matrix(psi)
    grad = np.zeros_like(psi)
    for i in range(psi.shape[0]):
        grad[i] = -2.0 * np.sum(G[i, :, None] * psi, axis=0)
    return grad


# ----------------------------
# Cluster detection
# ----------------------------

def connected_components_from_adjacency(A: np.ndarray) -> List[List[int]]:
    """
    A: (N,N) adjacency with 0/1 entries and A_ii = 0.
    Returns list of components, each as list of node indices.
    """
    N = A.shape[0]
    visited = np.zeros(N, dtype=bool)
    comps: List[List[int]] = []

    for start in range(N):
        if visited[start]:
            continue
        # BFS/DFS
        stack = [start]
        visited[start] = True
        comp = [start]
        while stack:
            u = stack.pop()
            nbrs = np.where(A[u] > 0)[0]
            for v in nbrs:
                if not visited[v]:
                    visited[v] = True
                    stack.append(v)
                    comp.append(int(v))
        comps.append(comp)

    # sort comps by size desc for stable output
    comps.sort(key=lambda c: (-len(c), c[0]))
    return comps


def cluster_metrics(C: np.ndarray, tau: float) -> Dict[str, Any]:
    """
    Compute cluster metrics from coupling matrix C using threshold tau.
    """
    N = C.shape[0]
    # adjacency by strong coupling
    A = (C >= tau).astype(int)
    np.fill_diagonal(A, 0)

    comps = connected_components_from_adjacency(A)
    sizes = [len(c) for c in comps]
    num_clusters = len(comps)
    largest_frac = float(max(sizes) / N) if N > 0 else None

    # intra vs inter coupling means
    # define labels by component index
    labels = np.zeros(N, dtype=int)
    for k, comp in enumerate(comps):
        for i in comp:
            labels[i] = k

    intra_vals = []
    inter_vals = []
    for i in range(N):
        for j in range(i + 1, N):
            if labels[i] == labels[j]:
                intra_vals.append(C[i, j])
            else:
                inter_vals.append(C[i, j])

    mean_intra = float(np.mean(intra_vals)) if intra_vals else 0.0
    mean_inter = float(np.mean(inter_vals)) if inter_vals else 0.0
    modularity_proxy = mean_intra - mean_inter

    return {
        "tau": tau,
        "num_clusters": int(num_clusters),
        "cluster_sizes": sizes,
        "largest_cluster_frac": largest_frac,
        "mean_intra_C": mean_intra,
        "mean_inter_C": mean_inter,
        "modularity_proxy": modularity_proxy,
    }


# ----------------------------
# Toy runner
# ----------------------------

@dataclass
class Config:
    N: int = 20
    d: int = 8
    steps: int = 300
    eta: float = 0.05
    omega_mean: float = 1.0
    omega_min: float = 0.1
    omega_max: float = 10.0
    sample_every: int = 20


def run_case(cfg: Config, sigma_ratio: float, eps_backreaction: float, tau: float) -> Dict[str, Any]:
    psi = deterministic_initial_states(cfg.N, cfg.d)

    sigma = sigma_ratio * cfg.omega_mean
    omega = deterministic_frequencies(cfg.N, cfg.omega_mean, sigma)
    omega = np.clip(omega, cfg.omega_min, cfg.omega_max)

    history: List[Dict[str, Any]] = []
    first_coherent_step: Optional[int] = None

    for t in range(cfg.steps + 1):
        if not all_finite(psi) or not all_finite(omega):
            return {
                "sigma_ratio": sigma_ratio,
                "eps_backreaction": eps_backreaction,
                "tau": tau,
                "status": "failed",
                "failure_step": t,
                "history": history,
                "note": "Non-finite state encountered.",
            }

        C = coupling_matrix(psi)
        Ft = F_total(C)
        pt = purity(psi)
        ost = omega_stats(omega)
        cm = cluster_metrics(C, tau=tau)

        if (t % cfg.sample_every) == 0 or (t == cfg.steps):
            history.append({
                "t": t,
                "F_total": Ft,
                "F_saturation_ratio": float(Ft / (cfg.N * (cfg.N - 1) / 2.0)) if cfg.N > 1 else None,
                "purity": pt,
                "omega": {
                    "mean": ost["mean"],
                    "sigma": ost["sigma"],
                    "delta": ost["delta"],
                    "coherent": ost["coherent"],
                    "min": float(np.min(omega)),
                    "max": float(np.max(omega)),
                },
                "clusters": cm,
            })

        if ost["coherent"] is True and first_coherent_step is None:
            first_coherent_step = t

        if t == cfg.steps:
            break

        # --- ψ update (ω-weighted) ---
        grad = grad_E_pairwise(psi)
        psi = psi - cfg.eta * (omega[:, None] * grad)
        psi = np.array([normalize(v) for v in psi])

        # --- ω backreaction update ---
        if eps_backreaction != 0.0:
            C_after = coupling_matrix(psi)
            c = node_mean_coupling(C_after)
            c_mean = float(np.mean(c)) if math.isfinite(float(np.mean(c))) else 0.0
            omega = omega + eps_backreaction * (c - c_mean)
            omega = np.clip(omega, cfg.omega_min, cfg.omega_max)

    # Final summary
    C_final = coupling_matrix(psi)
    Ft_final = F_total(C_final)
    pt_final = purity(psi)
    ost_final = omega_stats(omega)
    cm_final = cluster_metrics(C_final, tau=tau)

    F_max = cfg.N * (cfg.N - 1) / 2.0
    sat = float(Ft_final / F_max) if F_max > 0 else None

    return {
        "sigma_ratio": sigma_ratio,
        "eps_backreaction": eps_backreaction,
        "tau": tau,
        "status": "completed",
        "final": {
            "F_total": Ft_final,
            "F_saturation_ratio": sat,
            "purity": pt_final,
            "omega": {
                "mean": ost_final["mean"],
                "sigma": ost_final["sigma"],
                "delta": ost_final["delta"],
                "coherent": ost_final["coherent"],
                "min": float(np.min(omega)),
                "max": float(np.max(omega)),
            },
            "clusters": cm_final,
            "first_coherent_step": first_coherent_step,
        },
        "history": history,
    }


def build_payload(cfg: Config, sigma_ratios: List[float], epsilons: List[float], taus: List[float]) -> Dict[str, Any]:
    results: List[Dict[str, Any]] = []
    for tau in taus:
        for eps in epsilons:
            for sr in sigma_ratios:
                results.append(run_case(cfg, sigma_ratio=sr, eps_backreaction=eps, tau=tau))

    return {
        "toy_id": "NCFT-025",
        "theory": "NCFT-core (hard projection) + ω backreaction + cluster diagnostics",
        "spacetime": "State space: (S^{d-1})^N (real surrogate) with ω co-evolution; clusters from C_ij threshold graph",
        "units": {"G": 1, "c": 1},
        "parameters": {
            "N": cfg.N,
            "d": cfg.d,
            "steps": cfg.steps,
            "eta": cfg.eta,
            "omega_mean": cfg.omega_mean,
            "omega_min": cfg.omega_min,
            "omega_max": cfg.omega_max,
            "sample_every": cfg.sample_every,
            "sigma_ratios": sigma_ratios,
            "epsilons": epsilons,
            "taus": taus,
        },
        "notes": {
            "pressure_point": (
                "When coherence fails (sigma_omega >= 0.1*mean_omega), does the coupling network develop "
                "multiple strong-coupling clusters rather than global alignment?"
            ),
            "cluster_rule": "Adjacency A_ij = 1 if C_ij >= tau (i≠j). Clusters are connected components of A.",
            "cluster_metrics": [
                "num_clusters",
                "largest_cluster_frac",
                "modularity_proxy = mean_intra(C) - mean_inter(C)",
            ],
            "interpretation": (
                "If clusters emerge, NCFT has nontrivial phase structure beyond 'everything aligns'. "
                "If num_clusters→1 and modularity_proxy→0 while F saturates, dynamics are globally attractive."
            ),
        },
        "results": results,
    }


# ----------------------------
# CLI
# ----------------------------

def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def main() -> None:
    ap = argparse.ArgumentParser(description="NCFT Toy 025: cluster fragmentation diagnostics.")
    ap.add_argument("--N", type=int, default=20)
    ap.add_argument("--d", type=int, default=8)
    ap.add_argument("--steps", type=int, default=300)
    ap.add_argument("--eta", type=float, default=0.05)
    ap.add_argument("--omega_mean", type=float, default=1.0)
    ap.add_argument("--omega_min", type=float, default=0.1)
    ap.add_argument("--omega_max", type=float, default=10.0)
    ap.add_argument("--sigma_ratios", type=str, default="0.0,0.1,0.2,0.3,0.5")
    ap.add_argument("--epsilons", type=str, default="0.0,0.01,0.05,0.1")
    ap.add_argument("--taus", type=str, default="0.90,0.95,0.98")
    ap.add_argument("--sample_every", type=int, default=20)
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    sigma_ratios = parse_csv_floats(args.sigma_ratios)
    epsilons = parse_csv_floats(args.epsilons)
    taus = parse_csv_floats(args.taus)

    cfg = Config(
        N=int(args.N),
        d=int(args.d),
        steps=int(args.steps),
        eta=float(args.eta),
        omega_mean=float(args.omega_mean),
        omega_min=float(args.omega_min),
        omega_max=float(args.omega_max),
        sample_every=int(args.sample_every),
    )

    payload = build_payload(cfg, sigma_ratios=sigma_ratios, epsilons=epsilons, taus=taus)

    out_path = args.out.strip() or py_to_json_name(__file__)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

    print(f"Wrote {out_path}")

    # Compact summary: final cluster count and largest cluster fraction for each run
    for tau in taus:
        for eps in epsilons:
            for sr in sigma_ratios:
                r = next(x for x in payload["results"]
                         if x["tau"] == tau and x["eps_backreaction"] == eps and x["sigma_ratio"] == sr)
                if r["status"] != "completed":
                    print(f"tau={tau:.2f} eps={eps:>5.2f} σ/ω={sr:>4.2f} -> FAILED at t={r.get('failure_step')}")
                    continue
                fin = r["final"]
                cl = fin["clusters"]
                coh = fin["omega"]["coherent"]
                print(
                    f"tau={tau:.2f} eps={eps:>5.2f} σ/ω={sr:>4.2f} "
                    f"coh={str(coh):>5} clusters={cl['num_clusters']:>2} "
                    f"largest={cl['largest_cluster_frac']:.2f} mod={cl['modularity_proxy']:.3f} "
                    f"sat={fin['F_saturation_ratio']:.3f}"
                )

if __name__ == "__main__":
    main()
