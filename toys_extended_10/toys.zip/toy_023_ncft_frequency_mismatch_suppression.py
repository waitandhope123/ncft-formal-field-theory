#!/usr/bin/env python3
"""
NCFT Toy 023 — Frequency-Mismatch Suppression (Coherence becomes operational)

Purpose:
- Make frequency coherence (Axiom 3) matter dynamically by suppressing pairwise coupling
  when frequencies mismatch.

Model:
- States: ψ_i ∈ R^d, projected to unit norm every step (hard projection enforced).
- Weighted objective:
    F_beta = Σ_{i<j} w_ij(ω) * (<ψ_i, ψ_j>)^2
    w_ij = exp( -β * ((ω_i - ω_j)/ω_mean)^2 )
- Energy: E = -F_beta
- Gradient flow (Euler step):
    ψ <- ψ - η ∇E, then normalize each ψ_i

Sweep:
- σ/ω_mean values and β values.
- Report whether the system saturates (F close to max), and final purity.

Determinism:
- No randomness. Initial ψ_i and ω_i are deterministic.

Output:
- Writes JSON: toy_023_ncft_frequency_mismatch_suppression.json
"""

from __future__ import annotations

import argparse
import json
import math
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def normalize(x: np.ndarray) -> np.ndarray:
    n = float(np.linalg.norm(x))
    if (not math.isfinite(n)) or (n < 1e-12):
        return np.full_like(x, np.nan)
    return x / n


def deterministic_initial_states(N: int, d: int) -> np.ndarray:
    psi = np.zeros((N, d), dtype=float)
    for i in range(N):
        for j in range(d):
            psi[i, j] = math.sin((i + 1) * (j + 1)) + 0.25 * math.cos((i + 2) * (j + 1))
        psi[i] = normalize(psi[i])
    return psi


def deterministic_frequencies(N: int, omega_mean: float, sigma: float) -> np.ndarray:
    # Deterministic spread around mean
    if N == 1:
        return np.array([omega_mean], dtype=float)
    return np.linspace(omega_mean - sigma, omega_mean + sigma, N).astype(float)


def all_finite(x: np.ndarray) -> bool:
    return bool(np.all(np.isfinite(x)))


def gram_matrix(psi: np.ndarray) -> np.ndarray:
    return psi @ psi.T


def density_matrix(psi: np.ndarray) -> np.ndarray:
    N, d = psi.shape
    rho = np.zeros((d, d), dtype=float)
    for i in range(N):
        v = psi[i].reshape(-1, 1)
        rho += v @ v.T
    return rho / float(N)


def purity(psi: np.ndarray) -> Optional[float]:
    if not all_finite(psi):
        return None
    rho = density_matrix(psi)
    val = float(np.trace(rho @ rho))
    return val if math.isfinite(val) else None


# ----------------------------
# Weighted objective + gradient
# ----------------------------

def weight_matrix(omegas: np.ndarray, beta: float) -> np.ndarray:
    """
    w_ij = exp( -beta * ((ω_i - ω_j)/ω_mean)^2 )
    with w_ii=0
    """
    w = omegas.reshape(-1, 1)
    w_mean = float(np.mean(omegas))
    denom = w_mean if abs(w_mean) > 1e-12 else 1.0
    d_ij = (w - w.T) / denom
    W = np.exp(-beta * (d_ij ** 2))
    np.fill_diagonal(W, 0.0)
    return W


def F_weighted(psi: np.ndarray, W: np.ndarray) -> Optional[float]:
    if not all_finite(psi):
        return None
    G = gram_matrix(psi)
    C = G * G
    np.fill_diagonal(C, 0.0)
    val = float(np.sum(W * C) / 2.0)
    return val if math.isfinite(val) else None


def grad_E_weighted(psi: np.ndarray, W: np.ndarray) -> np.ndarray:
    """
    E = - Σ_{i<j} W_ij * (G_ij)^2

    For real ψ:
      ∂/∂ψ_i [ - W_ij * (G_ij)^2 ] = -2 W_ij G_ij ψ_j

    Thus:
      grad_E_i = -2 Σ_j W_ij G_ij ψ_j
    """
    G = gram_matrix(psi)
    WG = W * G  # elementwise
    grad = np.zeros_like(psi)
    for i in range(psi.shape[0]):
        grad[i] = -2.0 * np.sum(WG[i, :, None] * psi, axis=0)
    return grad


# ----------------------------
# Toy runner
# ----------------------------

@dataclass
class Config:
    N: int = 20
    d: int = 8
    steps: int = 200
    eta: float = 0.05
    omega_mean: float = 1.0
    sigma_ratios: List[float] = None
    betas: List[float] = None
    sample_every: int = 20


def run_case(cfg: Config, sigma_ratio: float, beta: float) -> Dict[str, Any]:
    psi = deterministic_initial_states(cfg.N, cfg.d)

    sigma = sigma_ratio * cfg.omega_mean
    omegas = deterministic_frequencies(cfg.N, cfg.omega_mean, sigma)
    W = weight_matrix(omegas, beta=beta)

    history = []
    for t in range(cfg.steps + 1):
        history.append({
            "t": t,
            "F_weighted": F_weighted(psi, W),
            "purity": purity(psi),
        })

        if not all_finite(psi):
            return {
                "sigma_ratio": sigma_ratio,
                "beta": beta,
                "status": "failed",
                "failure_step": t,
                "note": "Non-finite ψ encountered.",
                "history": history,
            }

        if t == cfg.steps:
            break

        grad = grad_E_weighted(psi, W)
        psi = psi - cfg.eta * grad
        psi = np.array([normalize(v) for v in psi])

    # Diagnostics: compare to the maximum possible weighted sum if perfectly aligned.
    # If perfectly aligned: G_ij = 1 => (G_ij)^2 = 1, so F_max_weighted = Σ_{i<j} W_ij
    W_upper = float(np.sum(W) / 2.0)

    final_F = F_weighted(psi, W)
    final_p = purity(psi)

    sat_ratio = None
    if final_F is not None and W_upper > 1e-12:
        sat_ratio = float(final_F / W_upper)

    return {
        "sigma_ratio": sigma_ratio,
        "beta": beta,
        "status": "completed",
        "final_F_weighted": final_F,
        "final_purity": final_p,
        "W_upper_sum": W_upper,
        "saturation_ratio": sat_ratio,
        "history": history,
    }


def build_payload(cfg: Config) -> Dict[str, Any]:
    results = []
    for beta in cfg.betas:
        for sr in cfg.sigma_ratios:
            results.append(run_case(cfg, sigma_ratio=sr, beta=beta))

    return {
        "toy_id": "NCFT-023",
        "theory": "NCFT-core (hard projection) + frequency-mismatch coupling suppression",
        "spacetime": "State space: (S^{d-1})^N (real surrogate)",
        "units": {"G": 1, "c": 1},
        "parameters": {
            "N": cfg.N,
            "d": cfg.d,
            "steps": cfg.steps,
            "eta": cfg.eta,
            "omega_mean": cfg.omega_mean,
            "sigma_ratios": cfg.sigma_ratios,
            "betas": cfg.betas,
            "sample_every": cfg.sample_every,
        },
        "notes": {
            "pressure_point": (
                "Coherence becomes operational by suppressing coupling across frequency mismatch. "
                "As σ/ω increases (or β increases), alignment should weaken and saturation_ratio should drop."
            ),
            "definitions": {
                "W_ij": "exp(-beta*((omega_i-omega_j)/mean(omega))^2), W_ii=0",
                "F_weighted": "Σ_{i<j} W_ij * (<ψ_i,ψ_j>)^2",
                "saturation_ratio": "final_F_weighted / Σ_{i<j} W_ij  (1.0 = perfect weighted alignment)",
            },
        },
        "results": results,
    }


def main() -> None:
    ap = argparse.ArgumentParser(description="NCFT Toy 023: Frequency mismatch suppression sweep.")
    ap.add_argument("--N", type=int, default=20)
    ap.add_argument("--d", type=int, default=8)
    ap.add_argument("--steps", type=int, default=200)
    ap.add_argument("--eta", type=float, default=0.05)
    ap.add_argument("--omega_mean", type=float, default=1.0)
    ap.add_argument("--sigma_ratios", type=str, default="0.0,0.05,0.1,0.2,0.3,0.5")
    ap.add_argument("--betas", type=str, default="0.0,1.0,5.0,20.0")
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    sigma_ratios = [float(x.strip()) for x in args.sigma_ratios.split(",") if x.strip()]
    betas = [float(x.strip()) for x in args.betas.split(",") if x.strip()]

    cfg = Config(
        N=int(args.N),
        d=int(args.d),
        steps=int(args.steps),
        eta=float(args.eta),
        omega_mean=float(args.omega_mean),
        sigma_ratios=sigma_ratios,
        betas=betas,
        sample_every=20,
    )

    payload = build_payload(cfg)
    out_path = args.out.strip() or None
    json_path = py_to_json_name(__file__) if out_path is None else out_path

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

    print(f"Wrote {json_path}")
    # Print a compact summary table
    for beta in betas:
        for sr in sigma_ratios:
            r = next(x for x in payload["results"] if x["beta"] == beta and x["sigma_ratio"] == sr)
            sat = r.get("saturation_ratio")
            sat_s = "None" if sat is None else f"{sat:.3f}"
            print(f"beta={beta:>5.1f}  σ/ω={sr:>4.2f}  status={r['status']:>9}  sat={sat_s}")

if __name__ == "__main__":
    main()
