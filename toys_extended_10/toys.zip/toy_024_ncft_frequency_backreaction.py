#!/usr/bin/env python3
"""
NCFT Toy 024 — Frequency Backreaction (ω evolves)

Purpose:
- Make frequency coherence operational by allowing ω_i to evolve in response to coupling.
- Projection is enforced every step (NCFT-valid manifold).
- This toy tests whether coherence emerges, fragments, or remains neutral.

Model:
- States: ψ_i ∈ R^d, normalized every step.
- Coupling: C_ij = (<ψ_i, ψ_j>)^2, with C_ii = 0.
- ψ dynamics (weighted by ω):
    ψ <- ψ - η * (ω_i * grad_E_i), then normalize
  where E = - Σ_{i<j} C_ij (so descending E increases alignment).
- ω backreaction dynamics:
    ω_i <- clamp( ω_i + ε * (c_i - mean(c)) )
  where c_i = (1/(N-1)) Σ_{j≠i} C_ij is node i's mean coupling.
  This preserves mean ω approximately (exact if unclamped).

Sweeps:
- Initial σ/ω_mean ratios
- ε (backreaction strength)

Outputs:
- JSON with per-run summaries + sampled time series
- "coherent" flag per step: sigma_omega < 0.1 * mean_omega

Determinism:
- No randomness. ψ and ω initializations are deterministic.

Run:
  py toy_024_ncft_frequency_backreaction.py
"""

from __future__ import annotations

import argparse
import json
import math
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def normalize(x: np.ndarray) -> np.ndarray:
    n = float(np.linalg.norm(x))
    if (not math.isfinite(n)) or (n < 1e-12):
        return np.full_like(x, np.nan)
    return x / n


def all_finite(x: np.ndarray) -> bool:
    return bool(np.all(np.isfinite(x)))


def deterministic_initial_states(N: int, d: int) -> np.ndarray:
    psi = np.zeros((N, d), dtype=float)
    for i in range(N):
        for j in range(d):
            psi[i, j] = math.sin((i + 1) * (j + 1)) + 0.25 * math.cos((i + 2) * (j + 1))
        psi[i] = normalize(psi[i])
    return psi


def deterministic_frequencies(N: int, omega_mean: float, sigma: float) -> np.ndarray:
    # Deterministic spread around mean
    if N == 1:
        return np.array([omega_mean], dtype=float)
    return np.linspace(omega_mean - sigma, omega_mean + sigma, N).astype(float)


# ----------------------------
# NCFT core quantities
# ----------------------------

def gram_matrix(psi: np.ndarray) -> np.ndarray:
    return psi @ psi.T


def coupling_matrix(psi: np.ndarray) -> np.ndarray:
    G = gram_matrix(psi)
    C = G * G
    np.fill_diagonal(C, 0.0)
    return C


def F_total(C: np.ndarray) -> float:
    return float(np.sum(C) / 2.0)


def node_mean_coupling(C: np.ndarray) -> np.ndarray:
    # c_i = mean_{j≠i} C_ij
    N = C.shape[0]
    if N <= 1:
        return np.zeros((N,), dtype=float)
    return np.sum(C, axis=1) / float(N - 1)


def density_matrix(psi: np.ndarray) -> np.ndarray:
    N, d = psi.shape
    rho = np.zeros((d, d), dtype=float)
    for i in range(N):
        v = psi[i].reshape(-1, 1)
        rho += v @ v.T
    return rho / float(N)


def purity(psi: np.ndarray) -> Optional[float]:
    if not all_finite(psi):
        return None
    rho = density_matrix(psi)
    val = float(np.trace(rho @ rho))
    return val if math.isfinite(val) else None


def omega_stats(omega: np.ndarray) -> Dict[str, Optional[float]]:
    if not all_finite(omega):
        return {"mean": None, "sigma": None, "delta": None, "coherent": None}
    m = float(np.mean(omega))
    s = float(np.std(omega))
    delta = 0.1 * m
    return {
        "mean": m,
        "sigma": s,
        "delta": delta,
        "coherent": bool(s < delta) if math.isfinite(delta) else None,
    }


# ----------------------------
# Gradients
# ----------------------------

def grad_E_pairwise(psi: np.ndarray) -> np.ndarray:
    """
    E = - Σ_{i<j} (<ψ_i,ψ_j>)^2
    grad_E_i = -2 Σ_j G_ij ψ_j
    """
    G = gram_matrix(psi)
    grad = np.zeros_like(psi)
    for i in range(psi.shape[0]):
        grad[i] = -2.0 * np.sum(G[i, :, None] * psi, axis=0)
    return grad


# ----------------------------
# Toy runner
# ----------------------------

@dataclass
class Config:
    N: int = 20
    d: int = 8
    steps: int = 300
    eta: float = 0.05          # ψ step size
    omega_mean: float = 1.0
    omega_min: float = 0.1     # clamp floor to keep ω positive
    omega_max: float = 10.0    # clamp ceiling to avoid runaway
    sample_every: int = 20


def run_case(cfg: Config, sigma_ratio: float, eps_backreaction: float) -> Dict[str, Any]:
    psi = deterministic_initial_states(cfg.N, cfg.d)

    sigma = sigma_ratio * cfg.omega_mean
    omega = deterministic_frequencies(cfg.N, cfg.omega_mean, sigma)
    omega = np.clip(omega, cfg.omega_min, cfg.omega_max)

    history: List[Dict[str, Any]] = []
    first_coherent_step: Optional[int] = None

    for t in range(cfg.steps + 1):

        if not all_finite(psi) or not all_finite(omega):
            return {
                "sigma_ratio": sigma_ratio,
                "eps_backreaction": eps_backreaction,
                "status": "failed",
                "failure_step": t,
                "history": history,
                "note": "Non-finite state encountered.",
            }

        C = coupling_matrix(psi)
        Ft = F_total(C)
        pt = purity(psi)
        ost = omega_stats(omega)

        if (t % cfg.sample_every) == 0 or (t == cfg.steps):
            history.append({
                "t": t,
                "F_total": Ft,
                "purity": pt,
                "omega": {
                    "mean": ost["mean"],
                    "sigma": ost["sigma"],
                    "delta": ost["delta"],
                    "coherent": ost["coherent"],
                    "min": float(np.min(omega)),
                    "max": float(np.max(omega)),
                },
            })

        if ost["coherent"] is True and first_coherent_step is None:
            first_coherent_step = t

        if t == cfg.steps:
            break

        # --- ψ update (ω-weighted) ---
        grad = grad_E_pairwise(psi)  # shape (N,d)
        psi = psi - cfg.eta * (omega[:, None] * grad)
        psi = np.array([normalize(v) for v in psi])

        if not all_finite(psi):
            # will be caught next loop, but we can early exit too
            continue

        # --- ω backreaction update ---
        # c_i is how strongly node i is currently coupled to others
        C_after = coupling_matrix(psi)
        c = node_mean_coupling(C_after)
        c_mean = float(np.mean(c)) if math.isfinite(float(np.mean(c))) else 0.0

        # backreaction: nodes with higher-than-average coupling drift upward in ω
        omega = omega + eps_backreaction * (c - c_mean)

        # clamp to keep ω reasonable/positive (documented!)
        omega = np.clip(omega, cfg.omega_min, cfg.omega_max)

    # End summary
    C_final = coupling_matrix(psi)
    F_final = F_total(C_final)
    p_final = purity(psi)
    ost_final = omega_stats(omega)

    # Max possible coupling for N nodes is N(N-1)/2
    F_max = cfg.N * (cfg.N - 1) / 2.0
    saturation = float(F_final / F_max) if F_max > 0 else None

    return {
        "sigma_ratio": sigma_ratio,
        "eps_backreaction": eps_backreaction,
        "status": "completed",
        "final": {
            "F_total": F_final,
            "F_saturation_ratio": saturation,
            "purity": p_final,
            "omega": {
                "mean": ost_final["mean"],
                "sigma": ost_final["sigma"],
                "delta": ost_final["delta"],
                "coherent": ost_final["coherent"],
                "min": float(np.min(omega)),
                "max": float(np.max(omega)),
            },
            "first_coherent_step": first_coherent_step,
        },
        "history": history,
    }


def build_payload(cfg: Config, sigma_ratios: List[float], epsilons: List[float]) -> Dict[str, Any]:
    results: List[Dict[str, Any]] = []
    for eps in epsilons:
        for sr in sigma_ratios:
            results.append(run_case(cfg, sigma_ratio=sr, eps_backreaction=eps))

    return {
        "toy_id": "NCFT-024",
        "theory": "NCFT-core (hard projection) + frequency backreaction",
        "spacetime": "State space: (S^{d-1})^N (real surrogate) with ω co-evolution",
        "units": {"G": 1, "c": 1},
        "parameters": {
            "N": cfg.N,
            "d": cfg.d,
            "steps": cfg.steps,
            "eta": cfg.eta,
            "omega_mean": cfg.omega_mean,
            "omega_min": cfg.omega_min,
            "omega_max": cfg.omega_max,
            "sample_every": cfg.sample_every,
            "sigma_ratios": sigma_ratios,
            "epsilons": epsilons,
        },
        "notes": {
            "pressure_point": (
                "Frequency coherence becomes dynamical: ω evolves via coupling backreaction. "
                "This tests whether coherence emerges, fragments into clusters, or stays neutral."
            ),
            "omega_update": "ω_i <- clip(ω_i + ε*(c_i - mean(c)), [omega_min, omega_max]) where c_i = mean_j C_ij",
            "psi_update": "ψ <- ψ - η * (ω_i * grad_E_i), then normalize each ψ_i",
            "interpretation": (
                "If Axiom 3 is meaningful dynamically, higher σ/ω should either self-cohere (σ decreases) "
                "or show structured failure/fragmentation. If nothing changes, coherence is just a label."
            ),
        },
        "results": results,
    }


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="NCFT Toy 024: frequency backreaction sweep.")
    ap.add_argument("--N", type=int, default=20)
    ap.add_argument("--d", type=int, default=8)
    ap.add_argument("--steps", type=int, default=300)
    ap.add_argument("--eta", type=float, default=0.05)
    ap.add_argument("--omega_mean", type=float, default=1.0)
    ap.add_argument("--omega_min", type=float, default=0.1)
    ap.add_argument("--omega_max", type=float, default=10.0)
    ap.add_argument("--sigma_ratios", type=str, default="0.0,0.1,0.2,0.3,0.5")
    ap.add_argument("--epsilons", type=str, default="0.0,0.01,0.05,0.1")
    ap.add_argument("--sample_every", type=int, default=20)
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    sigma_ratios = [float(x.strip()) for x in args.sigma_ratios.split(",") if x.strip()]
    epsilons = [float(x.strip()) for x in args.epsilons.split(",") if x.strip()]

    cfg = Config(
        N=int(args.N),
        d=int(args.d),
        steps=int(args.steps),
        eta=float(args.eta),
        omega_mean=float(args.omega_mean),
        omega_min=float(args.omega_min),
        omega_max=float(args.omega_max),
        sample_every=int(args.sample_every),
    )

    payload = build_payload(cfg, sigma_ratios=sigma_ratios, epsilons=epsilons)

    out_path = args.out.strip() or py_to_json_name(__file__)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

    print(f"Wrote {out_path}")

    # Compact terminal summary: final coherence + saturation
    for eps in epsilons:
        for sr in sigma_ratios:
            r = next(x for x in payload["results"] if x["eps_backreaction"] == eps and x["sigma_ratio"] == sr)
            if r["status"] != "completed":
                print(f"eps={eps:>5.2f}  σ/ω={sr:>4.2f}  status=FAILED at t={r.get('failure_step')}")
                continue
            coh = r["final"]["omega"]["coherent"]
            sig = r["final"]["omega"]["sigma"]
            sat = r["final"]["F_saturation_ratio"]
            fcs = r["final"]["first_coherent_step"]
            fcs_s = "None" if fcs is None else str(fcs)
            print(f"eps={eps:>5.2f}  σ/ω={sr:>4.2f}  coherent={str(coh):>5}  σ={sig:.4f}  sat={sat:.3f}  first_coh={fcs_s}")

if __name__ == "__main__":
    main()
