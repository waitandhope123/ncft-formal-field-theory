#!/usr/bin/env python3
"""
NCFT Toy 022 — Coherence Threshold Sweep

Purpose:
- Test sensitivity of NCFT dynamics to violation of frequency coherence (Axiom 3).
- Projection is always enforced.
- Pairwise gradient flow identical to Toy 021 hard_projection variant.

Outcome:
- Identify coherence breakdown threshold.
"""

from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass
from typing import Dict, List, Optional

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def normalize(x: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(x)
    if not math.isfinite(n) or n < 1e-12:
        return np.full_like(x, np.nan)
    return x / n


def deterministic_initial_states(N: int, d: int) -> np.ndarray:
    psi = np.zeros((N, d))
    for i in range(N):
        for j in range(d):
            psi[i, j] = math.sin((i + 1) * (j + 1))
        psi[i] = normalize(psi[i])
    return psi


def gram_matrix(psi: np.ndarray) -> np.ndarray:
    return psi @ psi.T


def coupling_sum(psi: np.ndarray) -> Optional[float]:
    if not np.all(np.isfinite(psi)):
        return None
    G = gram_matrix(psi)
    C = G * G
    np.fill_diagonal(C, 0.0)
    return float(np.sum(C) / 2.0)


def purity(psi: np.ndarray) -> Optional[float]:
    if not np.all(np.isfinite(psi)):
        return None
    rho = sum(np.outer(v, v) for v in psi) / psi.shape[0]
    val = float(np.trace(rho @ rho))
    return val if math.isfinite(val) else None


def grad_E(psi: np.ndarray) -> np.ndarray:
    G = gram_matrix(psi)
    grad = np.zeros_like(psi)
    for i in range(psi.shape[0]):
        grad[i] = -2.0 * np.sum(G[i, :, None] * psi, axis=0)
    return grad


# ----------------------------
# Toy logic
# ----------------------------

@dataclass
class Config:
    N: int = 20
    d: int = 8
    steps: int = 200
    eta: float = 0.05
    sigma_ratios: List[float] = None


def run_for_sigma(sigma_ratio: float, cfg: Config) -> Dict:
    psi = deterministic_initial_states(cfg.N, cfg.d)

    omega_mean = 1.0
    sigma = sigma_ratio * omega_mean
    omegas = np.linspace(
        omega_mean - sigma,
        omega_mean + sigma,
        cfg.N
    )

    history = []

    for t in range(cfg.steps + 1):

        history.append({
            "t": t,
            "F_total": coupling_sum(psi),
            "purity": purity(psi),
        })

        if not np.all(np.isfinite(psi)):
            return {
                "sigma_ratio": sigma_ratio,
                "status": "failed",
                "failure_step": t,
                "history": history,
            }

        if t == cfg.steps:
            break

        # Frequency-weighted gradient (minimal coupling to ω)
        grad = grad_E(psi)
        grad = grad * omegas[:, None]

        psi = psi - cfg.eta * grad
        psi = np.array([normalize(v) for v in psi])

    return {
        "sigma_ratio": sigma_ratio,
        "status": "completed",
        "final_F": coupling_sum(psi),
        "final_purity": purity(psi),
        "history": history,
    }


def build_payload(cfg: Config) -> Dict:
    results = []

    for sr in cfg.sigma_ratios:
        results.append(run_for_sigma(sr, cfg))

    return {
        "toy_id": "NCFT-022",
        "theory": "NCFT-core",
        "parameters": {
            "N": cfg.N,
            "d": cfg.d,
            "steps": cfg.steps,
            "eta": cfg.eta,
            "sigma_ratios": cfg.sigma_ratios,
        },
        "notes": {
            "pressure_point": "Sensitivity to violation of frequency coherence (Axiom 3).",
            "projection": "Hard projection enforced at every step.",
            "expected": "Sharp degradation beyond coherence threshold.",
        },
        "results": results,
    }


# ----------------------------
# Run
# ----------------------------

def main() -> None:
    cfg = Config(
        sigma_ratios=[0.0, 0.05, 0.1, 0.15, 0.2, 0.3, 0.5]
    )

    payload = build_payload(cfg)
    out = py_to_json_name(__file__)

    with open(out, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

    print(f"Wrote {out}")
    for r in payload["results"]:
        print(f"σ/ω={r['sigma_ratio']:.2f} → {r['status']}")


if __name__ == "__main__":
    main()
