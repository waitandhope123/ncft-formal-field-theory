#!/usr/bin/env python3
"""
NCFT Toy 026 — Projection Softening / Manifold Escape

Purpose:
- Test whether NCFT's global-alignment attractor and stability are *projection-enforced*.
- Introduce controlled "softening" of projection to see if:
    (a) dynamics still converge (intrinsic stability),
    (b) dynamics become numerically unstable (constraint-dependent),
    (c) multi-cluster structure emerges when the constraint manifold is relaxed.

This toy is intentionally a pressure test.

Variants (run in one script):
  A) hard_projection: normalize every step (baseline)
  B) partial_projection: ψ <- (1-α)ψ + α*normalize(ψ) each step, α∈(0,1]
  C) delayed_projection: normalize every k steps
  D) stochastic_projection: normalize each agent independently with prob p each step

Dynamics:
- Real states ψ_i ∈ R^d
- Pairwise energy E = -Σ_{i<j} (<ψ_i, ψ_j>)^2  (same as previous toys)
- Euler step: ψ <- ψ - η∇E
- Then apply projection variant as above

Measurements:
- F_total = Σ_{i<j} C_ij (with C_ij = (<ψ_i,ψ_j>)^2)
- purity γ = Tr(ρ^2), ρ = (1/N) Σ |ψ_i><ψ_i|
- norm drift stats (mean/min/max and max | ||ψ||-1 |)
- cluster diagnostics on C_ij threshold graph (same as Toy 025)
- failure detection: non-finite values OR norms exceeding guard rails

Determinism:
- No randomness except stochastic_projection (but we use a fixed seed).

Output:
- JSON written to <script>.json

Recommended filename:
  toy_026_ncft_projection_softening.py
"""

from __future__ import annotations

import argparse
import json
import math
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def normalize_or_nan(x: np.ndarray) -> np.ndarray:
    n = float(np.linalg.norm(x))
    if (not math.isfinite(n)) or (n < 1e-12):
        return np.full_like(x, np.nan)
    return x / n


def all_finite(x: np.ndarray) -> bool:
    return bool(np.all(np.isfinite(x)))


def deterministic_initial_states(N: int, d: int) -> np.ndarray:
    psi = np.zeros((N, d), dtype=float)
    for i in range(N):
        for j in range(d):
            psi[i, j] = math.sin((i + 1) * (j + 1)) + 0.25 * math.cos((i + 2) * (j + 1))
        psi[i] = normalize_or_nan(psi[i])
    return psi


# ----------------------------
# Core quantities
# ----------------------------

def gram_matrix(psi: np.ndarray) -> np.ndarray:
    return psi @ psi.T


def coupling_matrix(psi: np.ndarray) -> np.ndarray:
    G = gram_matrix(psi)
    C = G * G
    np.fill_diagonal(C, 0.0)
    return C


def F_total(psi: np.ndarray) -> Optional[float]:
    if not all_finite(psi):
        return None
    C = coupling_matrix(psi)
    if not np.all(np.isfinite(C)):
        return None
    return float(np.sum(C) / 2.0)


def density_matrix(psi: np.ndarray) -> Optional[np.ndarray]:
    if not all_finite(psi):
        return None
    N, d = psi.shape
    rho = np.zeros((d, d), dtype=float)
    for i in range(N):
        v = psi[i].reshape(-1, 1)
        rho += v @ v.T
    return rho / float(N)


def purity(psi: np.ndarray) -> Optional[float]:
    rho = density_matrix(psi)
    if rho is None or not np.all(np.isfinite(rho)):
        return None
    val = float(np.trace(rho @ rho))
    return val if math.isfinite(val) else None


def norm_stats(psi: np.ndarray) -> Dict[str, Optional[float]]:
    if not all_finite(psi):
        return {
            "norm_min": None, "norm_max": None, "norm_mean": None, "norm_std": None,
            "max_abs_norm_error_from_1": None
        }
    norms = np.linalg.norm(psi, axis=1)
    return {
        "norm_min": float(np.min(norms)),
        "norm_max": float(np.max(norms)),
        "norm_mean": float(np.mean(norms)),
        "norm_std": float(np.std(norms)),
        "max_abs_norm_error_from_1": float(np.max(np.abs(norms - 1.0))),
    }


# ----------------------------
# Cluster diagnostics (from Toy 025)
# ----------------------------

def connected_components(A: np.ndarray) -> List[List[int]]:
    N = A.shape[0]
    visited = np.zeros(N, dtype=bool)
    comps: List[List[int]] = []
    for start in range(N):
        if visited[start]:
            continue
        stack = [start]
        visited[start] = True
        comp = [start]
        while stack:
            u = stack.pop()
            nbrs = np.where(A[u] > 0)[0]
            for v in nbrs:
                if not visited[v]:
                    visited[v] = True
                    stack.append(int(v))
                    comp.append(int(v))
        comps.append(comp)
    comps.sort(key=lambda c: (-len(c), c[0]))
    return comps


def cluster_metrics(C: np.ndarray, tau: float) -> Dict[str, Any]:
    N = C.shape[0]
    A = (C >= tau).astype(int)
    np.fill_diagonal(A, 0)
    comps = connected_components(A)
    sizes = [len(c) for c in comps]
    num_clusters = len(comps)
    largest_frac = float(max(sizes) / N) if N > 0 else None

    labels = np.zeros(N, dtype=int)
    for k, comp in enumerate(comps):
        for i in comp:
            labels[i] = k

    intra_vals = []
    inter_vals = []
    for i in range(N):
        for j in range(i + 1, N):
            if labels[i] == labels[j]:
                intra_vals.append(C[i, j])
            else:
                inter_vals.append(C[i, j])

    mean_intra = float(np.mean(intra_vals)) if intra_vals else 0.0
    mean_inter = float(np.mean(inter_vals)) if inter_vals else 0.0

    return {
        "tau": tau,
        "num_clusters": int(num_clusters),
        "cluster_sizes": sizes,
        "largest_cluster_frac": largest_frac,
        "mean_intra_C": mean_intra,
        "mean_inter_C": mean_inter,
        "modularity_proxy": mean_intra - mean_inter,
    }


# ----------------------------
# Gradient
# ----------------------------

def grad_E_pairwise(psi: np.ndarray) -> np.ndarray:
    """
    E = - Σ_{i<j} (<ψ_i,ψ_j>)^2
    grad_E_i = -2 Σ_j G_ij ψ_j
    """
    G = gram_matrix(psi)
    grad = np.zeros_like(psi)
    for i in range(psi.shape[0]):
        grad[i] = -2.0 * np.sum(G[i, :, None] * psi, axis=0)
    return grad


# ----------------------------
# Projection variants
# ----------------------------

def apply_projection_variant(
    psi: np.ndarray,
    variant: str,
    alpha: float,
    k: int,
    p: float,
    t: int,
    rng: np.random.Generator,
) -> np.ndarray:
    N = psi.shape[0]

    if variant == "hard_projection":
        return np.array([normalize_or_nan(v) for v in psi])

    if variant == "partial_projection":
        # ψ <- (1-α)ψ + α*normalize(ψ), per agent
        out = psi.copy()
        for i in range(N):
            nhat = normalize_or_nan(out[i])
            out[i] = (1.0 - alpha) * out[i] + alpha * nhat
        return out

    if variant == "delayed_projection":
        if (t % k) == 0 and t > 0:
            return np.array([normalize_or_nan(v) for v in psi])
        return psi

    if variant == "stochastic_projection":
        out = psi.copy()
        mask = rng.random(N) < p
        for i in range(N):
            if mask[i]:
                out[i] = normalize_or_nan(out[i])
        return out

    raise ValueError(f"Unknown variant: {variant}")


# ----------------------------
# Toy runner
# ----------------------------

@dataclass
class Config:
    N: int = 20
    d: int = 8
    steps: int = 300
    eta: float = 0.05
    tau: float = 0.95          # cluster threshold on C_ij
    sample_every: int = 20

    # failure guardrails (diagnostics only)
    norm_guard_max: float = 1e6
    norm_guard_min: float = 1e-12


def run_variant(cfg: Config, variant: str, alpha: float, k: int, p: float, seed: int) -> Dict[str, Any]:
    psi = deterministic_initial_states(cfg.N, cfg.d)
    rng = np.random.default_rng(seed)

    history: List[Dict[str, Any]] = []

    for t in range(cfg.steps + 1):
        if not all_finite(psi):
            return {
                "variant": variant,
                "status": "failed",
                "failure_step": t,
                "failure_mode": "non_finite_state",
                "history": history,
            }

        ns = norm_stats(psi)
        # guardrail: declare failure if norms blow up or collapse
        if ns["norm_max"] is not None and ns["norm_max"] > cfg.norm_guard_max:
            return {
                "variant": variant,
                "status": "failed",
                "failure_step": t,
                "failure_mode": "norm_blowup",
                "history": history,
            }
        if ns["norm_min"] is not None and ns["norm_min"] < cfg.norm_guard_min:
            return {
                "variant": variant,
                "status": "failed",
                "failure_step": t,
                "failure_mode": "norm_collapse",
                "history": history,
            }

        if (t % cfg.sample_every) == 0 or (t == cfg.steps):
            C = coupling_matrix(psi)
            history.append({
                "t": t,
                "F_total": F_total(psi),
                "F_saturation_ratio": float(F_total(psi) / (cfg.N * (cfg.N - 1) / 2.0)) if cfg.N > 1 else None,
                "purity": purity(psi),
                "norm_stats": ns,
                "clusters": cluster_metrics(C, tau=cfg.tau),
            })

        if t == cfg.steps:
            break

        # gradient step
        grad = grad_E_pairwise(psi)
        psi = psi - cfg.eta * grad

        # apply projection variant
        psi = apply_projection_variant(
            psi=psi,
            variant=variant,
            alpha=alpha,
            k=k,
            p=p,
            t=t + 1,
            rng=rng,
        )

    # final summary
    C_final = coupling_matrix(psi)
    return {
        "variant": variant,
        "status": "completed",
        "final": {
            "F_total": F_total(psi),
            "purity": purity(psi),
            "norm_stats": norm_stats(psi),
            "clusters": cluster_metrics(C_final, tau=cfg.tau),
        },
        "history": history,
    }


def build_payload(cfg: Config, variants: List[Dict[str, Any]]) -> Dict[str, Any]:
    results = []
    for v in variants:
        results.append(run_variant(
            cfg=cfg,
            variant=v["name"],
            alpha=v.get("alpha", 1.0),
            k=v.get("k", 10),
            p=v.get("p", 1.0),
            seed=v.get("seed", 12345),
        ))

    return {
        "toy_id": "NCFT-026",
        "theory": "NCFT-core + projection softening stress test",
        "spacetime": "State space: R^{N×d} with optional projection toward (S^{d-1})^N",
        "units": {"G": 1, "c": 1},
        "parameters": {
            "N": cfg.N,
            "d": cfg.d,
            "steps": cfg.steps,
            "eta": cfg.eta,
            "tau": cfg.tau,
            "sample_every": cfg.sample_every,
            "norm_guard_max": cfg.norm_guard_max,
            "norm_guard_min": cfg.norm_guard_min,
            "variants": variants,
        },
        "notes": {
            "pressure_point": (
                "Does relaxing projection yield intrinsic stability, manifold escape, or emergent cluster structure?"
            ),
            "cluster_rule": "Adjacency A_ij=1 if C_ij >= tau, clusters are connected components of A.",
            "projection_variants": {
                "hard_projection": "normalize each ψ_i every step",
                "partial_projection": "ψ_i <- (1-α)ψ_i + α*normalize(ψ_i)",
                "delayed_projection": "normalize each ψ_i every k steps",
                "stochastic_projection": "normalize ψ_i with probability p each step",
            },
        },
        "results": results,
    }


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="NCFT Toy 026: Projection softening / manifold escape.")
    ap.add_argument("--N", type=int, default=20)
    ap.add_argument("--d", type=int, default=8)
    ap.add_argument("--steps", type=int, default=300)
    ap.add_argument("--eta", type=float, default=0.05)
    ap.add_argument("--tau", type=float, default=0.95)
    ap.add_argument("--sample_every", type=int, default=20)
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    cfg = Config(
        N=int(args.N),
        d=int(args.d),
        steps=int(args.steps),
        eta=float(args.eta),
        tau=float(args.tau),
        sample_every=int(args.sample_every),
    )

    variants = [
        {"name": "hard_projection", "seed": 12345},
        {"name": "partial_projection", "alpha": 0.2, "seed": 12345},
        {"name": "partial_projection", "alpha": 0.05, "seed": 12345},
        {"name": "delayed_projection", "k": 5, "seed": 12345},
        {"name": "delayed_projection", "k": 10, "seed": 12345},
        {"name": "stochastic_projection", "p": 0.5, "seed": 12345},
        {"name": "stochastic_projection", "p": 0.2, "seed": 12345},
    ]

    payload = build_payload(cfg, variants)

    out_path = args.out.strip() or py_to_json_name(__file__)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

    print(f"Wrote {out_path}")

    # Compact summary
    for r in payload["results"]:
        if r["status"] != "completed":
            print(f"{r['variant']:>20} -> FAILED at t={r.get('failure_step')} mode={r.get('failure_mode')}")
            continue
        fin = r["final"]
        cl = fin["clusters"]
        print(
            f"{r['variant']:>20} -> completed "
            f"F={fin['F_total']:.3f} purity={fin['purity']:.3f} "
            f"clusters={cl['num_clusters']} largest={cl['largest_cluster_frac']:.2f} "
            f"mod={cl['modularity_proxy']:.3f} "
            f"max_norm_err={fin['norm_stats']['max_abs_norm_error_from_1']:.3e}"
        )

if __name__ == "__main__":
    main()
