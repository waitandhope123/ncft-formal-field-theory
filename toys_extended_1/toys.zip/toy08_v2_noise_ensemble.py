"""
toy08_v2_noise_ensemble.py

TOY 08 v2 — NOISE PHASE DIAGRAM (Multi-seed Ensemble)

Builds on Toy 08, but runs multiple random seeds per noise level and reports:
- mean <R> over seeds
- standard deviation over seeds
- (optional) 95% CI approximation

This clarifies whether non-monotonic noise response is real or sampling noise.

Output:
  outputs/toy08_v2_noise_ensemble.csv
"""

import csv
from pathlib import Path
import numpy as np

EPS = 1e-12

# -----------------------
# CSV Logger
# -----------------------
class CSVLogger:
    def __init__(self, filename, fieldnames):
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        self.file = open(filename, "w", newline="")
        self.writer = csv.DictWriter(self.file, fieldnames=fieldnames)
        self.writer.writeheader()

    def log(self, **row):
        self.writer.writerow(row)

    def close(self):
        self.file.close()

# -----------------------
# Core math
# -----------------------
def normalize(psi):
    n = np.linalg.norm(psi)
    if n < EPS:
        raise ValueError("Zero norm forbidden")
    return psi / n

def random_state(rng, dim):
    psi = rng.normal(size=dim) + 1j * rng.normal(size=dim)
    return normalize(psi)

def coupling(a, b):
    c = np.abs(np.vdot(a, b)) ** 2
    # numerical clamp
    if c < 0 and c > -1e-9:
        c = 0.0
    if c > 1 and c < 1 + 1e-9:
        c = 1.0
    return float(c)

def coupling_matrix(states):
    N = len(states)
    C = np.zeros((N, N))
    for i in range(N):
        for j in range(i + 1, N):
            c = coupling(states[i], states[j])
            C[i, j] = C[j, i] = c
    return C

# -----------------------
# Kuramoto dynamics
# -----------------------
def kuramoto_step(theta, omega, C, K, dt, noise, rng):
    N = len(theta)
    dtheta = np.zeros(N)
    for i in range(N):
        s = 0.0
        for j in range(N):
            if i != j:
                s += C[i, j] * np.sin(theta[j] - theta[i])
        dtheta[i] = omega[i] + K * s
    theta = theta + dt * dtheta + noise * rng.normal(size=N) * np.sqrt(dt)
    return theta

def order_parameter(theta):
    return float(np.abs(np.mean(np.exp(1j * theta))))

# -----------------------
# One run for one seed/noise
# -----------------------
def simulate_one(seed, noise, T, burn_in, N, dim, K, dt):
    rng = np.random.default_rng(seed)

    # Static NCFT states per run (keeps ensemble honest)
    states = [random_state(rng, dim) for _ in range(N)]
    C = coupling_matrix(states)

    # Frequencies and initial phases
    omega = rng.normal(0.0, 0.5, size=N)
    theta = rng.uniform(0, 2 * np.pi, size=N)

    R_vals = []
    for t in range(T):
        theta = kuramoto_step(theta, omega, C, K, dt, noise, rng)
        if t >= burn_in:
            R_vals.append(order_parameter(theta))

    R_vals = np.array(R_vals, dtype=float)
    return float(R_vals.mean()), float(R_vals.std())

# -----------------------
# Main sweep
# -----------------------
def run_noise_ensemble(
    noise_levels=(0.0, 0.01, 0.02, 0.05, 0.1, 0.2),
    seeds=(0, 1, 2, 3, 4, 5, 6, 7, 8, 9),
    T=400,
    burn_in=150,
    N=12,
    dim=16,
    K=0.8,
    dt=0.05,
    out_csv="outputs/toy08_v2_noise_ensemble.csv",
):
    FIELDS = [
        "toy",
        "noise",
        "seed",
        "N", "dim", "K", "dt",
        "R_mean_time", "R_std_time",
        "status",
    ]
    logger = CSVLogger(out_csv, FIELDS)

    # We also print aggregated across seeds per noise
    print("TOY08 v2 — NOISE ENSEMBLE")
    print(f"N={N} dim={dim} K={K} | T={T} burn_in={burn_in} | seeds={len(seeds)}")
    print("")

    for noise in noise_levels:
        seed_means = []

        for seed in seeds:
            R_mean_time, R_std_time = simulate_one(
                seed=seed,
                noise=noise,
                T=T,
                burn_in=burn_in,
                N=N,
                dim=dim,
                K=K,
                dt=dt,
            )
            seed_means.append(R_mean_time)

            status = "COHERENT" if R_mean_time > 0.8 else "DECOHERED"

            logger.log(
                toy="toy08_v2_noise_ensemble",
                noise=noise,
                seed=seed,
                N=N,
                dim=dim,
                K=K,
                dt=dt,
                R_mean_time=R_mean_time,
                R_std_time=R_std_time,
                status=status,
            )

        seed_means = np.array(seed_means, dtype=float)
        mu = float(seed_means.mean())
        sd = float(seed_means.std())
        # normal approx 95% CI on mean
        ci95 = 1.96 * sd / np.sqrt(len(seed_means))

        print(f"noise={noise:>6.3f} | <R>_seeds={mu:.3f} ± {sd:.3f} | CI95≈±{ci95:.3f}")

    logger.close()
    print("")
    print(f"Saved CSV → {out_csv}")
    print("Interpretation:")
    print(" - Look at <R>_seeds vs noise for monotonicity or resonance.")
    print(" - If CI bands overlap heavily, effects may be weak at this N,dim,K.")

if __name__ == "__main__":
    run_noise_ensemble(
        noise_levels=(0.0, 0.01, 0.02, 0.05, 0.1, 0.2),
        seeds=tuple(range(10)),
        T=400,
        burn_in=150,
        N=12,
        dim=16,
        K=0.8,
        dt=0.05,
    )
