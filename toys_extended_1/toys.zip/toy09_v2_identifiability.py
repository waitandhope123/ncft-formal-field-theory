"""
toy09_v2_identifiability.py

TOY09 v2 — IDENTIFIABILITY WITH GLOBAL CONSTRAINT

We attempt to reconstruct states ψ̂_i given:
  1) Observed pairwise couplings C_ij
  2) Observed global purity Tr(ρ^2)

Loss:
  L = Σ_{i<j} (Ĉ_ij - C_ij)^2
    + λ (Tr(ρ̂^2) - Tr(ρ^2))^2

This tests whether adding ONE global observable
restores identifiability.
"""

import csv
from pathlib import Path
import numpy as np

EPS = 1e-12

# -----------------------
# CSV Logger
# -----------------------
class CSVLogger:
    def __init__(self, filename, fieldnames):
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        self.file = open(filename, "w", newline="")
        self.writer = csv.DictWriter(self.file, fieldnames=fieldnames)
        self.writer.writeheader()

    def log(self, **row):
        self.writer.writerow(row)

    def close(self):
        self.file.close()

# -----------------------
# Core math
# -----------------------
def normalize(psi):
    n = np.linalg.norm(psi)
    if n < EPS:
        raise ValueError("Zero norm forbidden")
    return psi / n

def random_state(rng, dim):
    psi = rng.normal(size=dim) + 1j * rng.normal(size=dim)
    return normalize(psi)

def coupling(a, b):
    return float(np.abs(np.vdot(a, b)) ** 2)

def coupling_matrix(states):
    N = len(states)
    C = np.zeros((N, N))
    for i in range(N):
        for j in range(i + 1, N):
            c = coupling(states[i], states[j])
            C[i, j] = C[j, i] = c
    return C

def density_matrix(states):
    dim = states[0].shape[0]
    rho = np.zeros((dim, dim), dtype=complex)
    for psi in states:
        rho += np.outer(psi, psi.conj())
    rho /= len(states)
    return 0.5 * (rho + rho.conj().T)

def purity_from_states(states):
    rho = density_matrix(states)
    return float(np.real(np.trace(rho @ rho)))

# -----------------------
# Loss + gradient
# -----------------------
def loss_and_grad(states_hat, C_obs, purity_obs, lam):
    N = len(states_hat)
    grads = [np.zeros_like(states_hat[0]) for _ in range(N)]
    L = 0.0

    # Pairwise loss
    for i in range(N):
        for j in range(i + 1, N):
            psi_i, psi_j = states_hat[i], states_hat[j]
            s = np.vdot(psi_i, psi_j)
            C_hat = np.abs(s) ** 2
            diff = C_hat - C_obs[i, j]
            L += diff * diff

            grads[i] += 2 * diff * (s * psi_j)
            grads[j] += 2 * diff * (np.conj(s) * psi_i)

    # Purity constraint
    purity_hat = purity_from_states(states_hat)
    dp = purity_hat - purity_obs
    L += lam * dp * dp

    # Approximate purity gradient
    rho = density_matrix(states_hat)
    for i, psi in enumerate(states_hat):
        grads[i] += 4 * lam * dp * (rho @ psi) / N

    return float(L), grads, purity_hat

# -----------------------
# Main experiment
# -----------------------
def run_identifiability_v2(
    N=10,
    dim=8,
    steps=1000,
    lr=0.03,
    lam=10.0,
    seed=0,
    out_csv="outputs/toy09_v2_identifiability.csv",
):
    rng = np.random.default_rng(seed)

    true_states = [random_state(rng, dim) for _ in range(N)]
    C_obs = coupling_matrix(true_states)
    purity_obs = purity_from_states(true_states)

    states_hat = [random_state(rng, dim) for _ in range(N)]

    logger = CSVLogger(
        out_csv,
        ["step", "loss", "purity_hat", "purity_obs", "status"]
    )

    print("TOY09 v2 — IDENTIFIABILITY WITH PURITY")
    print(f"N={N} dim={dim} λ={lam}")
    print(f"True purity = {purity_obs:.6f}")
    print("")

    for step in range(steps):
        L, grads, p_hat = loss_and_grad(states_hat, C_obs, purity_obs, lam)
        states_hat = [normalize(psi - lr * g) for psi, g in zip(states_hat, grads)]

        status = "FIT_OK" if L < 1e-6 else "FITTING"

        logger.log(
            step=step,
            loss=L,
            purity_hat=p_hat,
            purity_obs=purity_obs,
            status=status,
        )

        if step % 100 == 0:
            print(
                f"step={step:04d} | loss={L:.3e} | "
                f"purity_hat={p_hat:.6f} | {status}"
            )

    logger.close()
    print(f"\nSaved CSV → {out_csv}")

if __name__ == "__main__":
    run_identifiability_v2()
