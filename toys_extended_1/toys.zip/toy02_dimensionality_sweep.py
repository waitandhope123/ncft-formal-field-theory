"""
toy02_dimensionality_sweep.py

TOY 02 — DIMENSIONALITY SWEEP
Sweep over state dimension dim while keeping N fixed.
For each dim, run multiple trials of random normalized complex states
and record coupling statistics.

Output:
  outputs/toy02_dimensionality_sweep.csv
"""

import csv
from pathlib import Path
import numpy as np

EPS = 1e-12

# -----------------------
# CSV Logger
# -----------------------
class CSVLogger:
    def __init__(self, filename, fieldnames):
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        self.file = open(filename, "w", newline="")
        self.writer = csv.DictWriter(self.file, fieldnames=fieldnames)
        self.writer.writeheader()

    def log(self, **row):
        self.writer.writerow(row)

    def close(self):
        self.file.close()

# -----------------------
# Core math
# -----------------------
def normalize(psi: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(psi)
    if n < EPS:
        raise ValueError("Zero norm forbidden")
    return psi / n

def random_state(rng: np.random.Generator, dim: int) -> np.ndarray:
    psi = rng.normal(size=dim) + 1j * rng.normal(size=dim)
    return normalize(psi)

def coupling(psi_a: np.ndarray, psi_b: np.ndarray) -> float:
    c = np.abs(np.vdot(psi_a, psi_b)) ** 2
    # numerical clamp
    if c < 0.0 and c > -1e-9:
        c = 0.0
    if c > 1.0 and c < 1.0 + 1e-9:
        c = 1.0
    return float(c)

def coupling_stats(states: list[np.ndarray]) -> dict:
    N = len(states)
    pairs = []
    cmax = 0.0
    total = 0.0

    for i in range(N):
        for j in range(i + 1, N):
            c = coupling(states[i], states[j])
            pairs.append(c)
            total += c
            if c > cmax:
                cmax = c

    pairs = np.array(pairs, dtype=float)
    return {
        "pairs": len(pairs),
        "C_mean": float(np.mean(pairs)) if len(pairs) else 0.0,
        "C_sigma": float(np.std(pairs)) if len(pairs) else 0.0,
        "C_min": float(np.min(pairs)) if len(pairs) else 0.0,
        "C_max": float(cmax),
        "C_total": float(total),
    }

# -----------------------
# Main experiment
# -----------------------
def run_dimensionality_sweep(
    dims=(1, 2, 4, 8, 16, 32, 64),
    trials_per_dim=200,
    N=12,
    seed=0,
    out_csv="outputs/toy02_dimensionality_sweep.csv",
):
    rng = np.random.default_rng(seed)

    FIELDS = [
        "toy", "run_id", "seed",
        "dim", "trial", "N", "pairs",
        "C_mean", "C_sigma", "C_min", "C_max", "C_total",
        "expected_mean_1_over_dim",
        "status",
    ]
    logger = CSVLogger(out_csv, FIELDS)

    print("TOY02 — DIMENSIONALITY SWEEP")
    print(f"N={N} | trials per dim={trials_per_dim}")
    print("")

    for dim in dims:
        means = []
        sigmas = []

        for trial in range(trials_per_dim):
            states = [random_state(rng, dim) for _ in range(N)]
            stats = coupling_stats(states)

            means.append(stats["C_mean"])
            sigmas.append(stats["C_sigma"])

            logger.log(
                toy="toy02_dimensionality_sweep",
                run_id=0,
                seed=seed,
                dim=dim,
                trial=trial,
                N=N,
                pairs=stats["pairs"],
                C_mean=stats["C_mean"],
                C_sigma=stats["C_sigma"],
                C_min=stats["C_min"],
                C_max=stats["C_max"],
                C_total=stats["C_total"],
                expected_mean_1_over_dim=1.0 / dim,
                status="NULL",
            )

        means = np.array(means)
        sigmas = np.array(sigmas)

        print(
            f"dim={dim:>3d} | "
            f"<C>={means.mean():.6f} (expected≈{1.0/dim:.6f}) | "
            f"σ={sigmas.mean():.6f}"
        )

    logger.close()
    print("")
    print(f"Saved CSV → {out_csv}")
    print("Expectation: <C> ~ 1/dim for random states.")

if __name__ == "__main__":
    run_dimensionality_sweep(
        dims=(1, 2, 4, 8, 16, 32, 64),
        trials_per_dim=200,
        N=12,
        seed=0,
    )
