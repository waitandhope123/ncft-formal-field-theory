#!/usr/bin/env python3
"""
NCFT-core Toy 4: Inverse / Identifiability & Falsification Harness

Generates synthetic NCFT-like systems with known latent structure,
then tests what can be recovered from observables alone.

Latent structures tested:
- cluster structure
- null (random) structure
- mixed populations

Observables:
- full or partial C_ij
- noisy overlaps
- time-averaged statistics

Outputs: inverse_identifiability_results.csv
"""

import numpy as np
import csv
from itertools import product


# -------------------------
# Utilities
# -------------------------

def random_unit_vectors(N, d, rng):
    X = rng.normal(size=(N, d)) + 1j * rng.normal(size=(N, d))
    X /= np.linalg.norm(X, axis=1, keepdims=True)
    return X

def clustered_vectors(N, d, n_clusters, spread, rng):
    """
    Generate N vectors in d dims clustered around n_clusters centers.
    spread controls deviation from center.
    """
    centers = random_unit_vectors(n_clusters, d, rng)
    labels = rng.integers(0, n_clusters, size=N)
    psis = np.zeros((N, d), dtype=np.complex128)
    for i in range(N):
        psis[i] = centers[labels[i]] + spread * (
            rng.normal(size=d) + 1j * rng.normal(size=d)
        )
    psis /= np.linalg.norm(psis, axis=1, keepdims=True)
    return psis, labels

def compute_C(psis):
    inner = psis @ psis.conj().T
    C = np.abs(inner) ** 2
    np.fill_diagonal(C, 0.0)
    return C

def add_noise_to_C(C, sigma, rng):
    if sigma <= 0:
        return C
    noise = rng.normal(scale=sigma, size=C.shape)
    Cn = C + noise
    Cn = np.clip(Cn, 0.0, 1.0)
    np.fill_diagonal(Cn, 0.0)
    return Cn

def mask_C(C, frac_observed, rng):
    """
    Randomly hide a fraction of entries.
    """
    if frac_observed >= 1.0:
        return C, np.ones_like(C, dtype=bool)
    mask = rng.random(C.shape) < frac_observed
    mask = np.triu(mask, 1)
    mask = mask + mask.T
    np.fill_diagonal(mask, False)
    Cm = np.zeros_like(C)
    Cm[mask] = C[mask]
    return Cm, mask

def spectral_cluster_estimate(C, k):
    """
    Simple spectral clustering proxy:
    - use top k eigenvectors of C
    """
    w, v = np.linalg.eigh(C)
    idx = np.argsort(w)[::-1][:k]
    X = v[:, idx]
    # normalize rows
    norms = np.linalg.norm(X, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    X = X / norms
    return X

def clustering_accuracy(true_labels, X):
    """
    Very rough proxy:
    cluster by argmax dimension, compare to true labels
    (label permutation ignored by taking best match)
    """
    est = np.argmax(X, axis=1)
    # best permutation match (brute force for small k)
    k = X.shape[1]
    best = 0.0
    for perm in np.array(np.meshgrid(*[range(k)]*k)).T.reshape(-1, k):
        if len(set(perm)) < k:
            continue
        mapped = np.array([perm[e] for e in est])
        acc = np.mean(mapped == true_labels)
        best = max(best, acc)
    return best


# -------------------------
# Experiment runner
# -------------------------

def run_one(
    N=30,
    d=12,
    structure="clustered",   # "clustered" or "null"
    n_clusters=3,
    spread=0.1,
    frac_observed=1.0,
    noise_C=0.0,
    seed=0
):
    rng = np.random.default_rng(seed)

    if structure == "clustered":
        psis, labels = clustered_vectors(N, d, n_clusters, spread, rng)
    elif structure == "null":
        psis = random_unit_vectors(N, d, rng)
        labels = rng.integers(0, n_clusters, size=N)  # meaningless
    else:
        raise ValueError("Unknown structure")

    C = compute_C(psis)
    C = add_noise_to_C(C, noise_C, rng)
    C_obs, mask = mask_C(C, frac_observed, rng)

    # Attempt to recover cluster structure
    X = spectral_cluster_estimate(C_obs, n_clusters)
    acc = clustering_accuracy(labels, X)

    # Null baseline
    C_vals = C_obs[np.triu_indices(N, 1)]
    C_mean = float(np.mean(C_vals[C_vals > 0])) if np.any(C_vals > 0) else 0.0

    return {
        "N": N,
        "d": d,
        "structure": structure,
        "n_clusters": n_clusters,
        "spread": spread,
        "frac_observed": frac_observed,
        "noise_C": noise_C,
        "C_mean": C_mean,
        "cluster_recovery_accuracy": acc,
        "seed": seed,
    }


# -------------------------
# Main sweep
# -------------------------

def main():
    Ns = [30]
    ds = [12]
    seeds = [1, 7, 42]

    structures = ["clustered", "null"]
    n_clusters = 3
    spreads = [0.05, 0.1, 0.2]
    frac_observed_vals = [1.0, 0.5, 0.25]
    noise_vals = [0.0, 0.01, 0.05]

    rows = []
    for (structure, spread, frac_obs, noise, seed) in product(
        structures, spreads, frac_observed_vals, noise_vals, seeds
    ):
        print(f"struct={structure} spread={spread} obs={frac_obs} noise={noise} seed={seed}")
        rows.append(run_one(
            N=Ns[0],
            d=ds[0],
            structure=structure,
            n_clusters=n_clusters,
            spread=spread,
            frac_observed=frac_obs,
            noise_C=noise,
            seed=seed
        ))

    outpath = "inverse_identifiability_results.csv"
    with open(outpath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        for r in rows:
            writer.writerow(r)

    print(f"Saved {outpath}")

if __name__ == "__main__":
    main()
