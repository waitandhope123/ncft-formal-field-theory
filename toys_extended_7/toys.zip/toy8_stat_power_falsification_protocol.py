#!/usr/bin/env python3
"""
NCFT-core Toy 8: Statistical Power + Falsification Protocol Simulator

WHY THIS HELPS GREATLY
----------------------
Toys 1–7 establish internal mathematical coherence, robustness, topology, inference limits,
and (approximate) coarse-graining. What’s still missing for “physics-precise” grounding is:

  -> A falsifiable, pre-registered measurement protocol with power analysis.

Toy 8 turns NCFT from “computationally coherent” into “experimentally testable” by:
- defining explicit test statistics on observables (C_ij, summary features)
- generating synthetic null vs NCFT-like alternative data under controlled noise
- computing false-positive rates, power curves, ROC
- returning sample sizes needed to detect a specified effect at a chosen alpha

This gives you:
1) A disciplined bridge from theory → measurement → falsification.
2) Concrete experimental design: how many trials/events you need.

WHAT IT SIMULATES
-----------------
We simulate "events" as observed overlap matrices C (or partial observations of them).
We compare two models:
- NULL: random unit states in C^d -> overlaps distributed ~ 1/d
- ALT: structured/coherent generator producing elevated overlaps (effect size)

We then run a pre-registered test statistic:
- T = mean(C_ij) - (1/d)   over observed pairs
(or you can choose alternatives like tail mass above threshold).

OUTPUTS
-------
- toy8_power_curve.csv       : power vs number_of_events for each condition
- toy8_roc.csv               : ROC points for the chosen test statistic
- toy8_thresholds.csv        : selected thresholds for alpha control

RUN
---
python toy8_stat_power_falsification_protocol.py

TYPICAL NEXT STEP
-----------------
Pick a detection target (alpha=0.05, power=0.8) and let Toy 8 tell you:
- how many events are needed
- what threshold to use
- what noise/partial-observation tolerance you can survive
"""

import numpy as np
import csv
from dataclasses import dataclass
from itertools import product
from typing import Tuple, Dict, List


# -------------------------
# Core generation primitives
# -------------------------

def random_unit_vectors(N: int, d: int, rng: np.random.Generator) -> np.ndarray:
    X = rng.normal(size=(N, d)) + 1j * rng.normal(size=(N, d))
    X /= np.linalg.norm(X, axis=1, keepdims=True)
    return X

def compute_C(psis: np.ndarray) -> np.ndarray:
    inner = psis @ psis.conj().T
    C = np.abs(inner) ** 2
    np.fill_diagonal(C, 0.0)
    return C

def mask_pairs(C: np.ndarray, frac_observed: float, rng: np.random.Generator) -> Tuple[np.ndarray, np.ndarray]:
    """
    Randomly keep a fraction of off-diagonal entries (symmetric mask).
    Returns (C_obs, mask_bool).
    """
    N = C.shape[0]
    if frac_observed >= 1.0:
        mask = np.ones((N, N), dtype=bool)
        np.fill_diagonal(mask, False)
        return C.copy(), mask

    m = rng.random((N, N)) < frac_observed
    m = np.triu(m, 1)
    m = m + m.T
    mask = m.astype(bool)
    C_obs = np.zeros_like(C)
    C_obs[mask] = C[mask]
    return C_obs, mask

def add_measurement_noise_C(C_obs: np.ndarray, mask: np.ndarray, sigma: float, rng: np.random.Generator) -> np.ndarray:
    """
    Add clipped Gaussian noise to observed entries only.
    """
    if sigma <= 0:
        return C_obs
    noise = rng.normal(scale=sigma, size=C_obs.shape)
    Cn = C_obs.copy()
    Cn[mask] = np.clip(Cn[mask] + noise[mask], 0.0, 1.0)
    np.fill_diagonal(Cn, 0.0)
    return Cn


# -------------------------
# Alternative (NCFT-like) event generator
# -------------------------

def gen_alt_event_C(
    N: int,
    d: int,
    effect_strength: float,
    coherence_mix: float,
    rng: np.random.Generator
) -> np.ndarray:
    """
    Generate an "ALT" event with elevated overlaps.

    Construction (simple but controllable):
    - Draw a latent reference direction v (unit vector)
    - Create psis_i = normalize( (1 - coherence_mix)*rand + coherence_mix*(v + effect_strength*rand) )
    - effect_strength increases alignment concentration; coherence_mix controls fraction of shared direction.

    This is not claiming physical truth—it's a tunable structured alternative used to test detectability.
    """
    v = random_unit_vectors(1, d, rng)[0]
    base = random_unit_vectors(N, d, rng)
    pert = rng.normal(size=(N, d)) + 1j * rng.normal(size=(N, d))
    psis = (1.0 - coherence_mix) * base + coherence_mix * (v[None, :] + effect_strength * pert)
    psis /= np.linalg.norm(psis, axis=1, keepdims=True)
    return compute_C(psis)

def gen_null_event_C(N: int, d: int, rng: np.random.Generator) -> np.ndarray:
    psis = random_unit_vectors(N, d, rng)
    return compute_C(psis)


# -------------------------
# Pre-registered test statistics
# -------------------------

def stat_mean_excess(C_obs: np.ndarray, mask: np.ndarray, d: int) -> float:
    """
    T = mean(C_ij over observed pairs) - 1/d
    """
    vals = C_obs[mask]
    if vals.size == 0:
        return 0.0
    return float(np.mean(vals) - (1.0 / d))

def stat_tail_mass(C_obs: np.ndarray, mask: np.ndarray, threshold: float) -> float:
    """
    T = fraction of observed pairs with C_ij >= threshold
    """
    vals = C_obs[mask]
    if vals.size == 0:
        return 0.0
    return float(np.mean(vals >= threshold))

def compute_stat(
    stat_name: str,
    C_obs: np.ndarray,
    mask: np.ndarray,
    d: int,
    tail_threshold: float
) -> float:
    if stat_name == "mean_excess":
        return stat_mean_excess(C_obs, mask, d)
    if stat_name == "tail_mass":
        return stat_tail_mass(C_obs, mask, tail_threshold)
    raise ValueError("Unknown stat_name")


# -------------------------
# Simulation + thresholding
# -------------------------

def simulate_event_stats(
    model: str,
    n_events: int,
    N: int,
    d: int,
    frac_observed: float,
    meas_sigma: float,
    effect_strength: float,
    coherence_mix: float,
    stat_name: str,
    tail_threshold: float,
    rng: np.random.Generator
) -> np.ndarray:
    stats = np.zeros(n_events, dtype=float)
    for i in range(n_events):
        if model == "null":
            C = gen_null_event_C(N, d, rng)
        elif model == "alt":
            C = gen_alt_event_C(N, d, effect_strength, coherence_mix, rng)
        else:
            raise ValueError("model must be 'null' or 'alt'")

        C_obs, mask = mask_pairs(C, frac_observed, rng)
        C_obs = add_measurement_noise_C(C_obs, mask, meas_sigma, rng)
        stats[i] = compute_stat(stat_name, C_obs, mask, d, tail_threshold)
    return stats

def threshold_for_alpha(null_stats: np.ndarray, alpha: float) -> float:
    """
    Choose threshold tau so that P_null(T >= tau) <= alpha
    => tau = quantile at 1-alpha
    """
    return float(np.quantile(null_stats, 1.0 - alpha))

def power_at_threshold(alt_stats: np.ndarray, tau: float) -> float:
    return float(np.mean(alt_stats >= tau))


# -------------------------
# Config
# -------------------------

@dataclass
class Config:
    # Event structure
    N: int = 24
    d: int = 16

    # Observation / measurement model
    frac_observed_list: Tuple[float, ...] = (1.0, 0.5, 0.25)
    meas_sigma_list: Tuple[float, ...] = (0.0, 0.01, 0.05)

    # Alternative model knobs (effect size)
    effect_strength_list: Tuple[float, ...] = (0.0, 0.25, 0.5, 1.0)
    coherence_mix_list: Tuple[float, ...] = (0.0, 0.25, 0.5, 0.75)

    # Test statistic selection
    stat_name: str = "mean_excess"      # "mean_excess" or "tail_mass"
    tail_threshold: float = 0.25        # used only if stat_name=="tail_mass"

    # Alpha and desired power
    alpha: float = 0.05
    target_power: float = 0.80

    # Monte Carlo
    mc_null_events_for_threshold: int = 4000
    mc_alt_events_for_power: int = 4000

    # "How many events in the real experiment?"
    # Power will be computed for these effective sample sizes by averaging event stats.
    event_counts_to_test: Tuple[int, ...] = (1, 2, 5, 10, 20, 50, 100)

    # ROC sampling (optional output)
    roc_points: int = 60

    seed: int = 123


# -------------------------
# Main
# -------------------------

def main():
    cfg = Config()
    rng = np.random.default_rng(cfg.seed)

    # Output rows
    power_rows: List[Dict] = []
    roc_rows: List[Dict] = []
    thr_rows: List[Dict] = []

    # Sweep conditions
    for frac_obs, meas_sigma in product(cfg.frac_observed_list, cfg.meas_sigma_list):
        # Null distribution of per-event statistic
        null_stats = simulate_event_stats(
            model="null",
            n_events=cfg.mc_null_events_for_threshold,
            N=cfg.N,
            d=cfg.d,
            frac_observed=frac_obs,
            meas_sigma=meas_sigma,
            effect_strength=0.0,
            coherence_mix=0.0,
            stat_name=cfg.stat_name,
            tail_threshold=cfg.tail_threshold,
            rng=rng
        )

        # We will convert per-event stats into an experiment-level statistic by averaging over M events.
        # Under independence, mean-of-events reduces variance ~1/sqrt(M). We simulate this by bootstrap.
        def bootstrap_mean_stats(stats: np.ndarray, M: int, n_boot: int = 4000) -> np.ndarray:
            idx = rng.integers(0, len(stats), size=(n_boot, M))
            return np.mean(stats[idx], axis=1)

        # For each alternative setting, compute power curve vs M
        for effect_strength, coherence_mix in product(cfg.effect_strength_list, cfg.coherence_mix_list):
            # Skip the pure-null alternative point if you want (keep it for sanity)
            alt_stats = simulate_event_stats(
                model="alt",
                n_events=cfg.mc_alt_events_for_power,
                N=cfg.N,
                d=cfg.d,
                frac_observed=frac_obs,
                meas_sigma=meas_sigma,
                effect_strength=effect_strength,
                coherence_mix=coherence_mix,
                stat_name=cfg.stat_name,
                tail_threshold=cfg.tail_threshold,
                rng=rng
            )

            # Build bootstrap distributions of the experiment-level statistic for each M
            for M in cfg.event_counts_to_test:
                null_means = bootstrap_mean_stats(null_stats, M)
                alt_means = bootstrap_mean_stats(alt_stats, M)

                tau = threshold_for_alpha(null_means, cfg.alpha)
                pow_M = power_at_threshold(alt_means, tau)

                power_rows.append({
                    "N": cfg.N,
                    "d": cfg.d,
                    "stat": cfg.stat_name,
                    "tail_threshold": cfg.tail_threshold if cfg.stat_name == "tail_mass" else "",
                    "frac_observed": frac_obs,
                    "meas_sigma": meas_sigma,
                    "effect_strength": effect_strength,
                    "coherence_mix": coherence_mix,
                    "events_M": M,
                    "alpha": cfg.alpha,
                    "threshold_tau": tau,
                    "power": pow_M,
                })

            # Find minimal M achieving target power (if any)
            Ms = np.array(cfg.event_counts_to_test, dtype=int)
            pows = np.array([r["power"] for r in power_rows
                             if r["frac_observed"] == frac_obs
                             and r["meas_sigma"] == meas_sigma
                             and r["effect_strength"] == effect_strength
                             and r["coherence_mix"] == coherence_mix], dtype=float)
            # pows is appended in order; ensure same length
            if len(pows) == len(Ms):
                ok = np.where(pows >= cfg.target_power)[0]
                minM = int(Ms[ok[0]]) if ok.size else -1
            else:
                minM = -1

            thr_rows.append({
                "N": cfg.N,
                "d": cfg.d,
                "stat": cfg.stat_name,
                "frac_observed": frac_obs,
                "meas_sigma": meas_sigma,
                "effect_strength": effect_strength,
                "coherence_mix": coherence_mix,
                "alpha": cfg.alpha,
                "target_power": cfg.target_power,
                "min_events_for_target_power": minM,
            })

            # ROC curve for M=1 (per-event) for a quick model-separation diagnostic
            # (you can also do ROC on the bootstrapped mean for a specific M)
            # We'll compute ROC by sweeping thresholds on combined stats.
            if cfg.roc_points > 0:
                # Use per-event null/alt stats
                combined = np.sort(np.unique(np.concatenate([null_stats, alt_stats])))
                if combined.size == 0:
                    continue
                # pick evenly spaced thresholds over observed range
                idxs = np.linspace(0, combined.size - 1, cfg.roc_points).astype(int)
                for j, tau in enumerate(combined[idxs]):
                    fpr = float(np.mean(null_stats >= tau))
                    tpr = float(np.mean(alt_stats >= tau))
                    roc_rows.append({
                        "N": cfg.N,
                        "d": cfg.d,
                        "stat": cfg.stat_name,
                        "frac_observed": frac_obs,
                        "meas_sigma": meas_sigma,
                        "effect_strength": effect_strength,
                        "coherence_mix": coherence_mix,
                        "roc_point": j,
                        "threshold_tau": float(tau),
                        "FPR": fpr,
                        "TPR": tpr
                    })

            print(f"[done] frac_obs={frac_obs} sigma={meas_sigma} "
                  f"effect={effect_strength} mix={coherence_mix}")

    # Write outputs
    power_path = "toy8_power_curve.csv"
    roc_path = "toy8_roc.csv"
    thr_path = "toy8_thresholds.csv"

    with open(power_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=power_rows[0].keys())
        writer.writeheader()
        for r in power_rows:
            writer.writerow(r)

    with open(roc_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=roc_rows[0].keys())
        writer.writeheader()
        for r in roc_rows:
            writer.writerow(r)

    with open(thr_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=thr_rows[0].keys())
        writer.writeheader()
        for r in thr_rows:
            writer.writerow(r)

    print("Saved:")
    print(f"  {power_path}")
    print(f"  {roc_path}")
    print(f"  {thr_path}")
    print("Toy 8 complete.")


if __name__ == "__main__":
    main()
