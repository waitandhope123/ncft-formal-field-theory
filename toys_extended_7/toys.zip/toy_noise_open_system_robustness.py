#!/usr/bin/env python3
"""
NCFT-core Toy 3: Noise / Open-System Robustness Suite

Broad categorical stress test for NCFT-core under:
- additive state noise (pre-projection)
- dropout (random deactivation/reactivation of nodes)
- external driving to a reference direction ("field")
- optional intrinsic (unprojected) comparison

Outputs: noise_open_system_results.csv
"""

import numpy as np
import csv
from itertools import product


# -------------------------
# Core utilities
# -------------------------

def random_unit_vectors(N, d, rng):
    X = rng.normal(size=(N, d)) + 1j * rng.normal(size=(N, d))
    X /= np.linalg.norm(X, axis=1, keepdims=True)
    return X

def project(psis):
    norms = np.linalg.norm(psis, axis=1, keepdims=True)
    return psis / norms

def compute_inner(psis):
    return psis @ psis.conj().T

def compute_C(psis):
    inner = compute_inner(psis)
    C = np.abs(inner) ** 2
    np.fill_diagonal(C, 0.0)
    return C

def energy_from_C(C):
    # E = - sum_{i<j} C_ij = -0.5 * sum_{i!=j} C_ij
    return -0.5 * float(np.sum(C))

def density_matrix(psis):
    N = psis.shape[0]
    rho = np.zeros((psis.shape[1], psis.shape[1]), dtype=np.complex128)
    for i in range(N):
        rho += np.outer(psis[i], psis[i].conj())
    return rho / N

def effective_rank(rho, eps=1e-15):
    # exp(Shannon entropy of eigenvalues) as an effective rank measure
    w = np.real(np.linalg.eigvalsh(rho))
    w = np.clip(w, 0.0, 1.0)
    s = np.sum(w)
    if s <= eps:
        return np.nan
    p = w / s
    p = p[p > eps]
    H = -np.sum(p * np.log(p))
    return float(np.exp(H))

def add_complex_noise(psis, sigma, rng):
    if sigma <= 0:
        return psis
    noise = rng.normal(size=psis.shape) + 1j * rng.normal(size=psis.shape)
    return psis + sigma * noise

def random_unit_vector(d, rng):
    v = rng.normal(size=(d,)) + 1j * rng.normal(size=(d,))
    v /= np.linalg.norm(v)
    return v


# -------------------------
# NCFT update rules (pairwise fidelity gradient)
# -------------------------

def update_projected(psis, eta, active_mask):
    """
    Projected gradient step on E=-sum_{i<j} |<psi_i|psi_j>|^2 for active nodes only.
    Inactive nodes are held fixed.
    """
    inner = compute_inner(psis)
    grads = np.zeros_like(psis, dtype=np.complex128)

    # Vectorized gradient: grads = -2 * inner @ psis
    grads = -2.0 * (inner @ psis)

    # Apply only to active nodes
    grads[~active_mask] = 0.0

    psis = psis - eta * grads
    psis = project(psis)
    return psis

def update_intrinsic(psis, eta, active_mask):
    """
    Same gradient but without projection. Included only as a robustness comparison.
    """
    inner = compute_inner(psis)
    grads = -2.0 * (inner @ psis)
    grads[~active_mask] = 0.0
    return psis - eta * grads


# -------------------------
# Coherence / regime proxies
# -------------------------

def coherence_proxy_from_C(C):
    """
    A simple coherence proxy from overlaps:
      - mean and concentration of upper-triangular C_ij
    """
    N = C.shape[0]
    vals = C[np.triu_indices(N, 1)]
    return float(np.mean(vals)), float(np.std(vals)), float(np.max(vals))

def dropout_step(active_mask, drop_prob, return_prob, rng):
    """
    Simple open-system activity:
    - active nodes can drop with probability drop_prob
    - inactive nodes can return with probability return_prob
    """
    if drop_prob > 0:
        drops = (rng.random(active_mask.shape) < drop_prob) & active_mask
        active_mask[drops] = False
    if return_prob > 0:
        returns = (rng.random(active_mask.shape) < return_prob) & (~active_mask)
        active_mask[returns] = True
    return active_mask

def apply_external_drive(psis, drive_strength, ref_vec, active_mask):
    """
    Pull active states weakly toward ref_vec (then projection will normalize).
    """
    if drive_strength <= 0:
        return psis
    psis2 = psis.copy()
    psis2[active_mask] = (1.0 - drive_strength) * psis2[active_mask] + drive_strength * ref_vec
    return psis2


# -------------------------
# Metrics
# -------------------------

def compute_metrics(psis, C, E_hist, active_mask):
    N, d = psis.shape
    norms = np.linalg.norm(psis, axis=1)
    max_norm_err = float(np.max(np.abs(norms - 1.0)))

    iu = np.triu_indices(N, 1)
    Cvals = C[iu]
    sumC = float(np.sum(Cvals))

    rho = density_matrix(psis)
    purity = float(np.real(np.trace(rho @ rho)))
    purity_rhs = (N + 2.0 * sumC) / (N ** 2)
    purity_err = float(abs(purity - purity_rhs))

    dE = np.diff(E_hist) if len(E_hist) >= 2 else np.array([])
    lyap = float(np.mean(dE <= 1e-12)) if dE.size else np.nan

    c_mean, c_std, c_max = coherence_proxy_from_C(C)

    return {
        "N": int(N),
        "d": int(d),
        "active_frac_final": float(np.mean(active_mask)),
        "max_norm_err": max_norm_err,
        "gt1_count": int(np.sum(Cvals > 1.0 + 1e-12)),
        "C_mean": c_mean,
        "C_std": c_std,
        "C_max": c_max,
        "F_unweighted": sumC,
        "energy_final": float(E_hist[-1]) if E_hist else np.nan,
        "lyapunov_frac_nonincreasing": lyap,
        "purity": purity,
        "purity_identity_abs_err": purity_err,
        "eff_rank": effective_rank(rho),
    }


# -------------------------
# Experiment runner
# -------------------------

def run_one(
    N=24,
    d=16,
    eta=0.02,
    steps=400,
    seed=0,
    projected=True,
    sigma_noise=0.0,          # additive complex noise per step (pre-projection)
    drop_prob=0.0,            # active -> inactive probability per step
    return_prob=0.0,          # inactive -> active probability per step
    drive_strength=0.0        # pull toward reference vector
):
    rng = np.random.default_rng(seed)
    psis = random_unit_vectors(N, d, rng)
    active_mask = np.ones((N,), dtype=bool)

    ref_vec = random_unit_vector(d, rng)

    E_hist = []
    terminated_early = False
    term_reason = ""

    for t in range(steps):
        # Open-system: dropout/return
        active_mask = dropout_step(active_mask, drop_prob, return_prob, rng)

        # External drive (applied before noise and before update)
        psis = apply_external_drive(psis, drive_strength, ref_vec, active_mask)

        # Add noise (pre-projection)
        psis = add_complex_noise(psis, sigma_noise, rng)

        # If projected dynamics, normalization is enforced after update.
        # Still: if values explode (e.g., intrinsic), stop early.
        if projected:
            psis = project(psis)

        # Compute energy before update (diagnostics)
        C = compute_C(psis)
        E_hist.append(energy_from_C(C))

        # Update
        if projected:
            psis = update_projected(psis, eta, active_mask)
        else:
            psis = update_intrinsic(psis, eta, active_mask)

        # Early stop if intrinsic diverges
        norms = np.linalg.norm(psis, axis=1)
        if np.any(~np.isfinite(norms)) or np.max(norms) > 1e6:
            terminated_early = True
            term_reason = "diverged"
            break

    # Final metrics
    if projected:
        psis = project(psis)

    C = compute_C(psis)
    metrics = compute_metrics(psis, C, E_hist, active_mask)
    metrics.update({
        "eta": float(eta),
        "steps": int(steps),
        "seed": int(seed),
        "projected": bool(projected),
        "sigma_noise": float(sigma_noise),
        "drop_prob": float(drop_prob),
        "return_prob": float(return_prob),
        "drive_strength": float(drive_strength),
        "terminated_early": bool(terminated_early),
        "term_reason": term_reason,
        "steps_completed": int(len(E_hist)),
    })
    return metrics


# -------------------------
# Main sweep
# -------------------------

def main():
    # Broad but tractable sweep
    Ns = [24]
    ds = [8, 16]
    etas = [0.02]
    steps = 500
    seeds = [7, 42]  # small ensemble; increase later if desired

    # Noise levels (you will see coherence collapse as sigma increases)
    sigmas = [0.0, 0.005, 0.01, 0.02, 0.05]

    # Open-system activity settings
    #  (dropout only, dropout+return, and "stable")
    dropout_settings = [
        (0.0, 0.0),     # closed system
        (0.002, 0.0),   # mild dropout
        (0.002, 0.002), # dropout with recovery
    ]

    # External driving strengths
    drives = [0.0, 0.01]

    # Compare projected (core) to intrinsic (control)
    projected_opts = [True, False]

    rows = []
    for (N, d, eta, seed, sigma, (dp, rp), drive, proj) in product(
        Ns, ds, etas, seeds, sigmas, dropout_settings, drives, projected_opts
    ):
        print(f"Run N={N} d={d} eta={eta} seed={seed} proj={proj} "
              f"sigma={sigma} drop={dp} return={rp} drive={drive}")
        rows.append(run_one(
            N=N, d=d, eta=eta, steps=steps, seed=seed,
            projected=proj,
            sigma_noise=sigma,
            drop_prob=dp,
            return_prob=rp,
            drive_strength=drive
        ))

    outpath = "noise_open_system_results.csv"
    with open(outpath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        for r in rows:
            writer.writerow(r)

    print(f"Saved {outpath}")

if __name__ == "__main__":
    main()
