#!/usr/bin/env python3
"""
NCFT-core Toy 2: Topology & Kernel Stress

Runs projected NCFT-core dynamics with graph-weighted pairwise interactions:
    F_G = sum_{i<j} w_ij * |<psi_i|psi_j>|^2

Tests universality of invariants across graph types:
- complete
- ER (Erdos-Renyi)
- ring-k
- small-world (Watts-Strogatz)

Outputs: topology_kernel_stress_results.csv
"""

import numpy as np
import csv
from dataclasses import dataclass


# -------------------------
# Graph generation
# -------------------------

def graph_complete(N):
    W = np.ones((N, N), dtype=np.float64)
    np.fill_diagonal(W, 0.0)
    return W

def graph_er(N, p, rng):
    A = (rng.random((N, N)) < p).astype(np.float64)
    A = np.triu(A, 1)
    A = A + A.T
    return A

def graph_ring_k(N, k):
    # each node connected to k neighbors on each side => degree 2k
    A = np.zeros((N, N), dtype=np.float64)
    for i in range(N):
        for s in range(1, k + 1):
            j1 = (i + s) % N
            j2 = (i - s) % N
            A[i, j1] = 1.0
            A[i, j2] = 1.0
    return A

def graph_small_world(N, k, beta, rng):
    """
    Watts-Strogatz style:
    start from ring-k (degree 2k), then rewire each directed edge with prob beta.
    """
    if k < 1:
        raise ValueError("k must be >= 1")
    A = graph_ring_k(N, k)
    # Rewire edges i -> (i+s) for s=1..k (one direction to avoid double handling)
    for i in range(N):
        for s in range(1, k + 1):
            j = (i + s) % N
            if rng.random() < beta:
                # remove edge (i,j)
                A[i, j] = 0.0
                A[j, i] = 0.0
                # add edge (i,newj) with newj != i and not currently connected
                candidates = [x for x in range(N) if x != i and A[i, x] == 0.0]
                if candidates:
                    newj = rng.choice(candidates)
                    A[i, newj] = 1.0
                    A[newj, i] = 1.0
    return A

def graph_stats(A):
    N = A.shape[0]
    deg = A.sum(axis=1)
    edges = int(A.sum() / 2)
    return {
        "edges": edges,
        "deg_mean": float(np.mean(deg)),
        "deg_std": float(np.std(deg)),
        "deg_min": float(np.min(deg)),
        "deg_max": float(np.max(deg)),
        "density": float(edges / (N * (N - 1) / 2)),
    }


# -------------------------
# NCFT-core utilities
# -------------------------

def random_unit_vectors(N, d, rng):
    X = rng.normal(size=(N, d)) + 1j * rng.normal(size=(N, d))
    X /= np.linalg.norm(X, axis=1, keepdims=True)
    return X

def project(psis):
    return psis / np.linalg.norm(psis, axis=1, keepdims=True)

def compute_inner(psis):
    return psis @ psis.conj().T

def compute_C_from_inner(inner):
    C = np.abs(inner) ** 2
    np.fill_diagonal(C, 0.0)
    return C

def energy_graph(C, W):
    # E = - sum_{i<j} w_ij C_ij  (use 1/2 factor for symmetry)
    return -0.5 * float(np.sum(W * C))

def density_matrix(psis):
    N = psis.shape[0]
    rho = np.zeros((psis.shape[1], psis.shape[1]), dtype=np.complex128)
    for i in range(N):
        rho += np.outer(psis[i], psis[i].conj())
    return rho / N


# -------------------------
# Graph-weighted projected dynamics
# -------------------------

def update_projected_graph(psis, W, eta):
    """
    Gradient descent on E = -0.5 * sum_{i,j} w_ij |<psi_i|psi_j>|^2
    with per-step renormalization.

    Uses:
      inner_ij = <psi_i|psi_j>
      |inner_ij|^2 = inner_ij * conj(inner_ij)
    Gradient (up to a constant factor) is:
      grad_i ~ - sum_j w_ij * inner_ij * psi_j
    We use a stable form and then project.
    """
    inner = compute_inner(psis)  # (N,N) complex
    grads = np.zeros_like(psis, dtype=np.complex128)

    # Vectorized computation:
    # For fixed i: sum_j (w_ij * inner_ij) psi_j
    # Build M = W * inner  (elementwise), then grads = -2 * M @ psis
    M = (W * inner)
    grads = -2.0 * (M @ psis)

    psis = psis - eta * grads
    psis = project(psis)
    return psis


# -------------------------
# Metrics
# -------------------------

def compute_metrics(psis, W, E_hist):
    N, d = psis.shape
    inner = compute_inner(psis)
    C = compute_C_from_inner(inner)

    # only i<j values
    iu = np.triu_indices(N, 1)
    Cvals = C[iu]
    Wvals = W[iu]

    sumC = float(np.sum(Cvals))
    sumWC = float(np.sum(Wvals * Cvals))

    norms = np.linalg.norm(psis, axis=1)
    max_norm_err = float(np.max(np.abs(norms - 1.0)))

    dE = np.diff(E_hist)
    lyap = float(np.mean(dE <= 1e-12)) if len(dE) > 0 else np.nan

    rho = density_matrix(psis)
    purity = float(np.real(np.trace(rho @ rho)))
    purity_rhs = (N + 2.0 * sumC) / (N ** 2)
    purity_err = float(abs(purity - purity_rhs))

    # Graph-weighted "energy consistency" is separate from purity identity, which is unweighted.
    return {
        "N": N,
        "d": d,
        "eta": float(E_hist and 0.0 or 0.0),  # placeholder overwritten by caller
        "steps": int(len(E_hist)),
        "C_mean": float(np.mean(Cvals)),
        "C_std": float(np.std(Cvals)),
        "C_max": float(np.max(Cvals)),
        "gt1_count": int(np.sum(Cvals > 1.0 + 1e-12)),
        "max_norm_err": max_norm_err,
        "F_unweighted": sumC,
        "F_weighted": sumWC,
        "energy_final": float(E_hist[-1]) if E_hist else np.nan,
        "lyapunov_frac_nonincreasing": lyap,
        "purity": purity,
        "purity_identity_abs_err": purity_err,
        "W_mean": float(np.mean(Wvals)),
        "W_density": float(np.mean(Wvals > 0.0)),
    }


# -------------------------
# Experiment runner
# -------------------------

@dataclass
class RunSpec:
    graph_type: str
    N: int
    d: int
    eta: float
    steps: int
    seed: int
    # graph params
    p: float = 0.0       # ER
    k: int = 0           # ring / small-world
    beta: float = 0.0    # small-world


def build_graph(spec: RunSpec, rng):
    if spec.graph_type == "complete":
        return graph_complete(spec.N)
    if spec.graph_type == "er":
        return graph_er(spec.N, spec.p, rng)
    if spec.graph_type == "ring":
        return graph_ring_k(spec.N, spec.k)
    if spec.graph_type == "small_world":
        return graph_small_world(spec.N, spec.k, spec.beta, rng)
    raise ValueError(f"Unknown graph_type: {spec.graph_type}")

def run_one(spec: RunSpec):
    rng = np.random.default_rng(spec.seed)
    psis = random_unit_vectors(spec.N, spec.d, rng)
    W = build_graph(spec, rng)

    E_hist = []
    for _ in range(spec.steps):
        inner = compute_inner(psis)
        C = compute_C_from_inner(inner)
        E_hist.append(energy_graph(C, W))
        psis = update_projected_graph(psis, W, spec.eta)

    metrics = compute_metrics(psis, W, E_hist)
    metrics["eta"] = spec.eta
    metrics["graph_type"] = spec.graph_type
    metrics["seed"] = spec.seed

    # graph params + stats
    metrics["p"] = spec.p
    metrics["k"] = spec.k
    metrics["beta"] = spec.beta
    metrics.update({f"graph_{k}": v for k, v in graph_stats(W).items()})

    return metrics


# -------------------------
# Main sweep
# -------------------------

def main():
    # Keep it broad but not huge.
    runs = []

    # Baseline sweep points
    Ns = [12, 24]
    ds = [8, 16]
    etas = [0.01, 0.05]
    steps = 300
    seed = 42

    # Graph parameterizations
    for N in Ns:
        for d in ds:
            for eta in etas:
                # complete graph
                runs.append(RunSpec(graph_type="complete", N=N, d=d, eta=eta, steps=steps, seed=seed))

                # ER graphs (match density roughly)
                # choose p to yield moderate density; clamp for small N
                p = min(0.25, max(0.10, 8.0 / (N - 1)))
                runs.append(RunSpec(graph_type="er", N=N, d=d, eta=eta, steps=steps, seed=seed, p=p))

                # ring degree 2k ~ 8 (if possible)
                k = max(1, min(4, (N - 1) // 2))
                runs.append(RunSpec(graph_type="ring", N=N, d=d, eta=eta, steps=steps, seed=seed, k=k))

                # small-world: start ring-k, rewire beta
                runs.append(RunSpec(graph_type="small_world", N=N, d=d, eta=eta, steps=steps, seed=seed, k=k, beta=0.2))

    rows = []
    for idx, spec in enumerate(runs, 1):
        print(f"[{idx}/{len(runs)}] graph={spec.graph_type} N={spec.N} d={spec.d} eta={spec.eta} "
              f"(p={spec.p} k={spec.k} beta={spec.beta})")
        rows.append(run_one(spec))

    outpath = "topology_kernel_stress_results.csv"
    with open(outpath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        for r in rows:
            writer.writerow(r)

    print(f"Saved {outpath}")

if __name__ == "__main__":
    main()
