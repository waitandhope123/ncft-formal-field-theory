#!/usr/bin/env python3
"""
NCFT-core Toy 9: Signature Miner + Competing-Model Discriminator
===============================================================

WHY THIS FLUSHES THE THEORY OUT (HARD)
--------------------------------------
Toys 1–8 establish NCFT-core coherence, robustness, inference limits, coarse-grain behavior,
and statistical falsifiability *given a chosen statistic*.

Toy 9 does something different and extremely valuable:
    It automatically discovers WHICH OBSERVABLES (signatures) best separate NCFT-core
    from plausible alternative dynamical models.

That gives you:
1) A shortlist of *unique physical signatures* of NCFT (not cherry-picked).
2) Better predictions: "If NCFT is true, you should see signature X, Y, Z."
3) A principled way to refine the theory (what is essential vs incidental).

WHAT IT DOES
------------
- Simulates multiple dynamical models that all live on unit-normalized complex state vectors.
- Generates many "events" (runs) for each model.
- Extracts a large feature set from observables (C matrix, spectrum, density matrix, trajectories).
- Trains a simple classifier (no sklearn) to distinguish NCFT vs non-NCFT.
- Ranks features by discriminative power.

MODELS INCLUDED
---------------
- "ncft_projected"  : your projected Lyapunov descent (NCFT-core)
- "ncft_intrinsic"  : unprojected (should fail / blow up or behave differently)
- "kuramoto_like"   : phase-only coherence dynamics (control)
- "random_sphere_rw": random walk on unit sphere (null dynamical control)
- "hebbian_align"   : simple attractive alignment on overlaps (control)

OUTPUT FILES
------------
1) toy9_features.csv
   One row per run with: model label + feature columns

2) toy9_results.csv
   Summary: accuracy, confusion-like counts, and top feature rankings

3) toy9_feature_ranking.csv
   Feature ranking by:
   - Fisher score (between-class separation)
   - AUC proxy (threshold sweep on 1D feature)

RUN
---
python toy9_signature_miner_model_discriminator.py

INTERPRETATION
--------------
If Toy 9 says a small set of features perfectly separates NCFT from alternatives,
those features are your best "physics-precise" predictions.

If separation is weak, it tells you NCFT is not uniquely identifiable from these observables alone,
and you need new measurement channels (or revised claims).
"""

import numpy as np
import csv
from dataclasses import dataclass
from itertools import product
from typing import Dict, List, Tuple


# -------------------------
# Utilities
# -------------------------

def rng_cplx_normal(shape, rng):
    return rng.normal(size=shape) + 1j * rng.normal(size=shape)

def project(psis: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(psis, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return psis / norms

def random_unit_vectors(N: int, d: int, rng: np.random.Generator) -> np.ndarray:
    return project(rng_cplx_normal((N, d), rng))

def compute_inner(psis: np.ndarray) -> np.ndarray:
    return psis @ psis.conj().T

def compute_C(psis: np.ndarray) -> np.ndarray:
    inner = compute_inner(psis)
    C = np.abs(inner) ** 2
    np.fill_diagonal(C, 0.0)
    return C

def energy_from_C(C: np.ndarray, W: np.ndarray = None) -> float:
    if W is None:
        return -0.5 * float(np.sum(C))
    return -0.5 * float(np.sum(W * C))

def density_matrix(psis: np.ndarray) -> np.ndarray:
    N = psis.shape[0]
    rho = np.zeros((psis.shape[1], psis.shape[1]), dtype=np.complex128)
    for i in range(N):
        rho += np.outer(psis[i], psis[i].conj())
    return rho / N

def purity_identity_abs_err(psis: np.ndarray, C: np.ndarray) -> float:
    N = psis.shape[0]
    vals = C[np.triu_indices(N, 1)]
    sumC = float(np.sum(vals))
    rho = density_matrix(psis)
    purity = float(np.real(np.trace(rho @ rho)))
    rhs = (N + 2.0 * sumC) / (N ** 2)
    return float(abs(purity - rhs))

def eff_rank(rho: np.ndarray, eps: float = 1e-15) -> float:
    w = np.real(np.linalg.eigvalsh(rho))
    w = np.clip(w, 0.0, 1.0)
    s = float(np.sum(w))
    if s <= eps:
        return float("nan")
    p = w / s
    p = p[p > eps]
    H = -np.sum(p * np.log(p))
    return float(np.exp(H))

def upper_vals(A: np.ndarray) -> np.ndarray:
    return A[np.triu_indices(A.shape[0], 1)]

def safe_mean(x: np.ndarray) -> float:
    return float(np.mean(x)) if x.size else 0.0

def safe_std(x: np.ndarray) -> float:
    return float(np.std(x)) if x.size else 0.0

def safe_kurtosis(x: np.ndarray) -> float:
    # Excess kurtosis-ish (moment-based); robust enough for ranking features
    if x.size < 4:
        return 0.0
    m = np.mean(x)
    v = np.mean((x - m) ** 2)
    if v <= 1e-15:
        return 0.0
    k = np.mean((x - m) ** 4) / (v ** 2)
    return float(k - 3.0)

def spectral_stats_symmetric(A: np.ndarray) -> Tuple[float, float, float, float]:
    # eigenvalues of real symmetric A
    w = np.linalg.eigvalsh((A + A.T) / 2.0)
    return float(np.max(w)), float(np.min(w)), float(np.mean(w)), float(np.std(w))

def triangle_density(C: np.ndarray, thresh: float) -> float:
    """
    Graph triangle density on adjacency = (C > thresh).
    """
    A = (C > thresh).astype(np.float64)
    np.fill_diagonal(A, 0.0)
    # triangles = trace(A^3)/6 for undirected no self loops
    tri = float(np.trace(A @ A @ A)) / 6.0
    N = C.shape[0]
    denom = (N * (N - 1) * (N - 2)) / 6.0 if N >= 3 else 1.0
    return float(tri / denom) if denom > 0 else 0.0


# -------------------------
# Model Dynamics
# -------------------------

def step_ncft_projected(psis: np.ndarray, eta: float) -> np.ndarray:
    inner = compute_inner(psis)
    grads = -2.0 * (inner @ psis)
    psis = psis - eta * grads
    return project(psis)

def step_ncft_intrinsic(psis: np.ndarray, eta: float) -> np.ndarray:
    inner = compute_inner(psis)
    grads = -2.0 * (inner @ psis)
    return psis - eta * grads  # no projection on purpose

def step_kuramoto_like(psis: np.ndarray, eta: float) -> np.ndarray:
    """
    Keep amplitudes fixed by projection; update phases toward mean phase.
    Uses each component phase; this is a phase-coherence control model.
    """
    # compute mean phase per dimension
    phases = np.angle(psis)
    mean_phase = np.angle(np.mean(np.exp(1j * phases), axis=0))
    # move phases toward mean
    new_phases = phases + eta * np.sin(mean_phase[None, :] - phases)
    psis2 = np.abs(psis) * np.exp(1j * new_phases)
    return project(psis2)

def step_random_sphere_rw(psis: np.ndarray, eta: float, rng: np.random.Generator) -> np.ndarray:
    psis2 = psis + eta * rng_cplx_normal(psis.shape, rng)
    return project(psis2)

def step_hebbian_align(psis: np.ndarray, eta: float) -> np.ndarray:
    """
    Simple attractive alignment: psi_i <- psi_i + eta * sum_j <psi_i|psi_j> psi_j
    then project. This is a plausible alternative attractive dynamics.
    """
    inner = compute_inner(psis)
    psis2 = psis + eta * (inner @ psis)
    return project(psis2)

def simulate_model(
    model: str,
    N: int,
    d: int,
    eta: float,
    steps: int,
    rng: np.random.Generator
) -> Tuple[np.ndarray, Dict[str, float]]:
    psis = random_unit_vectors(N, d, rng)
    E_hist = []
    norm_err_hist = []
    gt1_hist = []
    nan_flag = 0

    for _ in range(steps):
        if model == "ncft_projected":
            psis = step_ncft_projected(psis, eta)
        elif model == "ncft_intrinsic":
            psis = step_ncft_intrinsic(psis, eta)
        elif model == "kuramoto_like":
            psis = step_kuramoto_like(psis, eta)
        elif model == "random_sphere_rw":
            psis = step_random_sphere_rw(psis, eta, rng)
        elif model == "hebbian_align":
            psis = step_hebbian_align(psis, eta)
        else:
            raise ValueError("Unknown model")

        if np.any(~np.isfinite(psis.real)) or np.any(~np.isfinite(psis.imag)):
            nan_flag = 1
            break

        # observable diagnostics (even for intrinsic)
        C = compute_C(project(psis))  # compute observables on projected view
        E_hist.append(energy_from_C(C))
        norms = np.linalg.norm(psis, axis=1)
        norm_err_hist.append(float(np.max(np.abs(norms - 1.0))))
        gt1_hist.append(float(np.sum(upper_vals(C) > 1.0 + 1e-12)))

    # final projected view for feature extraction
    psis_final = project(psis) if nan_flag == 0 else project(np.nan_to_num(psis, nan=0.0, posinf=0.0, neginf=0.0))
    C_final = compute_C(psis_final)

    metrics = {
        "nan_flag": float(nan_flag),
        "E0": float(E_hist[0]) if len(E_hist) else float("nan"),
        "E_final": float(E_hist[-1]) if len(E_hist) else float("nan"),
        "E_drop": float(E_hist[0] - E_hist[-1]) if len(E_hist) else float("nan"),
        "lyapunov_frac_nonincreasing": float(np.mean(np.diff(E_hist) <= 1e-12)) if len(E_hist) > 2 else float("nan"),
        "max_norm_err_over_traj": float(np.max(norm_err_hist)) if norm_err_hist else float("nan"),
        "gt1_sum_over_traj": float(np.sum(gt1_hist)) if gt1_hist else float("nan"),
    }
    return psis_final, metrics


# -------------------------
# Feature Extraction
# -------------------------

def extract_features(psis: np.ndarray) -> Dict[str, float]:
    C = compute_C(psis)
    vals = upper_vals(C)

    rho = density_matrix(psis)
    pr_err = purity_identity_abs_err(psis, C)
    er = eff_rank(rho)

    # spectrum features
    lam_max, lam_min, lam_mu, lam_sd = spectral_stats_symmetric(C)

    # density matrix spectrum stats
    ew = np.real(np.linalg.eigvalsh(rho))
    ew = np.clip(ew, 0.0, 1.0)
    ew_sorted = np.sort(ew)[::-1]
    top1 = float(ew_sorted[0]) if ew_sorted.size else 0.0
    top2 = float(ew_sorted[1]) if ew_sorted.size > 1 else 0.0
    gap12 = float(top1 - top2)

    # triangle density at two thresholds (captures "clique-iness")
    tri_02 = triangle_density(C, 0.2)
    tri_05 = triangle_density(C, 0.5)

    # tail masses (distributional signatures)
    tail_02 = float(np.mean(vals >= 0.2)) if vals.size else 0.0
    tail_05 = float(np.mean(vals >= 0.5)) if vals.size else 0.0
    tail_08 = float(np.mean(vals >= 0.8)) if vals.size else 0.0

    return {
        "C_mean": safe_mean(vals),
        "C_std": safe_std(vals),
        "C_kurtosis": safe_kurtosis(vals),
        "C_max": float(np.max(vals)) if vals.size else 0.0,
        "C_tail_ge_02": tail_02,
        "C_tail_ge_05": tail_05,
        "C_tail_ge_08": tail_08,
        "C_eig_max": lam_max,
        "C_eig_min": lam_min,
        "C_eig_mean": lam_mu,
        "C_eig_std": lam_sd,
        "purity_identity_abs_err": float(pr_err),
        "eff_rank": float(er),
        "rho_eig_top1": top1,
        "rho_eig_gap12": gap12,
        "tri_density_02": tri_02,
        "tri_density_05": tri_05,
    }


# -------------------------
# Feature Ranking + Simple Classification
# -------------------------

def fisher_score(x_pos: np.ndarray, x_neg: np.ndarray, eps: float = 1e-12) -> float:
    """
    Fisher score for 1D feature: (mu1 - mu0)^2 / (var1 + var0)
    """
    mu1, mu0 = np.mean(x_pos), np.mean(x_neg)
    v1, v0 = np.var(x_pos), np.var(x_neg)
    return float((mu1 - mu0) ** 2 / (v1 + v0 + eps))

def auc_proxy(x_pos: np.ndarray, x_neg: np.ndarray) -> float:
    """
    AUC for 1D feature via Mann-Whitney U estimate:
    AUC = P(x_pos > x_neg) + 0.5 P(equal)
    """
    # O(n^2) but ok for toy sizes. If too slow, reduce runs_per_model.
    cnt = 0.0
    tot = float(len(x_pos) * len(x_neg))
    for a in x_pos:
        cnt += float(np.sum(a > x_neg)) + 0.5 * float(np.sum(a == x_neg))
    return float(cnt / tot) if tot > 0 else 0.5

def standardize(X: np.ndarray, eps: float = 1e-12) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    mu = np.mean(X, axis=0)
    sd = np.std(X, axis=0)
    sd[sd < eps] = 1.0
    return (X - mu) / sd, mu, sd

def train_nearest_centroid(X: np.ndarray, y: np.ndarray) -> Dict:
    """
    Very simple classifier: nearest centroid in standardized feature space.
    Returns centroids for each class.
    """
    classes = np.unique(y)
    centroids = {}
    for c in classes:
        centroids[int(c)] = np.mean(X[y == c], axis=0)
    return {"classes": classes, "centroids": centroids}

def predict_nearest_centroid(model: Dict, X: np.ndarray) -> np.ndarray:
    classes = model["classes"]
    cents = model["centroids"]
    preds = np.zeros(X.shape[0], dtype=int)
    for i in range(X.shape[0]):
        best_c = int(classes[0])
        best_d = float("inf")
        for c in classes:
            d = float(np.sum((X[i] - cents[int(c)]) ** 2))
            if d < best_d:
                best_d = d
                best_c = int(c)
        preds[i] = best_c
    return preds

def accuracy(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.mean(y_true == y_pred)) if y_true.size else 0.0


# -------------------------
# Config
# -------------------------

@dataclass
class Config:
    N: int = 24
    d: int = 16
    steps: int = 250

    # Use modest etas so controls don't trivially explode;
    # intrinsic still tends to misbehave in signature ways.
    eta_map: Dict[str, float] = None

    models: Tuple[str, ...] = (
        "ncft_projected",
        "ncft_intrinsic",
        "kuramoto_like",
        "random_sphere_rw",
        "hebbian_align",
    )

    runs_per_model: int = 120
    seed: int = 123

    # Classification goal:
    # "ncft_projected" vs "non_ncft" (all others pooled)
    classify_ncft_vs_rest: bool = True

    out_features_csv: str = "toy9_features.csv"
    out_ranking_csv: str = "toy9_feature_ranking.csv"
    out_results_csv: str = "toy9_results.csv"


# -------------------------
# Main
# -------------------------

def main():
    cfg = Config()
    if cfg.eta_map is None:
        cfg.eta_map = {
            "ncft_projected": 0.02,
            "ncft_intrinsic": 0.02,
            "kuramoto_like": 0.08,
            "random_sphere_rw": 0.05,
            "hebbian_align": 0.04,
        }

    rng = np.random.default_rng(cfg.seed)

    rows: List[Dict] = []
    feature_names: List[str] = []

    # ---- Generate dataset ----
    for model_name in cfg.models:
        eta = cfg.eta_map.get(model_name, 0.02)
        for r in range(cfg.runs_per_model):
            psis, metrics = simulate_model(
                model=model_name,
                N=cfg.N,
                d=cfg.d,
                eta=eta,
                steps=cfg.steps,
                rng=rng
            )
            feats = extract_features(psis)

            if not feature_names:
                feature_names = list(feats.keys()) + list(metrics.keys())

            row = {
                "model": model_name,
                "run": r,
                "N": cfg.N,
                "d": cfg.d,
                "steps": cfg.steps,
                "eta": float(eta),
            }
            row.update(feats)
            row.update(metrics)
            rows.append(row)

        print(f"[done] {model_name} ({cfg.runs_per_model} runs)")

    # ---- Save features table ----
    with open(cfg.out_features_csv, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        for r in rows:
            writer.writerow(r)
    print(f"Saved {cfg.out_features_csv}")

    # ---- Build arrays for ranking + classification ----
    X = np.array([[row[name] for name in feature_names] for row in rows], dtype=float)

    if cfg.classify_ncft_vs_rest:
        y = np.array([1 if row["model"] == "ncft_projected" else 0 for row in rows], dtype=int)
        pos_label = 1
    else:
        # multi-class not implemented in ranking summary; keep binary for now
        y = np.array([cfg.models.index(row["model"]) for row in rows], dtype=int)
        pos_label = 0

    # standardize
    Xs, mu, sd = standardize(X)

    # train/test split
    idx = np.arange(len(rows))
    rng.shuffle(idx)
    split = int(0.8 * len(idx))
    tr, te = idx[:split], idx[split:]

    model = train_nearest_centroid(Xs[tr], y[tr])
    y_pred = predict_nearest_centroid(model, Xs[te])

    acc = accuracy(y[te], y_pred)

    # confusion-ish counts (binary case)
    tp = int(np.sum((y[te] == 1) & (y_pred == 1)))
    tn = int(np.sum((y[te] == 0) & (y_pred == 0)))
    fp = int(np.sum((y[te] == 0) & (y_pred == 1)))
    fn = int(np.sum((y[te] == 1) & (y_pred == 0)))

    # ---- Feature ranking (NCFT vs rest) ----
    ranking_rows = []
    x_pos = X[y == pos_label]
    x_neg = X[y != pos_label]

    for j, name in enumerate(feature_names):
        a = x_pos[:, j]
        b = x_neg[:, j]
        fs = fisher_score(a, b)
        # AUC proxy for 1D; invert if needed so that >=0.5
        auc = auc_proxy(a, b)
        if auc < 0.5:
            auc = 1.0 - auc
        ranking_rows.append({
            "feature": name,
            "fisher_score": float(fs),
            "auc_proxy_abs": float(auc),
            "pos_mean": float(np.mean(a)),
            "neg_mean": float(np.mean(b)),
            "pos_std": float(np.std(a)),
            "neg_std": float(np.std(b)),
        })

    ranking_rows.sort(key=lambda r: (r["fisher_score"], r["auc_proxy_abs"]), reverse=True)

    with open(cfg.out_ranking_csv, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(ranking_rows[0].keys()))
        writer.writeheader()
        for r in ranking_rows:
            writer.writerow(r)
    print(f"Saved {cfg.out_ranking_csv}")

    # ---- Save results summary ----
    topk = 12
    results_rows = [{
        "task": "ncft_projected_vs_rest",
        "N": cfg.N,
        "d": cfg.d,
        "steps": cfg.steps,
        "runs_per_model": cfg.runs_per_model,
        "num_models": len(cfg.models),
        "test_accuracy": float(acc),
        "tp": tp,
        "tn": tn,
        "fp": fp,
        "fn": fn,
        "top_features_by_fisher": ";".join([r["feature"] for r in ranking_rows[:topk]]),
    }]

    with open(cfg.out_results_csv, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(results_rows[0].keys()))
        writer.writeheader()
        writer.writerow(results_rows[0])
    print(f"Saved {cfg.out_results_csv}")

    print("Toy 9 complete.")
    print(f"Test accuracy (nearest-centroid, standardized): {acc:.3f}")
    print("Top discriminative features:")
    for r in ranking_rows[:10]:
        print(f"  {r['feature']}: fisher={r['fisher_score']:.4g}, auc~={r['auc_proxy_abs']:.3f}")


if __name__ == "__main__":
    main()
