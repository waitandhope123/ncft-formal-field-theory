#!/usr/bin/env python3
"""
NCFT-core Toy 6: Variational / Energy-Landscape Geometry

GOAL
----
Characterize the NCFT-core energy landscape by:
- running many random initial conditions ("restarts")
- evolving under projected dynamics (Lyapunov gradient flow)
- detecting distinct attractors / minima via clustering of final overlap structure
- estimating basin sizes and (optionally) noise-assisted transition rates

WHAT YOU GET
------------
1) energy_landscape_runs.csv
   One row per restart with: final energy, coherence stats, purity identity error,
   effective rank, and a "basin_id" (cluster label).

2) energy_landscape_basins.csv
   One row per discovered basin with: count (basin volume proxy),
   mean energy, mean C_mean, mean eff_rank.

3) (Optional) energy_landscape_transitions.csv
   If enabled, runs noise-assisted perturbations from basin representatives
   and records transition probabilities between basins.

This toy is *theory-shaping*: it tells you whether NCFT is single-attractor,
multi-attractor, or glassy (many metastable basins), and whether history matters.
"""

import numpy as np
import csv
from dataclasses import dataclass
from typing import List, Tuple, Dict, Optional


# -------------------------
# Core NCFT utilities
# -------------------------

def random_unit_vectors(N: int, d: int, rng: np.random.Generator) -> np.ndarray:
    X = rng.normal(size=(N, d)) + 1j * rng.normal(size=(N, d))
    X /= np.linalg.norm(X, axis=1, keepdims=True)
    return X

def project(psis: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(psis, axis=1, keepdims=True)
    return psis / norms

def compute_inner(psis: np.ndarray) -> np.ndarray:
    return psis @ psis.conj().T

def compute_C(psis: np.ndarray) -> np.ndarray:
    inner = compute_inner(psis)
    C = np.abs(inner) ** 2
    np.fill_diagonal(C, 0.0)
    return C

def energy_from_C(C: np.ndarray) -> float:
    # E = - sum_{i<j} C_ij = -0.5 * sum_{i!=j} C_ij
    return -0.5 * float(np.sum(C))

def density_matrix(psis: np.ndarray) -> np.ndarray:
    N = psis.shape[0]
    rho = np.zeros((psis.shape[1], psis.shape[1]), dtype=np.complex128)
    for i in range(N):
        rho += np.outer(psis[i], psis[i].conj())
    return rho / N

def effective_rank(rho: np.ndarray, eps: float = 1e-15) -> float:
    w = np.real(np.linalg.eigvalsh(rho))
    w = np.clip(w, 0.0, 1.0)
    s = np.sum(w)
    if s <= eps:
        return float("nan")
    p = w / s
    p = p[p > eps]
    H = -np.sum(p * np.log(p))
    return float(np.exp(H))

def coherence_stats_from_C(C: np.ndarray) -> Tuple[float, float, float]:
    N = C.shape[0]
    vals = C[np.triu_indices(N, 1)]
    return float(np.mean(vals)), float(np.std(vals)), float(np.max(vals))

def purity_identity_error(psis: np.ndarray, C: np.ndarray) -> float:
    N = psis.shape[0]
    vals = C[np.triu_indices(N, 1)]
    sumC = float(np.sum(vals))
    rho = density_matrix(psis)
    purity = float(np.real(np.trace(rho @ rho)))
    rhs = (N + 2.0 * sumC) / (N ** 2)
    return float(abs(purity - rhs))


# -------------------------
# Projected gradient dynamics
# -------------------------

def update_projected(psis: np.ndarray, eta: float, steps: int) -> Tuple[np.ndarray, List[float]]:
    """
    Projected gradient flow on E = -sum_{i<j} |<psi_i|psi_j>|^2.
    Returns final psis and energy history.
    """
    E_hist = []
    for _ in range(steps):
        C = compute_C(psis)
        E_hist.append(energy_from_C(C))
        inner = compute_inner(psis)
        grads = -2.0 * (inner @ psis)
        psis = psis - eta * grads
        psis = project(psis)
    return psis, E_hist


# -------------------------
# Basin fingerprinting + clustering
# -------------------------

def basin_fingerprint(C: np.ndarray, bins: int = 32) -> np.ndarray:
    """
    Create a permutation-invariant fingerprint of an attractor using:
    - histogram of upper-triangular C_ij values in [0,1]
    This avoids dependence on node labeling.

    Output: normalized histogram vector (L1=1).
    """
    N = C.shape[0]
    vals = C[np.triu_indices(N, 1)]
    hist, _ = np.histogram(vals, bins=bins, range=(0.0, 1.0), density=False)
    hist = hist.astype(np.float64)
    s = np.sum(hist)
    if s > 0:
        hist /= s
    return hist

def l2_dist(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.linalg.norm(a - b))

def greedy_cluster(fingerprints: List[np.ndarray], threshold: float) -> List[int]:
    """
    Simple greedy clustering:
    - Maintain a list of cluster representatives
    - Assign each point to first rep within threshold (L2), else start new cluster

    Returns: cluster labels list of length len(fingerprints)
    """
    reps: List[np.ndarray] = []
    labels: List[int] = []

    for fp in fingerprints:
        assigned = False
        for k, rep in enumerate(reps):
            if l2_dist(fp, rep) <= threshold:
                labels.append(k)
                assigned = True
                break
        if not assigned:
            reps.append(fp)
            labels.append(len(reps) - 1)

    return labels


# -------------------------
# Noise-assisted transition probe (optional)
# -------------------------

def add_complex_noise(psis: np.ndarray, sigma: float, rng: np.random.Generator) -> np.ndarray:
    noise = rng.normal(size=psis.shape) + 1j * rng.normal(size=psis.shape)
    return psis + sigma * noise

def probe_transitions(
    basin_reps: Dict[int, np.ndarray],
    eta: float,
    relax_steps: int,
    n_trials: int,
    kick_sigma: float,
    seed: int
) -> List[Dict]:
    """
    For each basin representative, apply random noise kicks and relax.
    Record which basin the trajectory returns to (by fingerprint clustering done outside).
    This provides a transition matrix estimate.
    """
    rng = np.random.default_rng(seed)
    records = []
    # We'll return raw final fingerprints so caller can map to basin ids consistently
    for bid, rep_psis in basin_reps.items():
        for t in range(n_trials):
            kicked = add_complex_noise(rep_psis.copy(), kick_sigma, rng)
            kicked = project(kicked)
            final_psis, _ = update_projected(kicked, eta=eta, steps=relax_steps)
            C = compute_C(final_psis)
            fp = basin_fingerprint(C)
            records.append({
                "from_basin": bid,
                "trial": t,
                "kick_sigma": kick_sigma,
                "final_fingerprint": fp  # stored temporarily in-memory
            })
    return records


# -------------------------
# Config
# -------------------------

@dataclass
class Config:
    N: int = 24
    d: int = 16
    eta: float = 0.02
    relax_steps: int = 800

    restarts: int = 200
    seed: int = 123

    fp_bins: int = 32
    cluster_threshold: float = 0.10  # adjust if you see too many / too few basins

    # Transition probing
    do_transitions: bool = True
    transition_trials_per_basin: int = 30
    transition_kick_sigma: float = 0.02
    transition_relax_steps: int = 400
    transition_seed: int = 999


# -------------------------
# Main
# -------------------------

def main():
    cfg = Config()

    rng = np.random.default_rng(cfg.seed)

    run_rows: List[Dict] = []
    fingerprints: List[np.ndarray] = []
    finals: List[np.ndarray] = []

    print(f"Running energy landscape toy with restarts={cfg.restarts} "
          f"(N={cfg.N}, d={cfg.d}, eta={cfg.eta}, steps={cfg.relax_steps})")

    # ---- Multi-start relaxations ----
    for r in range(cfg.restarts):
        psis0 = random_unit_vectors(cfg.N, cfg.d, rng)
        final_psis, E_hist = update_projected(psis0, eta=cfg.eta, steps=cfg.relax_steps)

        C = compute_C(final_psis)
        E_final = energy_from_C(C)
        c_mean, c_std, c_max = coherence_stats_from_C(C)
        rho = density_matrix(final_psis)
        effr = effective_rank(rho)
        p_err = purity_identity_error(final_psis, C)

        fp = basin_fingerprint(C, bins=cfg.fp_bins)

        fingerprints.append(fp)
        finals.append(final_psis)

        run_rows.append({
            "restart": r,
            "N": cfg.N,
            "d": cfg.d,
            "eta": cfg.eta,
            "relax_steps": cfg.relax_steps,
            "energy_final": float(E_final),
            "C_mean": float(c_mean),
            "C_std": float(c_std),
            "C_max": float(c_max),
            "eff_rank": float(effr),
            "purity_identity_abs_err": float(p_err),
            "lyapunov_frac_nonincreasing": float(np.mean(np.diff(E_hist) <= 1e-12)) if len(E_hist) > 2 else float("nan"),
        })

        if (r + 1) % max(1, cfg.restarts // 10) == 0:
            print(f"  completed {r+1}/{cfg.restarts}")

    # ---- Cluster basins by fingerprint ----
    labels = greedy_cluster(fingerprints, threshold=cfg.cluster_threshold)
    for row, lab in zip(run_rows, labels):
        row["basin_id"] = int(lab)

    n_basins = int(max(labels) + 1) if labels else 0
    print(f"Discovered basins: {n_basins} (threshold={cfg.cluster_threshold}, bins={cfg.fp_bins})")

    # ---- Basin summaries ----
    basin_rows: List[Dict] = []
    for b in range(n_basins):
        idx = [i for i, lab in enumerate(labels) if lab == b]
        energies = [run_rows[i]["energy_final"] for i in idx]
        cmeans = [run_rows[i]["C_mean"] for i in idx]
        effrs = [run_rows[i]["eff_rank"] for i in idx]
        basin_rows.append({
            "basin_id": b,
            "count": len(idx),
            "basin_frac": float(len(idx) / len(labels)) if labels else 0.0,
            "energy_mean": float(np.mean(energies)) if energies else float("nan"),
            "energy_std": float(np.std(energies)) if energies else float("nan"),
            "C_mean_mean": float(np.mean(cmeans)) if cmeans else float("nan"),
            "eff_rank_mean": float(np.mean(effrs)) if effrs else float("nan"),
        })

    # Choose a representative final state for each basin (lowest energy in basin)
    basin_reps: Dict[int, np.ndarray] = {}
    for b in range(n_basins):
        idx = [i for i, lab in enumerate(labels) if lab == b]
        if not idx:
            continue
        best_i = min(idx, key=lambda i: run_rows[i]["energy_final"])
        basin_reps[b] = finals[best_i]

    # ---- Save outputs ----
    runs_path = "energy_landscape_runs.csv"
    basins_path = "energy_landscape_basins.csv"
    with open(runs_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=run_rows[0].keys())
        writer.writeheader()
        for r in run_rows:
            writer.writerow(r)

    with open(basins_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=basin_rows[0].keys())
        writer.writeheader()
        for r in basin_rows:
            writer.writerow(r)

    print(f"Saved {runs_path}")
    print(f"Saved {basins_path}")

    # ---- Optional: noise-assisted transition probing ----
    if cfg.do_transitions and n_basins > 0:
        print("Probing basin transitions with noise kicks...")
        trans_records = probe_transitions(
            basin_reps=basin_reps,
            eta=cfg.eta,
            relax_steps=cfg.transition_relax_steps,
            n_trials=cfg.transition_trials_per_basin,
            kick_sigma=cfg.transition_kick_sigma,
            seed=cfg.transition_seed
        )

        # Map each transition final fingerprint to a basin using the same clustering reps.
        # To do this robustly, build representatives from discovered basins.
        # We'll pick the first fingerprint in each basin as rep.
        basin_fp_reps: Dict[int, np.ndarray] = {}
        for b in range(n_basins):
            i0 = next(i for i, lab in enumerate(labels) if lab == b)
            basin_fp_reps[b] = fingerprints[i0]

        def assign_basin(fp: np.ndarray) -> int:
            best_b = 0
            best_d = float("inf")
            for b, rep in basin_fp_reps.items():
                d = l2_dist(fp, rep)
                if d < best_d:
                    best_d = d
                    best_b = b
            return int(best_b)

        trans_rows = []
        for rec in trans_records:
            to_b = assign_basin(rec["final_fingerprint"])
            trans_rows.append({
                "from_basin": int(rec["from_basin"]),
                "to_basin": int(to_b),
                "trial": int(rec["trial"]),
                "kick_sigma": float(rec["kick_sigma"]),
            })

        trans_path = "energy_landscape_transitions.csv"
        with open(trans_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=trans_rows[0].keys())
            writer.writeheader()
            for r in trans_rows:
                writer.writerow(r)

        print(f"Saved {trans_path}")

    print("Done.")


if __name__ == "__main__":
    main()
