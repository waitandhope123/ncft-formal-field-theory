#!/usr/bin/env python3
"""
Toy 10 — Universality & Basin-of-Attraction Atlas for NCFT
=========================================================

This toy tests whether NCFT signatures emerge as UNIVERSAL ATTRACTORS
across a wide family of normalized, pairwise interaction dynamics.

It answers:
- How large is the basin of attraction of NCFT-like behavior?
- Which deformations preserve universality?
- Which break it?

This is a capstone physics-style toy.
"""

import numpy as np
import csv
from itertools import product
from dataclasses import dataclass

# -----------------------------
# Core utilities
# -----------------------------

def project(psis):
    n = np.linalg.norm(psis, axis=1, keepdims=True)
    n[n == 0] = 1.0
    return psis / n

def random_unit(N, d, rng):
    return project(rng.normal(size=(N, d)) + 1j * rng.normal(size=(N, d)))

def C_matrix(psis):
    inner = psis @ psis.conj().T
    C = np.abs(inner) ** 2
    np.fill_diagonal(C, 0.0)
    return C

def density_matrix(psis):
    rho = np.zeros((psis.shape[1], psis.shape[1]), dtype=np.complex128)
    for p in psis:
        rho += np.outer(p, p.conj())
    return rho / psis.shape[0]

def purity_identity_error(psis):
    C = C_matrix(psis)
    vals = C[np.triu_indices(psis.shape[0], 1)]
    rho = density_matrix(psis)
    purity = np.real(np.trace(rho @ rho))
    rhs = (psis.shape[0] + 2*np.sum(vals)) / psis.shape[0]**2
    return float(abs(purity - rhs))

# -----------------------------
# Update laws (families)
# -----------------------------

def update_ncft(psis, eta):
    inner = psis @ psis.conj().T
    grad = -2 * inner @ psis
    return project(psis - eta * grad)

def update_power_ncft(psis, eta, power):
    inner = np.abs(psis @ psis.conj().T) ** power
    grad = -2 * inner @ psis
    return project(psis - eta * grad)

def update_clipped(psis, eta, clip):
    inner = np.clip(np.abs(psis @ psis.conj().T), 0, clip)
    grad = -2 * inner @ psis
    return project(psis - eta * grad)

def update_random_smooth(psis, eta, rng):
    noise = rng.normal(size=psis.shape) + 1j * rng.normal(size=psis.shape)
    return project(psis + eta * noise)

def update_mixed(psis, eta, alpha):
    inner = psis @ psis.conj().T
    grad1 = -2 * inner @ psis
    grad2 = rng.normal(size=psis.shape) + 1j * rng.normal(size=psis.shape)
    return project(psis - eta * (alpha * grad1 + (1 - alpha) * grad2))

# -----------------------------
# Config
# -----------------------------

@dataclass
class Config:
    N: int = 24
    d: int = 16
    steps: int = 400
    eta: float = 0.02
    seed: int = 123

cfg = Config()
rng = np.random.default_rng(cfg.seed)

# -----------------------------
# Law catalog
# -----------------------------

laws = []

# Baseline NCFT
laws.append(("ncft", {}))

# Power distortions
for p in [0.5, 1.5, 2.0]:
    laws.append(("power", {"power": p}))

# Clipped couplings
for c in [0.5, 0.8]:
    laws.append(("clipped", {"clip": c}))

# Mixed dynamics
for a in [0.3, 0.6]:
    laws.append(("mixed", {"alpha": a}))

# Random smooth
laws.append(("random", {}))

# -----------------------------
# Run atlas
# -----------------------------

results = []

for law, params in laws:
    psis = random_unit(cfg.N, cfg.d, rng)

    for _ in range(cfg.steps):
        if law == "ncft":
            psis = update_ncft(psis, cfg.eta)
        elif law == "power":
            psis = update_power_ncft(psis, cfg.eta, params["power"])
        elif law == "clipped":
            psis = update_clipped(psis, cfg.eta, params["clip"])
        elif law == "mixed":
            psis = update_mixed(psis, cfg.eta, params["alpha"])
        elif law == "random":
            psis = update_random_smooth(psis, cfg.eta, rng)

    # Final diagnostics
    C = C_matrix(psis)
    vals = C[np.triu_indices(cfg.N, 1)]

    results.append({
        "law": law,
        **params,
        "C_mean": float(np.mean(vals)),
        "C_kurtosis": float(np.mean((vals - np.mean(vals))**4)),
        "purity_identity_err": purity_identity_error(psis),
        "C_tail_05": float(np.mean(vals > 0.5)),
    })

# -----------------------------
# Save (FIXED)
# -----------------------------

# Collect all possible fieldnames across rows
all_fields = set()
for r in results:
    all_fields.update(r.keys())

fieldnames = sorted(all_fields)

with open("toy10_universality_basin_results.csv", "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    for r in results:
        writer.writerow(r)

print("Toy 10 complete.")
print("Saved toy10_universality_basin_results.csv")
