#!/usr/bin/env python3
"""
NCFT-core Toy 1: Phase × Scale Atlas

Maps phase structure and scaling behavior across:
- N (system size)
- d (Hilbert dimension)
- step size eta
- projected vs intrinsic dynamics

Outputs a CSV with standardized metrics.
"""

import numpy as np
import csv
from itertools import product

# -------------------------
# Core utilities
# -------------------------

def random_unit_vectors(N, d, rng):
    X = rng.normal(size=(N, d)) + 1j * rng.normal(size=(N, d))
    X /= np.linalg.norm(X, axis=1, keepdims=True)
    return X

def compute_C(psis):
    inner = psis @ psis.conj().T
    C = np.abs(inner) ** 2
    np.fill_diagonal(C, 0.0)
    return C

def project(psis):
    return psis / np.linalg.norm(psis, axis=1, keepdims=True)

def energy_from_C(C):
    return -0.5 * np.sum(C)

def update_projected(psis, eta):
    C_inner = psis @ psis.conj().T
    grads = np.zeros_like(psis, dtype=np.complex128)
    for i in range(psis.shape[0]):
        grads[i] = -2.0 * np.sum(
            C_inner[i, :, None] * psis,
            axis=0
        )
    psis = psis - eta * grads
    psis = project(psis)
    return psis

def update_intrinsic(psis, eta):
    C_inner = psis @ psis.conj().T
    grads = np.zeros_like(psis, dtype=np.complex128)
    for i in range(psis.shape[0]):
        grads[i] = -2.0 * np.sum(
            C_inner[i, :, None] * psis,
            axis=0
        )
    return psis - eta * grads

def density_matrix(psis):
    N = psis.shape[0]
    rho = np.zeros((psis.shape[1], psis.shape[1]), dtype=np.complex128)
    for i in range(N):
        rho += np.outer(psis[i], psis[i].conj())
    return rho / N

# -------------------------
# Metrics
# -------------------------

def compute_metrics(psis, C, E_hist):
    N, d = psis.shape

    norms = np.linalg.norm(psis, axis=1)
    max_norm_err = np.max(np.abs(norms - 1.0))

    Cvals = C[np.triu_indices(N, k=1)]
    sumC = np.sum(Cvals)

    rho = density_matrix(psis)
    purity = np.real(np.trace(rho @ rho))
    purity_rhs = (N + 2.0 * sumC) / (N ** 2)

    dE = np.diff(E_hist)
    lyapunov_frac = np.mean(dE <= 1e-12) if len(dE) > 0 else np.nan

    return {
        "N": N,
        "d": d,
        "C_mean": float(np.mean(Cvals)),
        "C_std": float(np.std(Cvals)),
        "C_max": float(np.max(Cvals)),
        "gt1_count": int(np.sum(Cvals > 1.0 + 1e-12)),
        "max_norm_err": float(max_norm_err),
        "energy_final": float(E_hist[-1]),
        "lyapunov_frac_nonincreasing": float(lyapunov_frac),
        "purity": float(purity),
        "purity_identity_abs_err": float(abs(purity - purity_rhs)),
    }

# -------------------------
# Experiment runner
# -------------------------

def run_experiment(
    N,
    d,
    eta,
    steps,
    projected,
    seed=0
):
    rng = np.random.default_rng(seed)
    psis = random_unit_vectors(N, d, rng)

    E_hist = []

    for _ in range(steps):
        C = compute_C(psis)
        E_hist.append(energy_from_C(C))
        if projected:
            psis = update_projected(psis, eta)
        else:
            psis = update_intrinsic(psis, eta)

    C = compute_C(psis)
    metrics = compute_metrics(psis, C, E_hist)
    metrics.update({
        "eta": eta,
        "steps": steps,
        "projected": projected
    })
    return metrics

# -------------------------
# Main sweep
# -------------------------

def main():
    Ns = [6, 12, 24]
    ds = [4, 8, 16]
    etas = [0.01, 0.05]
    steps = 200
    projected_opts = [True, False]

    rows = []

    for N, d, eta, proj in product(Ns, ds, etas, projected_opts):
        print(f"Running N={N}, d={d}, eta={eta}, projected={proj}")
        metrics = run_experiment(
            N=N,
            d=d,
            eta=eta,
            steps=steps,
            projected=proj,
            seed=42
        )
        rows.append(metrics)

    with open("phase_scale_atlas_results.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        for r in rows:
            writer.writerow(r)

    print("Saved phase_scale_atlas_results.csv")

if __name__ == "__main__":
    main()
