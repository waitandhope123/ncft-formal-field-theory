#!/usr/bin/env python3
"""
NCFT-core Toy 7: Renormalization / Coarse-Graining Closure Test

PURPOSE
-------
Test whether NCFT-core is (approximately) closed under aggregation:
- Run NCFT on N micro-nodes until clusters form.
- Coarse-grain clusters into K "super-nodes" via an effective state map.
- Define an effective interaction kernel between super-nodes.
- Re-run NCFT on the coarse system.
- Compare coarse dynamics to the micro system aggregated dynamics.

This toy answers:
1) Does projection commute with aggregation (approximately)?
2) Are NCFT invariants preserved after coarse-graining?
3) Does the macro system follow a similar Lyapunov descent?
4) Can you define an effective renormalized step size eta_eff?

OUTPUTS
-------
1) coarse_grain_micro_timeseries.csv
   Micro-system time series + aggregated-from-micro coarse observables.

2) coarse_grain_macro_timeseries.csv
   Macro (super-node) system time series.

3) coarse_grain_summary.csv
   One-row summary: N, d, K, mapping quality, best eta_eff estimate, errors.

NOTES
-----
- No external libraries beyond numpy/csv.
- Clustering is done by spectral embedding of C, then k-means (simple implementation).
- Aggregation map options:
    (A) mean_state: normalize(mean of member states)
    (B) principal: principal eigenvector of cluster density matrix
  Choose via Config.cluster_state_map

Run:
  python toy_renormalization_coarse_grain.py
"""

import numpy as np
import csv
from dataclasses import dataclass
from typing import Dict, List, Tuple


# -------------------------
# Core NCFT utilities
# -------------------------

def random_unit_vectors(N: int, d: int, rng: np.random.Generator) -> np.ndarray:
    X = rng.normal(size=(N, d)) + 1j * rng.normal(size=(N, d))
    X /= np.linalg.norm(X, axis=1, keepdims=True)
    return X

def project(psis: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(psis, axis=1, keepdims=True)
    return psis / norms

def compute_inner(psis: np.ndarray) -> np.ndarray:
    return psis @ psis.conj().T

def compute_C(psis: np.ndarray) -> np.ndarray:
    inner = compute_inner(psis)
    C = np.abs(inner) ** 2
    np.fill_diagonal(C, 0.0)
    return C

def energy_from_C(C: np.ndarray, W: np.ndarray = None) -> float:
    """
    If W is None: E = -sum_{i<j} C_ij
    If W provided: E = -sum_{i<j} W_ij C_ij
    Implemented symmetrically as -0.5 * sum_{i!=j} ...
    """
    if W is None:
        return -0.5 * float(np.sum(C))
    return -0.5 * float(np.sum(W * C))

def density_matrix(psis: np.ndarray) -> np.ndarray:
    N = psis.shape[0]
    rho = np.zeros((psis.shape[1], psis.shape[1]), dtype=np.complex128)
    for i in range(N):
        rho += np.outer(psis[i], psis[i].conj())
    return rho / N

def purity_identity_abs_err(psis: np.ndarray, C: np.ndarray) -> float:
    N = psis.shape[0]
    vals = C[np.triu_indices(N, 1)]
    sumC = float(np.sum(vals))
    rho = density_matrix(psis)
    purity = float(np.real(np.trace(rho @ rho)))
    rhs = (N + 2.0 * sumC) / (N ** 2)
    return float(abs(purity - rhs))

def coherence_stats(C: np.ndarray) -> Tuple[float, float, float]:
    vals = C[np.triu_indices(C.shape[0], 1)]
    return float(np.mean(vals)), float(np.std(vals)), float(np.max(vals))


# -------------------------
# Projected updates
# -------------------------

def update_projected(psis: np.ndarray, eta: float, steps: int, W: np.ndarray = None) -> Tuple[np.ndarray, List[float]]:
    """
    Projected gradient descent on:
      E = - sum_{i<j} W_ij |<psi_i|psi_j>|^2   (W defaults to all-ones off-diagonal)
    """
    E_hist: List[float] = []
    for _ in range(steps):
        inner = compute_inner(psis)
        C = np.abs(inner) ** 2
        np.fill_diagonal(C, 0.0)

        E_hist.append(energy_from_C(C, W))

        # grads = -2 * ( (W * inner) @ psis )  if W else -2*(inner@psis)
        if W is None:
            grads = -2.0 * (inner @ psis)
        else:
            grads = -2.0 * ((W * inner) @ psis)

        psis = psis - eta * grads
        psis = project(psis)
    return psis, E_hist


# -------------------------
# Simple k-means (for clustering)
# -------------------------

def kmeans(X: np.ndarray, k: int, rng: np.random.Generator, iters: int = 50) -> np.ndarray:
    """
    Minimal k-means on real features.
    Returns labels in {0..k-1}.
    """
    n, d = X.shape
    # init centers by random points
    centers = X[rng.choice(n, size=k, replace=False)].copy()

    labels = np.zeros(n, dtype=int)
    for _ in range(iters):
        # assign
        dists = np.sum((X[:, None, :] - centers[None, :, :]) ** 2, axis=2)
        new_labels = np.argmin(dists, axis=1)

        if np.all(new_labels == labels):
            break
        labels = new_labels

        # update centers
        for j in range(k):
            idx = np.where(labels == j)[0]
            if len(idx) == 0:
                centers[j] = X[rng.integers(0, n)]
            else:
                centers[j] = np.mean(X[idx], axis=0)

    return labels

def spectral_embedding(C: np.ndarray, k: int) -> np.ndarray:
    """
    Use top-k eigenvectors of C as embedding (real part).
    """
    w, v = np.linalg.eigh(C)
    idx = np.argsort(w)[::-1][:k]
    X = np.real(v[:, idx])
    # row-normalize
    norms = np.linalg.norm(X, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return X / norms


# -------------------------
# Coarse-graining map
# -------------------------

def cluster_members(labels: np.ndarray, K: int) -> List[np.ndarray]:
    return [np.where(labels == j)[0] for j in range(K)]

def superstate_mean(psis: np.ndarray, members: np.ndarray) -> np.ndarray:
    v = np.mean(psis[members], axis=0)
    n = np.linalg.norm(v)
    return v / n if n > 0 else v

def superstate_principal(psis: np.ndarray, members: np.ndarray) -> np.ndarray:
    """
    Principal eigenvector of cluster density matrix.
    """
    rho = np.zeros((psis.shape[1], psis.shape[1]), dtype=np.complex128)
    for i in members:
        rho += np.outer(psis[i], psis[i].conj())
    if len(members) > 0:
        rho /= len(members)
    w, v = np.linalg.eigh(rho)
    vec = v[:, np.argmax(w)]
    vec /= np.linalg.norm(vec)
    return vec

def build_superstates(psis: np.ndarray, labels: np.ndarray, K: int, mode: str) -> np.ndarray:
    groups = cluster_members(labels, K)
    Phi = np.zeros((K, psis.shape[1]), dtype=np.complex128)
    for j, mem in enumerate(groups):
        if len(mem) == 0:
            # placeholder random unit vector if empty
            tmp = np.random.normal(size=psis.shape[1]) + 1j * np.random.normal(size=psis.shape[1])
            Phi[j] = tmp / np.linalg.norm(tmp)
            continue
        if mode == "mean_state":
            Phi[j] = superstate_mean(psis, mem)
        elif mode == "principal":
            Phi[j] = superstate_principal(psis, mem)
        else:
            raise ValueError("Unknown cluster_state_map")
    return Phi

def build_effective_W(labels: np.ndarray, K: int) -> np.ndarray:
    """
    Effective weight matrix between clusters based on pair counts:
      W_ab = (# of micro pairs i in a, j in b), for a != b
    Then normalized to [0,1] by dividing by max off-diagonal.
    """
    groups = cluster_members(labels, K)
    W = np.zeros((K, K), dtype=np.float64)
    for a in range(K):
        for b in range(K):
            if a == b:
                continue
            W[a, b] = float(len(groups[a]) * len(groups[b]))
    mx = np.max(W) if np.max(W) > 0 else 1.0
    W = W / mx
    np.fill_diagonal(W, 0.0)
    return W

def aggregate_micro_C_to_macro(C_micro: np.ndarray, labels: np.ndarray, K: int) -> np.ndarray:
    """
    Aggregate micro overlap matrix C into a KxK matrix by averaging over pairs:
      Cbar_ab = mean{ C_ij : i in a, j in b } for a != b
    """
    groups = cluster_members(labels, K)
    Cbar = np.zeros((K, K), dtype=np.float64)
    for a in range(K):
        for b in range(K):
            if a == b:
                continue
            ia = groups[a]
            ib = groups[b]
            if len(ia) == 0 or len(ib) == 0:
                Cbar[a, b] = 0.0
                continue
            block = C_micro[np.ix_(ia, ib)]
            Cbar[a, b] = float(np.mean(block))
    np.fill_diagonal(Cbar, 0.0)
    return Cbar


# -------------------------
# Comparison + eta renormalization
# -------------------------

def fit_eta_eff(
    E_micro_agg: np.ndarray,
    E_macro: np.ndarray,
    eta_grid: np.ndarray
) -> float:
    """
    Given two energy time series (same length), pick eta_eff index that minimizes L2 error.
    This assumes E_macro was generated for multiple eta values externally; here we provide a helper
    signature but in this script we run macro at a single eta_eff guess and then optionally refine.
    """
    # Not used in the simplest path; left as a placeholder if you expand to multi-eta sweeps.
    return float("nan")

def series_l2(a: np.ndarray, b: np.ndarray) -> float:
    m = min(len(a), len(b))
    return float(np.linalg.norm(a[:m] - b[:m]))


# -------------------------
# Config
# -------------------------

@dataclass
class Config:
    # micro system
    N: int = 48
    d: int = 16
    eta_micro: float = 0.02

    # timeline
    steps_precluster: int = 600
    steps_postcluster: int = 600

    # clustering
    K: int = 6
    cluster_state_map: str = "principal"  # "mean_state" or "principal"

    # macro system
    # Start with eta_macro = eta_micro; you can later explore scaling by K/N etc.
    eta_macro: float = 0.02
    use_effective_W: bool = True

    # reproducibility
    seed: int = 123

    # output
    micro_csv: str = "coarse_grain_micro_timeseries.csv"
    macro_csv: str = "coarse_grain_macro_timeseries.csv"
    summary_csv: str = "coarse_grain_summary.csv"


# -------------------------
# Main
# -------------------------

def main():
    cfg = Config()
    rng = np.random.default_rng(cfg.seed)

    # ---- 1) Initialize micro system and run to clustering time ----
    psis = random_unit_vectors(cfg.N, cfg.d, rng)
    psis, E_pre = update_projected(psis, eta=cfg.eta_micro, steps=cfg.steps_precluster, W=None)

    C_t = compute_C(psis)
    cmean_t, cstd_t, cmax_t = coherence_stats(C_t)

    # ---- 2) Cluster micro system at time t_cluster ----
    X = spectral_embedding(C_t, k=cfg.K)
    labels = kmeans(X, k=cfg.K, rng=rng, iters=80)

    # Ensure K is actually used (if kmeans collapses labels, relabel to 0..K-1)
    # (simple fix: keep as-is; empty clusters handled downstream)

    groups = cluster_members(labels, cfg.K)
    sizes = [len(g) for g in groups]
    size_min, size_max = int(np.min(sizes)), int(np.max(sizes))

    # ---- 3) Build macro system (superstates + effective kernel) ----
    Phi0 = build_superstates(psis, labels, cfg.K, mode=cfg.cluster_state_map)
    Phi0 = project(Phi0)

    W_macro = build_effective_W(labels, cfg.K) if cfg.use_effective_W else None

    # ---- 4) Continue micro system post-cluster (reference) ----
    psis_post, E_post = update_projected(psis.copy(), eta=cfg.eta_micro, steps=cfg.steps_postcluster, W=None)

    # Also compute aggregated-from-micro macro observables over time:
    # We'll re-run micro postcluster but logging each step to build time series.
    psis_log = psis.copy()
    micro_rows: List[Dict] = []
    for t in range(cfg.steps_postcluster):
        C_micro = compute_C(psis_log)
        E_micro = energy_from_C(C_micro, None)
        Cbar = aggregate_micro_C_to_macro(C_micro, labels, cfg.K)
        E_micro_agg = energy_from_C(Cbar, W_macro) if W_macro is not None else energy_from_C(Cbar, None)

        cm, cs, cx = coherence_stats(C_micro)
        cm_bar, cs_bar, cx_bar = coherence_stats(Cbar)

        micro_rows.append({
            "t": t,
            "level": "micro",
            "E_micro": float(E_micro),
            "C_mean_micro": float(cm),
            "C_std_micro": float(cs),
            "C_max_micro": float(cx),
            "purity_id_err_micro": float(purity_identity_abs_err(psis_log, C_micro)),
            "E_agg_from_micro": float(E_micro_agg),
            "C_mean_agg": float(cm_bar),
            "C_std_agg": float(cs_bar),
            "C_max_agg": float(cx_bar),
        })

        # step micro
        psis_log, _ = update_projected(psis_log, eta=cfg.eta_micro, steps=1, W=None)

    # ---- 5) Run macro system post-cluster and log ----
    Phi = Phi0.copy()
    macro_rows: List[Dict] = []
    for t in range(cfg.steps_postcluster):
        C_macro = compute_C(Phi)
        E_macro = energy_from_C(C_macro, W_macro)

        cm, cs, cx = coherence_stats(C_macro)
        macro_rows.append({
            "t": t,
            "level": "macro",
            "E_macro": float(E_macro),
            "C_mean_macro": float(cm),
            "C_std_macro": float(cs),
            "C_max_macro": float(cx),
            "purity_id_err_macro": float(purity_identity_abs_err(Phi, C_macro)),
            "gt1_count_macro": int(np.sum(C_macro[np.triu_indices(cfg.K, 1)] > 1.0 + 1e-12)),
            "max_norm_err_macro": float(np.max(np.abs(np.linalg.norm(Phi, axis=1) - 1.0))),
        })

        Phi, _ = update_projected(Phi, eta=cfg.eta_macro, steps=1, W=W_macro)

    # ---- 6) Compare macro vs aggregated micro ----
    E_agg_series = np.array([r["E_agg_from_micro"] for r in micro_rows], dtype=float)
    E_macro_series = np.array([r["E_macro"] for r in macro_rows], dtype=float)

    E_l2 = series_l2(E_agg_series, E_macro_series)

    # A simple "closure quality" metric: relative L2 error
    denom = float(np.linalg.norm(E_agg_series)) if np.linalg.norm(E_agg_series) > 0 else 1.0
    rel_E_l2 = float(E_l2 / denom)

    # ---- 7) Save CSVs ----
    with open(cfg.micro_csv, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=micro_rows[0].keys())
        writer.writeheader()
        for r in micro_rows:
            writer.writerow(r)

    with open(cfg.macro_csv, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=macro_rows[0].keys())
        writer.writeheader()
        for r in macro_rows:
            writer.writerow(r)

    summary = [{
        "N": cfg.N,
        "d": cfg.d,
        "K": cfg.K,
        "eta_micro": cfg.eta_micro,
        "eta_macro": cfg.eta_macro,
        "use_effective_W": cfg.use_effective_W,
        "cluster_state_map": cfg.cluster_state_map,
        "steps_precluster": cfg.steps_precluster,
        "steps_postcluster": cfg.steps_postcluster,
        "cluster_sizes_min": size_min,
        "cluster_sizes_max": size_max,
        "C_mean_at_cluster_time": cmean_t,
        "C_std_at_cluster_time": cstd_t,
        "C_max_at_cluster_time": cmax_t,
        "energy_series_rel_L2_error_macro_vs_aggmicro": rel_E_l2,
    }]

    with open(cfg.summary_csv, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=summary[0].keys())
        writer.writeheader()
        writer.writerow(summary[0])

    print("Saved:")
    print(f"  {cfg.micro_csv}")
    print(f"  {cfg.macro_csv}")
    print(f"  {cfg.summary_csv}")
    print(f"Closure error (relative L2 on energy series): {rel_E_l2:.6f}")

    # ---- 8) Interpretive hints in console (not required) ----
    if rel_E_l2 < 0.10:
        print("Interpretation: Strong coarse-graining closure (macro tracks aggregated micro well).")
    elif rel_E_l2 < 0.25:
        print("Interpretation: Partial closure (macro captures trend but misses details).")
    else:
        print("Interpretation: Weak closure (macro does not track aggregated micro; scale-specific dynamics likely).")


if __name__ == "__main__":
    main()
