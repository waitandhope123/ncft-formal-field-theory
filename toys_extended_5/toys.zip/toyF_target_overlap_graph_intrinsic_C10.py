import numpy as np
from toy_utils import random_states, normalize, coupling, pairwise_stats

# ----------------------------
# Graph builders
# ----------------------------
def ring_graph_edges(N: int, k: int = 4):
    """
    Undirected ring with k neighbors on each side (total degree 2k).
    Returns list of edges (i, j) with i<j.
    """
    edges = set()
    for i in range(N):
        for s in range(1, k + 1):
            j = (i + s) % N
            a, b = (i, j) if i < j else (j, i)
            edges.add((a, b))
    return sorted(edges)

def er_graph_edges_sparse(N: int, p: float = 0.1, seed: int = 0):
    """
    Sparse ER edge generator that avoids O(N^2).
    Works well when p is small (expected degree O(1)).

    Strategy: for each i, sample how many edges from i to {i+1..N-1}
    using a Poisson approximation with mean p*(N-i-1), then choose endpoints.
    This is not an exact ER(n,p) sampler, but is a good sparse approximation
    and is fast for huge N.
    """
    rng = np.random.default_rng(seed)
    edges = []
    for i in range(N - 1):
        mean_out = p * (N - i - 1)
        if mean_out <= 0:
            continue
        m = rng.poisson(mean_out)
        if m <= 0:
            continue
        js = rng.integers(i + 1, N, size=m, endpoint=False)
        for j in js:
            edges.append((i, int(j)))
    return edges

def er_graph_edges_exact_small(N: int, p: float = 0.1, seed: int = 0):
    """
    Exact ER generator (O(N^2)) — only use for small N.
    """
    rng = np.random.default_rng(seed)
    edges = []
    for i in range(N):
        for j in range(i + 1, N):
            if rng.random() < p:
                edges.append((i, j))
    return edges

# ----------------------------
# Intrinsic update machinery
# ----------------------------
def tangent_project(psi: np.ndarray, g: np.ndarray) -> np.ndarray:
    # complex-safe tangent projection at psi
    return g - psi * np.vdot(psi, g)

def energy(psis: np.ndarray, edges, C0: float) -> float:
    E = 0.0
    for (i, j) in edges:
        cij = coupling(psis[i], psis[j])
        E += (cij - C0) ** 2
    return float(E)

def grad_proxy_target_overlap(psis: np.ndarray, edges, C0: float):
    """
    A practical gradient proxy for E = Σ (C_ij - C0)^2.

    For C_ij = |<psi_i|psi_j>|^2, a usable direction (not exact analytic grad,
    but aligned in practice) is:
      g_i += 4*(C_ij - C0) * <psi_j|psi_i> * psi_j
    (and similarly for g_j)

    Then we project to tangent space per i and retract by normalization.
    """
    N, d = psis.shape
    g = np.zeros_like(psis, dtype=psis.dtype)

    for (i, j) in edges:
        psi_i = psis[i]
        psi_j = psis[j]
        inner_ji = np.vdot(psi_j, psi_i)              # <psi_j|psi_i>
        cij = float(np.abs(inner_ji) ** 2)            # |<psi_j|psi_i>|^2

        a = 4.0 * (cij - C0)

        g[i] += a * inner_ji * psi_j
        inner_ij = np.vdot(psi_i, psi_j)
        g[j] += a * inner_ij * psi_i

    return g

def intrinsic_step(psis: np.ndarray, eta: float, edges, C0: float):
    g_all = grad_proxy_target_overlap(psis, edges, C0)
    out = psis.copy()
    for i in range(out.shape[0]):
        gi_tan = tangent_project(out[i], g_all[i])
        out[i] = normalize(out[i] - eta * gi_tan)
    return out

# ----------------------------
# Stats helpers (safe for huge N)
# ----------------------------
def edge_overlap_stats(psis: np.ndarray, edges):
    """
    Stats of C_ij only over the provided edge list (O(|E|)).
    """
    if len(edges) == 0:
        return {"mean": 0.0, "sigma": 0.0, "max": 0.0}

    vals = np.empty(len(edges), dtype=np.float64)
    for idx, (i, j) in enumerate(edges):
        vals[idx] = coupling(psis[i], psis[j])

    mean = float(vals.mean())
    sigma = float(vals.std())
    mx = float(vals.max())
    return {"mean": mean, "sigma": sigma, "max": mx}

def sampled_pairwise_mean(psis: np.ndarray, num_samples: int = 200_000, seed: int = 0):
    """
    Estimate mean overlap over uniformly sampled distinct pairs (O(num_samples)).
    This is the scalable replacement for pairwise_stats(psis) when N is large.
    """
    rng = np.random.default_rng(seed)
    N = psis.shape[0]
    acc = 0.0
    kept = 0

    # vectorized batching for speed
    batch = 50_000
    while kept < num_samples:
        m = min(batch, num_samples - kept)
        ii = rng.integers(0, N, size=m)
        jj = rng.integers(0, N, size=m)
        mask = ii != jj
        ii = ii[mask]
        jj = jj[mask]
        if ii.size == 0:
            continue

        # compute overlaps
        # <psi_i|psi_j> for each sampled pair
        inners = np.einsum("ij,ij->i", np.conjugate(psis[ii]), psis[jj])
        acc += float(np.sum(np.abs(inners) ** 2))
        kept += int(ii.size)

    return acc / kept

# ----------------------------
# Main run
# ----------------------------
def run(
    N=50,
    d=16,
    steps=1500,
    eta=0.15,
    C0=0.25,
    graph="ring",
    ring_k=4,
    er_p=0.10,
    seed=2,
    print_every=100,
    save_final=True,
):
    psis = random_states(N, d, complex_states=True, seed=seed)

    if graph == "ring":
        edges = ring_graph_edges(N, k=ring_k)
    elif graph == "er":
        # Use exact only for small N; sparse approx for large N
        if N <= 20_000:
            edges = er_graph_edges_exact_small(N, p=er_p, seed=seed)
        else:
            edges = er_graph_edges_sparse(N, p=er_p, seed=seed)
    else:
        raise ValueError("graph must be 'ring' or 'er'")

    print(f"TOY F — TARGET-OVERLAP GRAPH INTRINSIC")
    print(f"N={N} d={d} steps={steps} eta={eta} C0={C0} graph={graph} | edges={len(edges)}")

    for t in range(0, steps + 1):
        if t % print_every == 0 or t == steps:
            E = energy(psis, edges, C0)
            norms = np.linalg.norm(psis, axis=1)
            max_norm_err = float(np.max(np.abs(norms - 1.0)))

            # Small N: full stats are ok
            if N <= 5000:
                st = pairwise_stats(psis)
                print(
                    f"t={t:04d} | E={E:.6f} | <C>={st['mean']:.6f} σ={st['sigma']:.6f} "
                    f"Cmax={st['max']:.6f} gt1={st['count_gt1']} | norm_err={max_norm_err:.2e}"
                )
            else:
                # Large N: edge stats + sampled global mean (fast)
                est_global = sampled_pairwise_mean(psis, num_samples=200_000, seed=seed + t)
                est_edges = edge_overlap_stats(psis, edges)
                print(
                    f"t={t:04d} | E={E:.6f} | <C>~{est_global:.6e} (sample) | "
                    f"<C_edge>={est_edges['mean']:.6e} σ_edge={est_edges['sigma']:.6e} "
                    f"Cedge_max={est_edges['max']:.6e} | norm_err={max_norm_err:.2e}"
                )

        psis = intrinsic_step(psis, eta=eta, edges=edges, C0=C0)

    if save_final:
        import os
        os.makedirs("outputs", exist_ok=True)
        np.save("outputs/toyF_final_psis.npy", psis)
        print("Saved outputs/toyF_final_psis.npy")

    print("✅ Completed.")
    return psis  # return in-memory so caller doesn't need to load

# ----------------------------
# Cosmic test (updated so it works)
# ----------------------------
if __name__ == "__main__":
    N_test = 1_000_000

    psis = run(
        N=N_test,
        d=16,
        steps=1500,
        eta=0.15,
        C0=0.001,
        graph="er",
        er_p=2 / N_test,   # average degree ~2
        seed=2,
        print_every=100,
        save_final=False,  # avoid giant disk I/O unless you really want it
    )

    # COSMIC DENSITY CALCULATION (sample-based; scalable)
    rho_field = sampled_pairwise_mean(psis, num_samples=300_000, seed=123)
    total_connections = rho_field * N_test * (N_test - 1) / 2

    print(f"\n🌌 COSMIC TEST RESULTS:")
    print(f"ρ_field ≈ {rho_field:.8e}")
    print(f"Total conscious connections (estimated): {total_connections:.2e}")
