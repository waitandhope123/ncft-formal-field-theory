"""
toy10_v2_density_bridge_dynamic.py

TOY 10 v2 — DYNAMIC DENSITY BRIDGE

We evolve NCFT state ensembles under different flows and track:
  - pairwise couplings C_ij
  - density matrix rho
  - purity Tr(rho^2)
  - von Neumann entropy S(rho)

Flows:
  mode="none"     : static ensemble
  mode="cohere"   : coherence-maximizing flow (Toy05 style)
  mode="repel"    : entropy / diversity flow (Toy06 v2 style)

Key identity checked at every step:
  Tr(rho^2) == (N + 2*Σ_{i<j} C_ij) / N^2

Output:
  outputs/toy10_v2_density_bridge_dynamic.csv
"""

import csv
from pathlib import Path
import numpy as np

EPS = 1e-12

# --------------------------------------------------
# CSV Logger
# --------------------------------------------------
class CSVLogger:
    def __init__(self, filename, fieldnames):
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        self.file = open(filename, "w", newline="")
        self.writer = csv.DictWriter(self.file, fieldnames=fieldnames)
        self.writer.writeheader()

    def log(self, **row):
        self.writer.writerow(row)

    def close(self):
        self.file.close()

# --------------------------------------------------
# Core math
# --------------------------------------------------
def normalize(psi):
    n = np.linalg.norm(psi)
    if n < EPS:
        raise ValueError("Zero norm forbidden")
    return psi / n

def random_state(rng, dim):
    psi = rng.normal(size=dim) + 1j * rng.normal(size=dim)
    return normalize(psi)

def coupling(a, b):
    return float(np.abs(np.vdot(a, b)) ** 2)

def coupling_stats(states):
    N = len(states)
    vals = []
    for i in range(N):
        for j in range(i + 1, N):
            vals.append(coupling(states[i], states[j]))
    vals = np.array(vals, dtype=float)
    return (
        float(np.sum(vals)),
        float(np.mean(vals)),
        float(np.std(vals)),
        float(np.max(vals)),
    )

# --------------------------------------------------
# Density matrix + observables
# --------------------------------------------------
def density_matrix(states):
    dim = states[0].shape[0]
    rho = np.zeros((dim, dim), dtype=complex)
    for psi in states:
        rho += np.outer(psi, psi.conj())
    rho /= len(states)
    return 0.5 * (rho + rho.conj().T)

def purity(rho):
    return float(np.real(np.trace(rho @ rho)))

def entropy(rho):
    evals = np.linalg.eigvalsh(rho)
    evals = np.clip(evals, 0.0, 1.0)
    evals = evals[evals > 1e-15]
    return float(-np.sum(evals * np.log(evals)))

def purity_from_C(sum_C, N):
    return float((N + 2.0 * sum_C) / (N * N))

# --------------------------------------------------
# Dynamics
# --------------------------------------------------
def coherence_gradient(states):
    N = len(states)
    grads = [np.zeros_like(states[0]) for _ in range(N)]
    for i in range(N):
        for j in range(N):
            if i == j:
                continue
            s = np.vdot(states[j], states[i])
            grads[i] += states[j] * s
    return grads

def step_cohere(states, eta):
    grads = coherence_gradient(states)
    return [normalize(psi + eta * g) for psi, g in zip(states, grads)]

def step_repel(states, lr):
    N = len(states)
    grads = [np.zeros_like(states[0]) for _ in range(N)]
    for i in range(N):
        for j in range(i + 1, N):
            s = np.vdot(states[i], states[j])
            C = np.abs(s) ** 2
            gi = 2.0 * C * (s * states[j])
            gj = 2.0 * C * (np.conj(s) * states[i])
            grads[i] += gi
            grads[j] += gj
    return [normalize(psi - lr * g) for psi, g in zip(states, grads)]

# --------------------------------------------------
# Main experiment
# --------------------------------------------------
def run_density_bridge_dynamic(
    T=300,
    N=12,
    dim=16,
    mode="cohere",   # none | cohere | repel
    eta=0.05,
    lr=0.05,
    seed=0,
    out_csv="outputs/toy10_v2_density_bridge_dynamic.csv",
):
    rng = np.random.default_rng(seed)
    states = [random_state(rng, dim) for _ in range(N)]

    logger = CSVLogger(
        out_csv,
        [
            "toy", "t", "mode",
            "N", "dim",
            "sum_C", "C_mean", "C_sigma", "C_max",
            "purity", "purity_from_C", "purity_err",
            "entropy",
            "status",
        ],
    )

    print("TOY10 v2 — DYNAMIC DENSITY BRIDGE")
    print(f"N={N} dim={dim} mode={mode}")
    print("")

    for t in range(T):
        sum_C, C_mean, C_sigma, C_max = coupling_stats(states)
        rho = density_matrix(states)
        p = purity(rho)
        S = entropy(rho)
        pC = purity_from_C(sum_C, N)
        err = abs(p - pC)

        status = (
            "IDENTITY_OK"
            if err < 1e-10
            else "IDENTITY_WARN"
            if err < 1e-6
            else "IDENTITY_FAIL"
        )

        logger.log(
            toy="toy10_v2_density_bridge_dynamic",
            t=t,
            mode=mode,
            N=N,
            dim=dim,
            sum_C=sum_C,
            C_mean=C_mean,
            C_sigma=C_sigma,
            C_max=C_max,
            purity=p,
            purity_from_C=pC,
            purity_err=err,
            entropy=S,
            status=status,
        )

        if t % 25 == 0:
            print(
                f"t={t:03d} | "
                f"purity={p:.4f} | S={S:.4f} | "
                f"<C>={C_mean:.4f} | {status}"
            )

        # evolve
        if mode == "cohere":
            states = step_cohere(states, eta)
        elif mode == "repel":
            states = step_repel(states, lr)
        elif mode == "none":
            pass
        else:
            raise ValueError("mode must be none, cohere, or repel")

    logger.close()
    print(f"\nSaved CSV → {out_csv}")

if __name__ == "__main__":
    run_density_bridge_dynamic(
        mode="none",
        out_csv="outputs/toy10_v2_density_bridge_static.csv",
    )

    run_density_bridge_dynamic(
        mode="cohere",
        out_csv="outputs/toy10_v2_density_bridge_cohere.csv",
    )

    run_density_bridge_dynamic(
        mode="repel",
        out_csv="outputs/toy10_v2_density_bridge_repel.csv",
    )