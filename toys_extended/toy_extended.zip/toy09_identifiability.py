"""
toy09_identifiability.py

TOY 09 — IDENTIFIABILITY
Given only observed C_ij = |<ψ_i|ψ_j>|^2 from a "true" set of states,
attempt to reconstruct a new set of states that reproduces C.

We minimize:
  L = Σ_{i<j} ( |<ψ̂_i|ψ̂_j>|^2 - C_obs_ij )^2

using simple projected gradient descent.

Output:
  outputs/toy09_identifiability.csv
"""

import csv
from pathlib import Path
import numpy as np

EPS = 1e-12

# -----------------------
# CSV Logger
# -----------------------
class CSVLogger:
    def __init__(self, filename, fieldnames):
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        self.file = open(filename, "w", newline="")
        self.writer = csv.DictWriter(self.file, fieldnames=fieldnames)
        self.writer.writeheader()

    def log(self, **row):
        self.writer.writerow(row)

    def close(self):
        self.file.close()

# -----------------------
# Core math
# -----------------------
def normalize(psi):
    n = np.linalg.norm(psi)
    if n < EPS:
        raise ValueError("Zero norm forbidden")
    return psi / n

def random_state(rng, dim):
    psi = rng.normal(size=dim) + 1j * rng.normal(size=dim)
    return normalize(psi)

def coupling(a, b):
    c = np.abs(np.vdot(a, b)) ** 2
    if c < 0 and c > -1e-9:
        c = 0.0
    if c > 1 and c < 1 + 1e-9:
        c = 1.0
    return float(c)

def coupling_matrix(states):
    N = len(states)
    C = np.zeros((N, N), dtype=float)
    for i in range(N):
        for j in range(i + 1, N):
            c = coupling(states[i], states[j])
            C[i, j] = C[j, i] = c
    return C

# -----------------------
# Loss + gradient
# -----------------------
def loss_and_grad(states_hat, C_obs):
    """
    Compute loss:
      L = Σ_{i<j} (C_hat_ij - C_obs_ij)^2
    and gradients for each ψ̂_i (complex).

    We use a practical gradient for:
      C_hat_ij = |<ψ_i|ψ_j>|^2 = (<ψ_i|ψ_j>)(<ψ_j|ψ_i>)
    Let s_ij = <ψ_i|ψ_j>.
    Then dC/dψ_i* ≈ s_ij * ψ_j
    Loss gradient accumulates:
      dL/dψ_i* += 2*(C_hat_ij - C_obs_ij) * (s_ij * ψ_j)
    """
    N = len(states_hat)
    grads = [np.zeros_like(states_hat[0]) for _ in range(N)]
    L = 0.0

    for i in range(N):
        for j in range(i + 1, N):
            psi_i = states_hat[i]
            psi_j = states_hat[j]

            s = np.vdot(psi_i, psi_j)         # <ψ_i|ψ_j>
            C_hat = float(np.abs(s) ** 2)     # |s|^2

            diff = C_hat - C_obs[i, j]
            L += diff * diff

            # gradient contributions (Wirtinger-style heuristic)
            # dC/dψ_i* ≈ s * ψ_j
            gi = 2.0 * diff * (s * psi_j)
            # dC/dψ_j* ≈ conj(s) * ψ_i  (since <ψ_j|ψ_i> = conj(s))
            gj = 2.0 * diff * (np.conj(s) * psi_i)

            grads[i] += gi
            grads[j] += gj

    return float(L), grads

def step(states_hat, grads, lr):
    new_states = []
    for psi, g in zip(states_hat, grads):
        psi_new = psi - lr * g
        psi_new = normalize(psi_new)
        new_states.append(psi_new)
    return new_states

# -----------------------
# Main experiment
# -----------------------
def run_identifiability(
    N=10,
    dim=8,
    steps=800,
    lr=0.05,
    trials=5,
    seed=0,
    out_csv="outputs/toy09_identifiability.csv",
):
    rng = np.random.default_rng(seed)

    FIELDS = [
        "toy", "run_id", "seed",
        "trial", "N", "dim",
        "step", "lr",
        "loss",
        "status",
    ]
    logger = CSVLogger(out_csv, FIELDS)

    print("TOY09 — IDENTIFIABILITY (Reconstruct ψ from C)")
    print(f"N={N} dim={dim} steps={steps} lr={lr} trials={trials}")
    print("")

    for trial in range(trials):
        # True states and observed C
        true_states = [random_state(rng, dim) for _ in range(N)]
        C_obs = coupling_matrix(true_states)

        # Initialize guess states (independent random)
        states_hat = [random_state(rng, dim) for _ in range(N)]

        for s in range(steps):
            L, grads = loss_and_grad(states_hat, C_obs)
            states_hat = step(states_hat, grads, lr)

            status = "FIT_OK" if L < 1e-6 else "FITTING"

            logger.log(
                toy="toy09_identifiability",
                run_id=0,
                seed=seed,
                trial=trial,
                N=N,
                dim=dim,
                step=s,
                lr=lr,
                loss=L,
                status=status,
            )

            if s % 100 == 0:
                print(f"trial={trial} step={s:04d} | loss={L:.3e} | {status}")

        print(f"trial={trial} final loss={L:.3e}")
        print("")

    logger.close()
    print(f"Saved CSV → {out_csv}")
    print("Interpretation:")
    print(" - If loss reliably reaches ~0, C is (at least) realizable by some ψ set.")
    print(" - If loss stalls above a floor, C may be non-identifiable or needs more observables.")
    print(" - Even with near-zero loss, solution is not unique (global unitary/gauge).")

if __name__ == "__main__":
    run_identifiability(
        N=10,
        dim=8,
        steps=800,
        lr=0.05,
        trials=5,
        seed=0,
    )
