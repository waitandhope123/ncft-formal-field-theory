"""
toy06_v2_entropy_repulsion.py

TOY 06 v2 — ENTROPY REPULSION / DIVERSITY FLOW
Fixes the Toy06 v1 collapse by penalizing squared overlaps:

Objective:
  J = Σ_{i<j} C_ij^2,   where C_ij = |<ψ_i|ψ_j>|^2

We perform projected gradient descent on J (repulsion),
keeping each ψ_i normalized.

Expected:
- C_max should *not* run to 1.0 and freeze.
- Mean coupling should drop or stabilize lower.
- Distribution should become more uniform.

Output:
  outputs/toy06_v2_entropy_repulsion.csv
"""

import csv
from pathlib import Path
import numpy as np

EPS = 1e-12

# -----------------------
# CSV Logger
# -----------------------
class CSVLogger:
    def __init__(self, filename, fieldnames):
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        self.file = open(filename, "w", newline="")
        self.writer = csv.DictWriter(self.file, fieldnames=fieldnames)
        self.writer.writeheader()

    def log(self, **row):
        self.writer.writerow(row)

    def close(self):
        self.file.close()

# -----------------------
# Core math
# -----------------------
def normalize(psi):
    n = np.linalg.norm(psi)
    if n < EPS:
        raise ValueError("Zero norm forbidden")
    return psi / n

def random_state(rng, dim):
    psi = rng.normal(size=dim) + 1j * rng.normal(size=dim)
    return normalize(psi)

def coupling_overlap(a, b):
    """
    Returns s=<a|b> and C=|s|^2.
    """
    s = np.vdot(a, b)
    C = float(np.abs(s) ** 2)
    return s, C

def coupling_stats(states):
    N = len(states)
    vals = []
    total = 0.0
    cmax = 0.0
    for i in range(N):
        for j in range(i + 1, N):
            _, C = coupling_overlap(states[i], states[j])
            vals.append(C)
            total += C
            if C > cmax:
                cmax = C
    vals = np.array(vals, dtype=float)
    return {
        "pairs": len(vals),
        "C_mean": float(np.mean(vals)) if len(vals) else 0.0,
        "C_sigma": float(np.std(vals)) if len(vals) else 0.0,
        "C_max": float(cmax),
        "C_total": float(total),
        "J_sum_C2": float(np.sum(vals * vals)),
    }

def spectral_gap_from_C(states):
    """
    Build C matrix and compute eigengap for structure diagnostics.
    """
    N = len(states)
    Cmat = np.zeros((N, N), dtype=float)
    for i in range(N):
        for j in range(i + 1, N):
            _, C = coupling_overlap(states[i], states[j])
            Cmat[i, j] = Cmat[j, i] = C
    w = np.linalg.eigvalsh(Cmat)
    w = np.sort(w)[::-1]
    if len(w) < 2:
        return float(w[0]) if len(w) else 0.0, 0.0
    return float(w[0]), float(w[0] - w[1])

# -----------------------
# Gradient descent on J = Σ C_ij^2
# -----------------------
def grad_J(states):
    """
    J = Σ_{i<j} (|<ψ_i|ψ_j>|^2)^2 = Σ C_ij^2

    For pair (i,j), with s=<ψ_i|ψ_j>, C=|s|^2,
    d(C^2)/dψ_i* ≈ 2*C * ( dC/dψ_i* )
    and dC/dψ_i* ≈ s * ψ_j

    => contribution to grad_i: 2*C * (s * ψ_j)
       contribution to grad_j: 2*C * (conj(s) * ψ_i)

    We sum over all pairs.
    """
    N = len(states)
    grads = [np.zeros_like(states[0]) for _ in range(N)]

    for i in range(N):
        for j in range(i + 1, N):
            psi_i, psi_j = states[i], states[j]
            s = np.vdot(psi_i, psi_j)
            C = np.abs(s) ** 2

            # gradients for descent (we'll subtract lr*grad)
            gi = 2.0 * C * (s * psi_j)
            gj = 2.0 * C * (np.conj(s) * psi_i)

            grads[i] += gi
            grads[j] += gj

    return grads

def step(states, lr):
    grads = grad_J(states)
    new_states = []
    for psi, g in zip(states, grads):
        psi_new = normalize(psi - lr * g)
        new_states.append(psi_new)
    return new_states

# -----------------------
# Main experiment
# -----------------------
def run_entropy_repulsion(
    T=300,
    N=14,
    dim=16,
    lr=0.05,
    seed=0,
    out_csv="outputs/toy06_v2_entropy_repulsion.csv",
):
    rng = np.random.default_rng(seed)
    states = [random_state(rng, dim) for _ in range(N)]

    FIELDS = [
        "toy", "run_id", "seed", "t",
        "N", "dim",
        "lr",
        "C_mean", "C_sigma", "C_max", "C_total",
        "J_sum_C2",
        "eig_top", "spectral_gap",
        "status",
    ]
    logger = CSVLogger(out_csv, FIELDS)

    print("TOY06 v2 — ENTROPY REPULSION / DIVERSITY FLOW")
    print(f"N={N} dim={dim} lr={lr}")
    print("Goal: suppress large overlaps (Cmax should not run to 1 and freeze).")
    print("")

    for t in range(T):
        stats = coupling_stats(states)
        eig_top, gap = spectral_gap_from_C(states)

        # heuristic: "healthy" diversity if C_max stays moderate
        status = "DIVERSE" if stats["C_max"] < 0.6 else "CLUSTERING"

        logger.log(
            toy="toy06_v2_entropy_repulsion",
            run_id=0,
            seed=seed,
            t=t,
            N=N,
            dim=dim,
            lr=lr,
            C_mean=stats["C_mean"],
            C_sigma=stats["C_sigma"],
            C_max=stats["C_max"],
            C_total=stats["C_total"],
            J_sum_C2=stats["J_sum_C2"],
            eig_top=eig_top,
            spectral_gap=gap,
            status=status,
        )

        if t % 25 == 0:
            print(
                f"t={t:03d} | <C>={stats['C_mean']:.4f} σ={stats['C_sigma']:.4f} "
                f"Cmax={stats['C_max']:.4f} | J={stats['J_sum_C2']:.4f} "
                f"| λ1={eig_top:.3f} gap={gap:.3f} | {status}"
            )

        states = step(states, lr=lr)

    logger.close()
    print("")
    print(f"Saved CSV → {out_csv}")
    print("Tips:")
    print(" - If it changes too slowly, increase lr to 0.08–0.12.")
    print(" - If it becomes unstable, reduce lr to 0.02–0.04.")
    print(" - Compare against Toy06 v1: Cmax should not saturate at 1.")

if __name__ == "__main__":
    run_entropy_repulsion(
        T=300,
        N=14,
        dim=16,
        lr=0.05,
        seed=0,
    )
