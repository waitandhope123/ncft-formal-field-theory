"""
toy06_competitive_exclusion.py

TOY 06 — COMPETITIVE EXCLUSION / REPULSION
States repel from highly-coupled neighbors, encouraging separation and clustering.

Update:
    ψ_i <- normalize( ψ_i - α Σ_{j≠i} C_ij ψ_j )

Output:
  outputs/toy06_competitive_exclusion.csv
"""

import csv
from pathlib import Path
import numpy as np

EPS = 1e-12

# -----------------------
# CSV Logger
# -----------------------
class CSVLogger:
    def __init__(self, filename, fieldnames):
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        self.file = open(filename, "w", newline="")
        self.writer = csv.DictWriter(self.file, fieldnames=fieldnames)
        self.writer.writeheader()

    def log(self, **row):
        self.writer.writerow(row)

    def close(self):
        self.file.close()

# -----------------------
# Core math
# -----------------------
def normalize(psi):
    n = np.linalg.norm(psi)
    if n < EPS:
        raise ValueError("Zero norm forbidden")
    return psi / n

def random_state(rng, dim):
    psi = rng.normal(size=dim) + 1j * rng.normal(size=dim)
    return normalize(psi)

def coupling(a, b):
    c = np.abs(np.vdot(a, b)) ** 2
    if c < 0 and c > -1e-9:
        c = 0.0
    if c > 1 and c < 1 + 1e-9:
        c = 1.0
    return float(c)

def coupling_matrix(states):
    N = len(states)
    C = np.zeros((N, N), dtype=float)
    for i in range(N):
        for j in range(i + 1, N):
            c = coupling(states[i], states[j])
            C[i, j] = C[j, i] = c
    return C

def coupling_stats_from_C(C):
    N = C.shape[0]
    vals = C[np.triu_indices(N, 1)]
    return {
        "pairs": len(vals),
        "C_mean": float(np.mean(vals)) if len(vals) else 0.0,
        "C_sigma": float(np.std(vals)) if len(vals) else 0.0,
        "C_max": float(np.max(vals)) if len(vals) else 0.0,
        "C_total": float(np.sum(vals)) if len(vals) else 0.0,
    }

def spectral_gap(C):
    # eigenvalues of symmetric real matrix
    w = np.linalg.eigvalsh(C)
    w = np.sort(w)[::-1]  # descending
    if len(w) < 2:
        return 0.0, float(w[0]) if len(w) else 0.0
    return float(w[0] - w[1]), float(w[0])

# -----------------------
# Repulsion dynamics
# -----------------------
def repulsion_step(states, alpha):
    """
    ψ_i <- normalize( ψ_i - α Σ_{j≠i} C_ij ψ_j )
    """
    N = len(states)
    C = coupling_matrix(states)
    new_states = []

    for i in range(N):
        push = np.zeros_like(states[i])
        for j in range(N):
            if i == j:
                continue
            push += C[i, j] * states[j]
        psi_new = states[i] - alpha * push
        psi_new = normalize(psi_new)
        new_states.append(psi_new)

    return new_states, C

# -----------------------
# Main experiment
# -----------------------
def run_competitive_exclusion(
    T=300,
    N=14,
    dim=16,
    alpha=0.20,
    seed=0,
    out_csv="outputs/toy06_competitive_exclusion.csv",
):
    rng = np.random.default_rng(seed)
    states = [random_state(rng, dim) for _ in range(N)]

    FIELDS = [
        "toy", "run_id", "seed", "t",
        "N", "dim",
        "alpha",
        "C_mean", "C_sigma", "C_max", "C_total",
        "eig_top", "spectral_gap",
        "status",
    ]
    logger = CSVLogger(out_csv, FIELDS)

    print("TOY06 — COMPETITIVE EXCLUSION / REPULSION")
    print(f"N={N} dim={dim} alpha={alpha}")
    print("Goal: reduce coupling (states separate) and possibly form clusters.")
    print("")

    for t in range(T):
        states, C = repulsion_step(states, alpha=alpha)
        stats = coupling_stats_from_C(C)
        gap, top = spectral_gap(C)

        # heuristic: more cluster/block structure often increases leading eigengap
        status = "SEPARATING" if stats["C_mean"] < 0.2 else "MIXED"

        logger.log(
            toy="toy06_competitive_exclusion",
            run_id=0,
            seed=seed,
            t=t,
            N=N,
            dim=dim,
            alpha=alpha,
            C_mean=stats["C_mean"],
            C_sigma=stats["C_sigma"],
            C_max=stats["C_max"],
            C_total=stats["C_total"],
            eig_top=top,
            spectral_gap=gap,
            status=status,
        )

        if t % 25 == 0:
            print(
                f"t={t:03d} | "
                f"<C>={stats['C_mean']:.4f} σ={stats['C_sigma']:.4f} "
                f"Cmax={stats['C_max']:.4f} | "
                f"λ1={top:.3f} gap={gap:.3f} | {status}"
            )

    logger.close()
    print("")
    print(f"Saved CSV → {out_csv}")
    print("Tips:")
    print(" - If it collapses or behaves oddly, reduce alpha (e.g., 0.05–0.15).")
    print(" - If nothing happens, increase alpha slightly (e.g., 0.25).")

if __name__ == "__main__":
    run_competitive_exclusion(
        T=300,
        N=14,
        dim=16,
        alpha=0.20,
        seed=0,
    )
