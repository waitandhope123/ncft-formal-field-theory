"""
toy10_density_bridge.py

TOY 10 — DENSITY BRIDGE (ρ, purity, entropy proxy)

Given normalized states ψ_i ∈ ℂ^dim, define:
  ρ = (1/N) Σ |ψ_i><ψ_i|

Compute:
  purity = Tr(ρ^2)
  entropy = -Tr(ρ log ρ)   (via eigenvalues)

Key identity check:
  Tr(ρ^2) == (N + 2*Σ_{i<j} C_ij) / N^2
where C_ij = |<ψ_i|ψ_j>|^2

Optional dynamics:
  mode="none"   : no state updates
  mode="cohere" : projected gradient ascent on coherence (Toy 5 style)
  mode="repel"  : repulsion from coupled neighbors (Toy 6 style)

Output:
  outputs/toy10_density_bridge.csv
"""

import csv
from pathlib import Path
import numpy as np

EPS = 1e-12

# -----------------------
# CSV Logger
# -----------------------
class CSVLogger:
    def __init__(self, filename, fieldnames):
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        self.file = open(filename, "w", newline="")
        self.writer = csv.DictWriter(self.file, fieldnames=fieldnames)
        self.writer.writeheader()

    def log(self, **row):
        self.writer.writerow(row)

    def close(self):
        self.file.close()

# -----------------------
# Core math
# -----------------------
def normalize(psi):
    n = np.linalg.norm(psi)
    if n < EPS:
        raise ValueError("Zero norm forbidden")
    return psi / n

def random_state(rng, dim):
    psi = rng.normal(size=dim) + 1j * rng.normal(size=dim)
    return normalize(psi)

def coupling(a, b):
    c = np.abs(np.vdot(a, b)) ** 2
    # numerical clamp
    if c < 0 and c > -1e-9:
        c = 0.0
    if c > 1 and c < 1 + 1e-9:
        c = 1.0
    return float(c)

def coupling_matrix(states):
    N = len(states)
    C = np.zeros((N, N), dtype=float)
    for i in range(N):
        for j in range(i + 1, N):
            c = coupling(states[i], states[j])
            C[i, j] = C[j, i] = c
    return C

def coupling_sums(C):
    N = C.shape[0]
    vals = C[np.triu_indices(N, 1)]
    return float(np.sum(vals)), float(np.mean(vals)), float(np.std(vals)), float(np.max(vals))

# -----------------------
# Density bridge
# -----------------------
def density_matrix(states):
    """
    ρ = (1/N) Σ |ψ_i><ψ_i|
    """
    N = len(states)
    dim = states[0].shape[0]
    rho = np.zeros((dim, dim), dtype=complex)
    for psi in states:
        rho += np.outer(psi, psi.conj())
    rho /= float(N)
    # Hermitian symmetrize for numerical hygiene
    rho = 0.5 * (rho + rho.conj().T)
    return rho

def purity(rho):
    return float(np.real(np.trace(rho @ rho)))

def von_neumann_entropy(rho):
    """
    S(ρ) = -Tr(ρ log ρ). Compute via eigenvalues of Hermitian rho.
    Natural log (nats). Divide by log(2) if you want bits.
    """
    evals = np.linalg.eigvalsh(rho)
    evals = np.clip(evals, 0.0, 1.0)  # guard tiny negatives
    evals = evals[evals > 1e-15]
    return float(-np.sum(evals * np.log(evals)))

def purity_identity_from_C(sum_C, N):
    """
    Tr(ρ^2) = (N + 2*Σ_{i<j} C_ij) / N^2
    """
    return float((N + 2.0 * sum_C) / (N * N))

# -----------------------
# Optional dynamics
# -----------------------
def coherence_gradient(states):
    """
    Ascent direction for F = Σ_{i<j} |<ψ_i|ψ_j>|^2:
      grad_i ≈ Σ_{j≠i} ψ_j * <ψ_j|ψ_i>
    """
    N = len(states)
    grads = [np.zeros_like(states[0]) for _ in range(N)]
    for i in range(N):
        gi = np.zeros_like(states[i])
        psi_i = states[i]
        for j in range(N):
            if i == j:
                continue
            psi_j = states[j]
            overlap = np.vdot(psi_j, psi_i)  # <ψ_j|ψ_i>
            gi += psi_j * overlap
        grads[i] = gi
    return grads

def step_cohere(states, eta):
    grads = coherence_gradient(states)
    new_states = []
    for psi, g in zip(states, grads):
        psi_new = normalize(psi + eta * g)
        new_states.append(psi_new)
    return new_states

def step_repel(states, alpha):
    C = coupling_matrix(states)
    N = len(states)
    new_states = []
    for i in range(N):
        push = np.zeros_like(states[i])
        for j in range(N):
            if i == j:
                continue
            push += C[i, j] * states[j]
        psi_new = normalize(states[i] - alpha * push)
        new_states.append(psi_new)
    return new_states

# -----------------------
# Main experiment
# -----------------------
def run_density_bridge(
    T=200,
    N=12,
    dim=16,
    mode="none",      # "none" | "cohere" | "repel"
    eta=0.05,         # used if mode="cohere"
    alpha=0.20,       # used if mode="repel"
    seed=0,
    out_csv="outputs/toy10_density_bridge.csv",
):
    rng = np.random.default_rng(seed)
    states = [random_state(rng, dim) for _ in range(N)]

    FIELDS = [
        "toy", "run_id", "seed", "t",
        "N", "dim",
        "mode", "eta", "alpha",
        "C_sum", "C_mean", "C_sigma", "C_max",
        "purity",
        "purity_from_C",
        "purity_err",
        "entropy",
        "status",
    ]
    logger = CSVLogger(out_csv, FIELDS)

    print("TOY10 — DENSITY BRIDGE (ρ, purity, entropy)")
    print(f"N={N} dim={dim} mode={mode} eta={eta} alpha={alpha}")
    print("Key check: purity == (N + 2*ΣC_ij)/N^2")
    print("")

    for t in range(T):
        C = coupling_matrix(states)
        C_sum, C_mean, C_sigma, C_max = coupling_sums(C)

        rho = density_matrix(states)
        p = purity(rho)
        S = von_neumann_entropy(rho)

        p_from_C = purity_identity_from_C(C_sum, N)
        p_err = abs(p - p_from_C)

        # heuristic status
        if p_err < 1e-10:
            status = "IDENTITY_OK"
        elif p_err < 1e-6:
            status = "IDENTITY_NUMERIC"
        else:
            status = "IDENTITY_FAIL"

        logger.log(
            toy="toy10_density_bridge",
            run_id=0,
            seed=seed,
            t=t,
            N=N,
            dim=dim,
            mode=mode,
            eta=eta,
            alpha=alpha,
            C_sum=C_sum,
            C_mean=C_mean,
            C_sigma=C_sigma,
            C_max=C_max,
            purity=p,
            purity_from_C=p_from_C,
            purity_err=p_err,
            entropy=S,
            status=status,
        )

        if t % 25 == 0:
            print(
                f"t={t:03d} | "
                f"purity={p:.6f} (from C={p_from_C:.6f}, err={p_err:.1e}) | "
                f"S={S:.6f} | <C>={C_mean:.4f} | {status}"
            )

        # evolve (optional)
        if mode == "cohere":
            states = step_cohere(states, eta=eta)
        elif mode == "repel":
            states = step_repel(states, alpha=alpha)
        elif mode == "none":
            pass
        else:
            raise ValueError("mode must be one of: none, cohere, repel")

    logger.close()
    print("")
    print(f"Saved CSV → {out_csv}")
    print("Interpretation:")
    print(" - purity ↑, entropy ↓ when states become more aligned/coherent.")
    print(" - purity ↓, entropy ↑ when states separate/orthogonalize.")
    print(" - The identity check ties your pairwise C_ij to a global summary (Tr(ρ^2)).")

if __name__ == "__main__":
    # Try mode="none" first (static ensemble)
    run_density_bridge(T=200, N=12, dim=16, mode="none", seed=0)

    # Then try one of these:
    # run_density_bridge(T=200, N=12, dim=16, mode="cohere", eta=0.05, seed=0,
    #                   out_csv="outputs/toy10_density_bridge_cohere.csv")
    # run_density_bridge(T=200, N=12, dim=16, mode="repel", alpha=0.20, seed=0,
    #                   out_csv="outputs/toy10_density_bridge_repel.csv")
