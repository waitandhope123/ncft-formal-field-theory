"""
toy04_v2_feedback_sync.py

TOY 04 v2 — FEEDBACK SYNCHRONIZATION
Kuramoto-style phase dynamics with NCFT-weighted couplings, plus slow adaptive feedback:

Baseline coupling from NCFT states:
    C0_ij = |<ψ_i|ψ_j>|^2

Evolving coupling matrix:
    C_ij(t+dt) = clip( C_ij(t) + dt * [ eps*cos(theta_i-theta_j) - gamma*(C_ij(t)-C0_ij) ], 0, 1 )

Phase dynamics:
    dtheta_i = omega_i + K * Σ_j C_ij(t) * sin(theta_j - theta_i)

This tests whether weak coherence can self-reinforce without "hard axiom checks".

Output:
  outputs/toy04_v2_feedback_sync.csv
"""

import csv
from pathlib import Path
import numpy as np

EPS = 1e-12

# -----------------------
# CSV Logger
# -----------------------
class CSVLogger:
    def __init__(self, filename, fieldnames):
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        self.file = open(filename, "w", newline="")
        self.writer = csv.DictWriter(self.file, fieldnames=fieldnames)
        self.writer.writeheader()

    def log(self, **row):
        self.writer.writerow(row)

    def close(self):
        self.file.close()

# -----------------------
# NCFT baseline couplings
# -----------------------
def normalize(psi):
    n = np.linalg.norm(psi)
    if n < EPS:
        raise ValueError("Zero norm forbidden")
    return psi / n

def random_state(rng, dim):
    psi = rng.normal(size=dim) + 1j * rng.normal(size=dim)
    return normalize(psi)

def coupling(a, b):
    c = np.abs(np.vdot(a, b)) ** 2
    # numerical clamp
    if c < 0 and c > -1e-9:
        c = 0.0
    if c > 1 and c < 1 + 1e-9:
        c = 1.0
    return float(c)

def coupling_matrix(states):
    N = len(states)
    C = np.zeros((N, N))
    for i in range(N):
        for j in range(i + 1, N):
            c = coupling(states[i], states[j])
            C[i, j] = C[j, i] = c
    return C

def coupling_stats(C):
    N = C.shape[0]
    vals = C[np.triu_indices(N, 1)]
    return float(np.mean(vals)), float(np.std(vals)), float(np.max(vals)), float(np.sum(vals))

# -----------------------
# Dynamics
# -----------------------
def kuramoto_step(theta, omega, C, K, dt, noise, rng):
    N = len(theta)
    dtheta = np.zeros(N)
    for i in range(N):
        s = 0.0
        for j in range(N):
            if i != j:
                s += C[i, j] * np.sin(theta[j] - theta[i])
        dtheta[i] = omega[i] + K * s
    theta = theta + dt * dtheta + noise * rng.normal(size=N) * np.sqrt(dt)
    return theta

def adapt_couplings(C, C0, theta, eps, gamma, dt):
    """
    C <- C + dt*( eps*cos(Δθ) - gamma*(C - C0) )
    symmetric, clipped to [0,1], diagonal 0.
    """
    N = C.shape[0]
    newC = C.copy()
    for i in range(N):
        newC[i, i] = 0.0
        for j in range(i + 1, N):
            drive = eps * np.cos(theta[i] - theta[j])
            relax = -gamma * (C[i, j] - C0[i, j])
            cij = C[i, j] + dt * (drive + relax)
            if cij < 0.0:
                cij = 0.0
            if cij > 1.0:
                cij = 1.0
            newC[i, j] = newC[j, i] = cij
    return newC

def order_parameter(theta):
    return float(np.abs(np.mean(np.exp(1j * theta))))

# -----------------------
# Main experiment
# -----------------------
def run_feedback_sync(
    T=400,
    N=12,
    dim=16,
    K=0.8,
    dt=0.05,
    noise=0.01,
    eps=0.10,      # adaptation strength
    gamma=0.50,    # pullback to baseline C0
    seed=0,
    out_csv="outputs/toy04_v2_feedback_sync.csv",
):
    rng = np.random.default_rng(seed)

    # baseline NCFT states/couplings
    states = [random_state(rng, dim) for _ in range(N)]
    C0 = coupling_matrix(states)

    # adaptive coupling starts at baseline
    C = C0.copy()

    # phase and natural frequency
    theta = rng.uniform(0, 2 * np.pi, size=N)
    omega = rng.normal(0.0, 0.5, size=N)

    FIELDS = [
        "toy", "run_id", "seed", "t",
        "N", "dim",
        "K", "dt", "noise",
        "eps", "gamma",
        "order_R",
        "C_mean", "C_sigma", "C_max", "C_total",
        "delta_C_l2",
        "status",
    ]
    logger = CSVLogger(out_csv, FIELDS)

    print("TOY04 v2 — FEEDBACK SYNCHRONIZATION")
    print(f"N={N} dim={dim} K={K} noise={noise} eps={eps} gamma={gamma}")
    print("")

    for t in range(T):
        # evolve phases using current couplings
        theta = kuramoto_step(theta, omega, C, K, dt, noise, rng)

        # adapt couplings from phase alignment + relax to baseline
        C = adapt_couplings(C, C0, theta, eps, gamma, dt)

        # metrics
        R = order_parameter(theta)
        C_mean, C_sig, C_max, C_total = coupling_stats(C)
        delta_C = float(np.linalg.norm(C - C0) / (np.linalg.norm(C0) + 1e-12))

        status = "COHERENT" if R > 0.8 else "DECOHERED"

        logger.log(
            toy="toy04_v2_feedback_sync",
            run_id=0,
            seed=seed,
            t=t,
            N=N,
            dim=dim,
            K=K,
            dt=dt,
            noise=noise,
            eps=eps,
            gamma=gamma,
            order_R=R,
            C_mean=C_mean,
            C_sigma=C_sig,
            C_max=C_max,
            C_total=C_total,
            delta_C_l2=delta_C,
            status=status,
        )

        if t % 25 == 0:
            print(
                f"t={t:03d} | R={R:.3f} | <C>={C_mean:.3f} Cmax={C_max:.3f} "
                f"| ||C-C0||/||C0||={delta_C:.3f} | {status}"
            )

    logger.close()
    print("")
    print(f"Saved CSV → {out_csv}")
    print("Notes:")
    print(" - If it still won't sync, increase eps (0.15–0.30) or K.")
    print(" - If C runs away from baseline, increase gamma or reduce eps.")
    print(" - delta_C_l2 shows how far couplings moved from NCFT baseline.")

if __name__ == "__main__":
    run_feedback_sync(
        T=400,
        N=12,
        dim=16,
        K=0.8,
        noise=0.01,
        eps=0.10,
        gamma=0.50,
        seed=0,
    )
