"""
toy05_conservation_or_lyapunov.py

TOY 05 — CONSERVATION / LYAPUNOV TEST (Projected Gradient)

We define a coherence functional:
    F = sum_{i<j} |<ψ_i|ψ_j>|^2

Define energy:
    E = -F

We evolve states ψ_i ∈ ℂ^dim on the unit sphere via projected gradient descent on E
(equivalently gradient ascent on F), with optional renormalization.

This toy checks:
- Does E(t) decrease monotonically (Lyapunov-like)?
- What happens if we disable per-step renormalization?

Output:
  outputs/toy05_conservation_or_lyapunov.csv
"""

import csv
from pathlib import Path
import numpy as np

EPS = 1e-12

# -----------------------
# CSV Logger
# -----------------------
class CSVLogger:
    def __init__(self, filename, fieldnames):
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        self.file = open(filename, "w", newline="")
        self.writer = csv.DictWriter(self.file, fieldnames=fieldnames)
        self.writer.writeheader()

    def log(self, **row):
        self.writer.writerow(row)

    def close(self):
        self.file.close()

# -----------------------
# Core math
# -----------------------
def normalize(psi: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(psi)
    if n < EPS:
        raise ValueError("Zero norm forbidden")
    return psi / n

def random_state(rng: np.random.Generator, dim: int) -> np.ndarray:
    psi = rng.normal(size=dim) + 1j * rng.normal(size=dim)
    return normalize(psi)

def coupling(a: np.ndarray, b: np.ndarray) -> float:
    # assumes normalized
    c = np.abs(np.vdot(a, b)) ** 2
    # numerical clamp
    if c < 0 and c > -1e-9:
        c = 0.0
    if c > 1 and c < 1 + 1e-9:
        c = 1.0
    return float(c)

def coupling_stats(states):
    N = len(states)
    vals = []
    total = 0.0
    cmax = 0.0
    for i in range(N):
        for j in range(i + 1, N):
            c = coupling(states[i], states[j])
            vals.append(c)
            total += c
            if c > cmax:
                cmax = c
    vals = np.array(vals, dtype=float)
    return {
        "pairs": len(vals),
        "C_mean": float(np.mean(vals)) if len(vals) else 0.0,
        "C_sigma": float(np.std(vals)) if len(vals) else 0.0,
        "C_max": float(cmax),
        "F_total": float(total),     # F = total coherence
        "E_energy": float(-total),   # E = -F
    }

# -----------------------
# Gradient on F (coherence)
# -----------------------
def coherence_gradient(states):
    """
    For F = Σ_{i<j} |<ψ_i|ψ_j>|^2 with normalized ψ,
    one (complex) gradient direction for ascent in F is:

      ∂F/∂ψ_i* = Σ_{j≠i} ψ_j * (<ψ_j|ψ_i>)

    We'll return grads aligned with that ascent direction.
    """
    N = len(states)
    grads = [np.zeros_like(states[0]) for _ in range(N)]
    for i in range(N):
        gi = np.zeros_like(states[i])
        psi_i = states[i]
        for j in range(N):
            if i == j:
                continue
            psi_j = states[j]
            overlap = np.vdot(psi_j, psi_i)  # <ψ_j|ψ_i>
            gi += psi_j * overlap
        grads[i] = gi
    return grads

def projected_update(states, grads, eta, renormalize=True):
    """
    Gradient ascent on F (equivalently descent on E=-F):
      ψ_i <- ψ_i + η * grad_i
    Then optionally renormalize onto unit sphere.
    """
    new_states = []
    for psi, g in zip(states, grads):
        psi_new = psi + eta * g
        if renormalize:
            psi_new = normalize(psi_new)
        new_states.append(psi_new)
    return new_states

def max_norm_error(states):
    return float(max(abs(np.linalg.norm(psi) - 1.0) for psi in states))

# -----------------------
# Main experiment
# -----------------------
def run_lyapunov_test(
    T=200,
    N=10,
    dim=16,
    eta=0.05,
    renormalize=True,
    seed=0,
    out_csv="outputs/toy05_conservation_or_lyapunov.csv",
):
    rng = np.random.default_rng(seed)
    states = [random_state(rng, dim) for _ in range(N)]

    FIELDS = [
        "toy", "run_id", "seed", "t",
        "N", "dim",
        "eta", "renormalize",
        "C_mean", "C_sigma", "C_max",
        "F_total", "E_energy",
        "delta_E",
        "norm_err_max",
        "status",
    ]
    logger = CSVLogger(out_csv, FIELDS)

    prev_E = None
    monotone_violations = 0

    print("TOY05 — LYAPUNOV / ENERGY TEST")
    print(f"N={N} dim={dim} eta={eta} renormalize={renormalize}")
    print("Goal: E=-F should be non-increasing (mostly) if step size is reasonable.")
    print("")

    for t in range(T):
        stats = coupling_stats(states)
        E = stats["E_energy"]

        delta_E = 0.0 if prev_E is None else (E - prev_E)  # should be <= 0 ideally
        if prev_E is not None and delta_E > 1e-9:
            monotone_violations += 1

        norm_err = max_norm_error(states)

        # status labeling
        status = "OK"
        if (not renormalize) and norm_err > 1e-3:
            status = "NORM_DRIFT"
        if monotone_violations > 0:
            status = "NON_MONOTONE"

        logger.log(
            toy="toy05_conservation_or_lyapunov",
            run_id=0,
            seed=seed,
            t=t,
            N=N,
            dim=dim,
            eta=eta,
            renormalize=int(renormalize),
            C_mean=stats["C_mean"],
            C_sigma=stats["C_sigma"],
            C_max=stats["C_max"],
            F_total=stats["F_total"],
            E_energy=E,
            delta_E=delta_E,
            norm_err_max=norm_err,
            status=status,
        )

        if t % 25 == 0:
            print(f"t={t:03d} | F={stats['F_total']:.4f} | E={E:.4f} | ΔE={delta_E:+.2e} | norm_err={norm_err:.2e} | {status}")

        # evolve
        grads = coherence_gradient(states)
        states = projected_update(states, grads, eta=eta, renormalize=renormalize)

        prev_E = E

    logger.close()

    print("")
    print(f"Saved CSV → {out_csv}")
    print(f"Monotonicity violations (ΔE>0): {monotone_violations}/{T-1}")
    print("Tips:")
    print(" - If you see many violations with renormalize=1, reduce eta (e.g., 0.02).")
    print(" - With renormalize=0, norm drift is expected and E may behave unpredictably.")

if __name__ == "__main__":
    # Default: projected gradient (stable)
    run_lyapunov_test(
        T=200,
        N=10,
        dim=16,
        eta=0.05,
        renormalize=True,
        seed=0,
    )

    # Optional: uncomment to see what happens without renormalization
    # run_lyapunov_test(T=200, N=10, dim=16, eta=0.05, renormalize=False, seed=0,
    #                  out_csv="outputs/toy05_conservation_or_lyapunov_no_renorm.csv")
