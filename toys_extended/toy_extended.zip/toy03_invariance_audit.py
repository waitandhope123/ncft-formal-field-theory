"""
toy03_invariance_audit.py

TOY 03 — INVARIANCE AUDIT
Checks two required invariances of the NCFT coupling definition:

1) Permutation invariance:
   Shuffling field order must not change coupling statistics.

2) Global unitary invariance:
   Applying the same unitary U to all states must not change couplings.

Output:
  outputs/toy03_invariance_audit.csv
"""

import csv
from pathlib import Path
import numpy as np
from scipy.stats import wasserstein_distance

EPS = 1e-12

# -----------------------
# CSV Logger
# -----------------------
class CSVLogger:
    def __init__(self, filename, fieldnames):
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        self.file = open(filename, "w", newline="")
        self.writer = csv.DictWriter(self.file, fieldnames=fieldnames)
        self.writer.writeheader()

    def log(self, **row):
        self.writer.writerow(row)

    def close(self):
        self.file.close()

# -----------------------
# Core math
# -----------------------
def normalize(psi):
    n = np.linalg.norm(psi)
    if n < EPS:
        raise ValueError("Zero norm forbidden")
    return psi / n

def random_state(rng, dim):
    psi = rng.normal(size=dim) + 1j * rng.normal(size=dim)
    return normalize(psi)

def coupling(a, b):
    c = np.abs(np.vdot(a, b)) ** 2
    if c < 0 and c > -1e-9:
        c = 0.0
    if c > 1 and c < 1 + 1e-9:
        c = 1.0
    return float(c)

def coupling_list(states):
    N = len(states)
    vals = []
    for i in range(N):
        for j in range(i + 1, N):
            vals.append(coupling(states[i], states[j]))
    return np.array(vals)

def random_unitary(rng, dim):
    # Haar-ish unitary via QR
    X = rng.normal(size=(dim, dim)) + 1j * rng.normal(size=(dim, dim))
    Q, R = np.linalg.qr(X)
    diag = np.diag(R)
    return Q * (diag / np.abs(diag))

# -----------------------
# Main experiment
# -----------------------
def run_invariance_audit(
    trials=200,
    N=10,
    dim=16,
    seed=0,
    out_csv="outputs/toy03_invariance_audit.csv",
):
    rng = np.random.default_rng(seed)

    FIELDS = [
        "toy", "run_id", "seed",
        "trial", "N", "dim",
        "perm_distance",
        "unitary_distance",
        "status",
    ]
    logger = CSVLogger(out_csv, FIELDS)

    perm_dists = []
    unitary_dists = []

    for trial in range(trials):
        states = [random_state(rng, dim) for _ in range(N)]

        base = coupling_list(states)

        # --- Permutation test
        perm = rng.permutation(N)
        permuted_states = [states[i] for i in perm]
        perm_vals = coupling_list(permuted_states)

        d_perm = wasserstein_distance(base, perm_vals)

        # --- Global unitary test
        U = random_unitary(rng, dim)
        rotated_states = [normalize(U @ psi) for psi in states]
        unit_vals = coupling_list(rotated_states)

        d_unit = wasserstein_distance(base, unit_vals)

        perm_dists.append(d_perm)
        unitary_dists.append(d_unit)

        status = "PASS" if (d_perm < 1e-10 and d_unit < 1e-10) else "FAIL"

        logger.log(
            toy="toy03_invariance_audit",
            run_id=0,
            seed=seed,
            trial=trial,
            N=N,
            dim=dim,
            perm_distance=d_perm,
            unitary_distance=d_unit,
            status=status,
        )

    logger.close()

    perm_dists = np.array(perm_dists)
    unitary_dists = np.array(unitary_dists)

    print("TOY03 — INVARIANCE AUDIT COMPLETE")
    print(f"Saved → {out_csv}")
    print("")
    print(f"Permutation distance:  mean={perm_dists.mean():.3e}  max={perm_dists.max():.3e}")
    print(f"Unitary distance:      mean={unitary_dists.mean():.3e}  max={unitary_dists.max():.3e}")
    print("")
    print("Expectation: both distances ≈ 0 (numerical noise only).")

if __name__ == "__main__":
    run_invariance_audit(
        trials=200,
        N=10,
        dim=16,
        seed=0,
    )
