"""
toy01_null_ensemble.py

TOY 01 — NULL ENSEMBLE BASELINE
Generate many random normalized complex state vectors ψ_i ∈ ℂ^dim for N fields.
Compute pairwise couplings C_ij = |<ψ_i|ψ_j>|^2.
Write per-trial metrics to CSV.

Output:
  outputs/toy01_null_ensemble.csv

This toy is purely a statistical baseline (null model).
"""

import csv
from pathlib import Path
import numpy as np

EPS = 1e-12

# -----------------------
# CSV Logger
# -----------------------
class CSVLogger:
    def __init__(self, filename, fieldnames):
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        self.file = open(filename, "w", newline="")
        self.writer = csv.DictWriter(self.file, fieldnames=fieldnames)
        self.writer.writeheader()

    def log(self, **row):
        self.writer.writerow(row)

    def close(self):
        self.file.close()

# -----------------------
# Core math
# -----------------------
def normalize(psi: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(psi)
    if n < EPS:
        raise ValueError("Zero norm forbidden")
    return psi / n

def random_state(rng: np.random.Generator, dim: int) -> np.ndarray:
    psi = rng.normal(size=dim) + 1j * rng.normal(size=dim)
    return normalize(psi)

def coupling(psi_a: np.ndarray, psi_b: np.ndarray) -> float:
    # assumes normalized inputs
    c = np.abs(np.vdot(psi_a, psi_b)) ** 2
    # numerical clamp
    if c < 0.0 and c > -1e-9:
        c = 0.0
    if c > 1.0 and c < 1.0 + 1e-9:
        c = 1.0
    return float(c)

def coupling_stats(states: list[np.ndarray]) -> dict:
    N = len(states)
    pairs = []
    cmax = 0.0
    total = 0.0
    for i in range(N):
        for j in range(i + 1, N):
            c = coupling(states[i], states[j])
            pairs.append(c)
            total += c
            if c > cmax:
                cmax = c

    pairs = np.array(pairs, dtype=float)
    return {
        "pairs": len(pairs),
        "C_mean": float(np.mean(pairs)) if len(pairs) else 0.0,
        "C_sigma": float(np.std(pairs)) if len(pairs) else 0.0,
        "C_min": float(np.min(pairs)) if len(pairs) else 0.0,
        "C_max": float(cmax),
        "C_total": float(total),
    }

# -----------------------
# Main experiment
# -----------------------
def run_null_ensemble(
    trials: int = 500,
    N: int = 12,
    dim: int = 16,
    seed: int = 0,
    out_csv: str = "outputs/toy01_null_ensemble.csv",
):
    rng = np.random.default_rng(seed)

    FIELDS = [
        "toy", "run_id", "seed",
        "trial", "N", "dim", "pairs",
        "C_mean", "C_sigma", "C_min", "C_max", "C_total",
        "status",
    ]
    logger = CSVLogger(out_csv, FIELDS)

    # For quick console summary across trials
    means = []
    sigmas = []
    totals = []
    cmaxs = []

    for trial in range(trials):
        states = [random_state(rng, dim) for _ in range(N)]
        stats = coupling_stats(states)

        means.append(stats["C_mean"])
        sigmas.append(stats["C_sigma"])
        totals.append(stats["C_total"])
        cmaxs.append(stats["C_max"])

        logger.log(
            toy="toy01_null_ensemble",
            run_id=0,
            seed=seed,
            trial=trial,
            N=N,
            dim=dim,
            pairs=stats["pairs"],
            C_mean=stats["C_mean"],
            C_sigma=stats["C_sigma"],
            C_min=stats["C_min"],
            C_max=stats["C_max"],
            C_total=stats["C_total"],
            status="NULL",
        )

    logger.close()

    # Console summary (baseline “expected” ranges)
    means = np.array(means)
    sigmas = np.array(sigmas)
    totals = np.array(totals)
    cmaxs = np.array(cmaxs)

    def q(x, p):
        return float(np.quantile(x, p))

    print("TOY01 — NULL ENSEMBLE COMPLETE")
    print(f"Saved: {out_csv}")
    print(f"Trials={trials} | N={N} | dim={dim} | pairs={N*(N-1)//2}")
    print("")
    print("Baseline distributions (over trials):")
    print(f"  C_mean : mean={means.mean():.6f} | q05={q(means,0.05):.6f} q50={q(means,0.50):.6f} q95={q(means,0.95):.6f}")
    print(f"  C_sigma: mean={sigmas.mean():.6f} | q05={q(sigmas,0.05):.6f} q50={q(sigmas,0.50):.6f} q95={q(sigmas,0.95):.6f}")
    print(f"  C_total: mean={totals.mean():.6f} | q05={q(totals,0.05):.6f} q50={q(totals,0.50):.6f} q95={q(totals,0.95):.6f}")
    print(f"  C_max  : mean={cmaxs.mean():.6f} | q05={q(cmaxs,0.05):.6f} q50={q(cmaxs,0.50):.6f} q95={q(cmaxs,0.95):.6f}")
    print("")
    print("Use this CSV as the null baseline for Toys 2–10.")

if __name__ == "__main__":
    # Adjust as desired
    run_null_ensemble(trials=500, N=12, dim=16, seed=0)
