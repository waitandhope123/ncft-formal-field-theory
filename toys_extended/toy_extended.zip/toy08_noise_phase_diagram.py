"""
toy08_noise_phase_diagram.py

TOY 08 — NOISE PHASE DIAGRAM
Sweep noise strength in Kuramoto-style frequency synchronization
with NCFT-weighted couplings.

Measures:
- Order parameter R(t)
- Time-averaged coherence vs noise
- Identifies breakdown threshold

Output:
  outputs/toy08_noise_phase_diagram.csv
"""

import csv
from pathlib import Path
import numpy as np

EPS = 1e-12

# -----------------------
# CSV Logger
# -----------------------
class CSVLogger:
    def __init__(self, filename, fieldnames):
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        self.file = open(filename, "w", newline="")
        self.writer = csv.DictWriter(self.file, fieldnames=fieldnames)
        self.writer.writeheader()

    def log(self, **row):
        self.writer.writerow(row)

    def close(self):
        self.file.close()

# -----------------------
# Core math
# -----------------------
def normalize(psi):
    n = np.linalg.norm(psi)
    if n < EPS:
        raise ValueError("Zero norm forbidden")
    return psi / n

def random_state(rng, dim):
    psi = rng.normal(size=dim) + 1j * rng.normal(size=dim)
    return normalize(psi)

def coupling(a, b):
    c = np.abs(np.vdot(a, b)) ** 2
    if c < 0 and c > -1e-9:
        c = 0.0
    if c > 1 and c < 1 + 1e-9:
        c = 1.0
    return float(c)

def coupling_matrix(states):
    N = len(states)
    C = np.zeros((N, N))
    for i in range(N):
        for j in range(i + 1, N):
            c = coupling(states[i], states[j])
            C[i, j] = C[j, i] = c
    return C

# -----------------------
# Kuramoto dynamics
# -----------------------
def kuramoto_step(theta, omega, C, K, dt, noise, rng):
    N = len(theta)
    dtheta = np.zeros(N)
    for i in range(N):
        s = 0.0
        for j in range(N):
            if i != j:
                s += C[i, j] * np.sin(theta[j] - theta[i])
        dtheta[i] = omega[i] + K * s
    theta = theta + dt * dtheta + noise * rng.normal(size=N) * np.sqrt(dt)
    return theta

def order_parameter(theta):
    return float(np.abs(np.mean(np.exp(1j * theta))))

# -----------------------
# Main experiment
# -----------------------
def run_noise_phase_diagram(
    noise_levels=(0.0, 0.01, 0.02, 0.05, 0.1, 0.2),
    T=300,
    burn_in=100,
    N=12,
    dim=16,
    K=0.8,
    dt=0.05,
    seed=0,
    out_csv="outputs/toy08_noise_phase_diagram.csv",
):
    rng = np.random.default_rng(seed)

    # Static NCFT states
    states = [random_state(rng, dim) for _ in range(N)]
    C = coupling_matrix(states)

    # Frequencies fixed across noise sweeps
    omega = rng.normal(0.0, 0.5, size=N)

    FIELDS = [
        "toy", "run_id", "seed",
        "noise", "t",
        "N", "dim",
        "K", "dt",
        "order_R",
        "status",
    ]
    logger = CSVLogger(out_csv, FIELDS)

    print("TOY08 — NOISE PHASE DIAGRAM")
    print(f"N={N} dim={dim} K={K}")
    print("")

    for noise in noise_levels:
        theta = rng.uniform(0, 2 * np.pi, size=N)
        R_vals = []

        for t in range(T):
            theta = kuramoto_step(theta, omega, C, K, dt, noise, rng)
            R = order_parameter(theta)

            if t >= burn_in:
                R_vals.append(R)

            status = "COHERENT" if R > 0.8 else "DECOHERED"

            logger.log(
                toy="toy08_noise_phase_diagram",
                run_id=0,
                seed=seed,
                noise=noise,
                t=t,
                N=N,
                dim=dim,
                K=K,
                dt=dt,
                order_R=R,
                status=status,
            )

        R_vals = np.array(R_vals)
        print(
            f"noise={noise:>6.3f} | "
            f"<R>={R_vals.mean():.3f} ± {R_vals.std():.3f}"
        )

    logger.close()
    print("")
    print(f"Saved CSV → {out_csv}")
    print("Interpretation:")
    print(" - Plot <R> vs noise → look for a sharp drop (critical noise).")
    print(" - This defines robustness / breakdown of Axiom 3 dynamics.")

if __name__ == "__main__":
    run_noise_phase_diagram(
        noise_levels=(0.0, 0.01, 0.02, 0.05, 0.1, 0.2),
        T=300,
        burn_in=100,
        N=12,
        dim=16,
        K=0.8,
        seed=0,
    )
