"""
toy07_graph_mediation.py

TOY 07 — GRAPH TOPOLOGY + INDIRECT MEDIATION
Fields live on a graph. Direct interactions only along edges.
We measure:
- Direct coupling statistics on edges
- Indirect 2-hop mediation for non-edges using common neighbors:
    I_ij = sum_{k in N(i)∩N(j)} C_ik * C_kj

Graph types:
- ring
- erdos_renyi (ER)
- preferential_attachment (BA-like)

Output:
  outputs/toy07_graph_mediation.csv
"""

import csv
from pathlib import Path
import numpy as np

EPS = 1e-12

# -----------------------
# CSV Logger
# -----------------------
class CSVLogger:
    def __init__(self, filename, fieldnames):
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        self.file = open(filename, "w", newline="")
        self.writer = csv.DictWriter(self.file, fieldnames=fieldnames)
        self.writer.writeheader()

    def log(self, **row):
        self.writer.writerow(row)

    def close(self):
        self.file.close()

# -----------------------
# Core math
# -----------------------
def normalize(psi):
    n = np.linalg.norm(psi)
    if n < EPS:
        raise ValueError("Zero norm forbidden")
    return psi / n

def random_state(rng, dim):
    psi = rng.normal(size=dim) + 1j * rng.normal(size=dim)
    return normalize(psi)

def coupling(a, b):
    c = np.abs(np.vdot(a, b)) ** 2
    if c < 0 and c > -1e-9:
        c = 0.0
    if c > 1 and c < 1 + 1e-9:
        c = 1.0
    return float(c)

def coupling_matrix(states):
    N = len(states)
    C = np.zeros((N, N), dtype=float)
    for i in range(N):
        for j in range(i + 1, N):
            c = coupling(states[i], states[j])
            C[i, j] = C[j, i] = c
    return C

# -----------------------
# Graph builders (no networkx)
# -----------------------
def graph_ring(N, k=2):
    """Ring with k neighbors on each side (degree 2k)."""
    adj = [set() for _ in range(N)]
    for i in range(N):
        for d in range(1, k + 1):
            j1 = (i + d) % N
            j2 = (i - d) % N
            adj[i].add(j1); adj[j1].add(i)
            adj[i].add(j2); adj[j2].add(i)
    return adj

def graph_erdos_renyi(N, p, rng):
    adj = [set() for _ in range(N)]
    for i in range(N):
        for j in range(i + 1, N):
            if rng.random() < p:
                adj[i].add(j); adj[j].add(i)
    return adj

def graph_preferential_attachment(N, m, rng):
    """
    Simple BA-like preferential attachment.
    Start with a fully connected core of size m+1, then add nodes attaching to m existing nodes
    with probability proportional to degree+1.
    """
    if m < 1 or m >= N:
        raise ValueError("m must satisfy 1 <= m < N")

    adj = [set() for _ in range(N)]
    core = m + 1
    # fully connect core
    for i in range(core):
        for j in range(i + 1, core):
            adj[i].add(j); adj[j].add(i)

    degrees = np.zeros(N, dtype=float)
    for i in range(core):
        degrees[i] = len(adj[i])

    for new in range(core, N):
        # choose m targets without replacement
        targets = set()
        while len(targets) < m:
            weights = degrees[:new] + 1.0
            probs = weights / weights.sum()
            t = rng.choice(new, p=probs)
            targets.add(int(t))
        for t in targets:
            adj[new].add(t); adj[t].add(new)
        degrees[new] = len(adj[new])
        for t in targets:
            degrees[t] = len(adj[t])

    return adj

def edge_set(adj):
    edges = set()
    N = len(adj)
    for i in range(N):
        for j in adj[i]:
            if i < j:
                edges.add((i, j))
    return edges

# -----------------------
# Mediation metrics
# -----------------------
def mediation_metrics(C, adj):
    """
    Direct: couplings only on edges.
    Indirect (2-hop): for non-edges, I_ij = sum_{k in common neighbors} C_ik*C_kj
    """
    N = C.shape[0]
    edges = edge_set(adj)
    neighbors = adj

    direct_vals = []
    indirect_vals = []
    indirect_pairs = 0

    for i in range(N):
        for j in range(i + 1, N):
            if (i, j) in edges:
                direct_vals.append(C[i, j])
            else:
                # 2-hop mediation via common neighbors
                commons = neighbors[i].intersection(neighbors[j])
                if commons:
                    indirect_pairs += 1
                    s = 0.0
                    for k in commons:
                        s += C[i, k] * C[k, j]
                    indirect_vals.append(s)

    direct_vals = np.array(direct_vals, dtype=float)
    indirect_vals = np.array(indirect_vals, dtype=float)

    def safe_stats(x):
        if len(x) == 0:
            return 0.0, 0.0, 0.0
        return float(np.mean(x)), float(np.std(x)), float(np.max(x))

    d_mean, d_sig, d_max = safe_stats(direct_vals)
    i_mean, i_sig, i_max = safe_stats(indirect_vals)

    return {
        "edges": len(edges),
        "direct_mean": d_mean,
        "direct_sigma": d_sig,
        "direct_max": d_max,
        "indirect_pairs": indirect_pairs,
        "indirect_mean": i_mean,
        "indirect_sigma": i_sig,
        "indirect_max": i_max,
        "indirect_over_direct": float(i_mean / (d_mean + 1e-12)),
    }

# -----------------------
# Main experiment
# -----------------------
def run_graph_mediation(
    trials=200,
    N=20,
    dim=16,
    seed=0,
    ring_k=2,
    er_p=0.15,
    pa_m=2,
    out_csv="outputs/toy07_graph_mediation.csv",
):
    rng = np.random.default_rng(seed)

    FIELDS = [
        "toy", "run_id", "seed",
        "trial", "graph_type",
        "N", "dim",
        "edges",
        "direct_mean", "direct_sigma", "direct_max",
        "indirect_pairs",
        "indirect_mean", "indirect_sigma", "indirect_max",
        "indirect_over_direct",
        "status",
    ]
    logger = CSVLogger(out_csv, FIELDS)

    graph_specs = [
        ("ring", lambda: graph_ring(N, k=ring_k)),
        ("erdos_renyi", lambda: graph_erdos_renyi(N, p=er_p, rng=rng)),
        ("preferential_attachment", lambda: graph_preferential_attachment(N, m=pa_m, rng=rng)),
    ]

    print("TOY07 — GRAPH MEDIATION")
    print(f"N={N} dim={dim} trials={trials}")
    print(f"Ring k={ring_k} | ER p={er_p} | PA m={pa_m}")
    print("")

    for graph_type, build in graph_specs:
        ratios = []
        for trial in range(trials):
            states = [random_state(rng, dim) for _ in range(N)]
            C = coupling_matrix(states)
            adj = build()

            m = mediation_metrics(C, adj)
            ratios.append(m["indirect_over_direct"])

            # heuristic label
            status = "MEDIATION_PRESENT" if m["indirect_mean"] > 0 else "NO_MEDIATION"

            logger.log(
                toy="toy07_graph_mediation",
                run_id=0,
                seed=seed,
                trial=trial,
                graph_type=graph_type,
                N=N,
                dim=dim,
                edges=m["edges"],
                direct_mean=m["direct_mean"],
                direct_sigma=m["direct_sigma"],
                direct_max=m["direct_max"],
                indirect_pairs=m["indirect_pairs"],
                indirect_mean=m["indirect_mean"],
                indirect_sigma=m["indirect_sigma"],
                indirect_max=m["indirect_max"],
                indirect_over_direct=m["indirect_over_direct"],
                status=status,
            )

        ratios = np.array(ratios, dtype=float)
        print(f"{graph_type:<22s} | mean(indirect/direct) = {ratios.mean():.4f} | q95={float(np.quantile(ratios,0.95)):.4f}")

    logger.close()
    print("")
    print(f"Saved CSV → {out_csv}")
    print("Interpretation:")
    print(" - Higher indirect/direct suggests stronger generic triangulation via topology.")
    print(" - Compare graph types: ring vs ER vs preferential attachment.")

if __name__ == "__main__":
    run_graph_mediation(
        trials=200,
        N=20,
        dim=16,
        seed=0,
        ring_k=2,
        er_p=0.15,
        pa_m=2,
    )
