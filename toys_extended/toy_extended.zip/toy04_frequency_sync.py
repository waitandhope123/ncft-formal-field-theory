"""
toy04_frequency_sync.py

TOY 04 — FREQUENCY SYNCHRONIZATION
Axiom 3 becomes dynamical via a Kuramoto-style phase model,
with coupling weights C_ij = |<ψ_i|ψ_j>|^2.

Output:
  outputs/toy04_frequency_sync.csv
"""

import csv
from pathlib import Path
import numpy as np

EPS = 1e-12

# -----------------------
# CSV Logger
# -----------------------
class CSVLogger:
    def __init__(self, filename, fieldnames):
        Path(filename).parent.mkdir(parents=True, exist_ok=True)
        self.file = open(filename, "w", newline="")
        self.writer = csv.DictWriter(self.file, fieldnames=fieldnames)
        self.writer.writeheader()

    def log(self, **row):
        self.writer.writerow(row)

    def close(self):
        self.file.close()

# -----------------------
# Core math
# -----------------------
def normalize(psi):
    n = np.linalg.norm(psi)
    if n < EPS:
        raise ValueError("Zero norm forbidden")
    return psi / n

def random_state(rng, dim):
    psi = rng.normal(size=dim) + 1j * rng.normal(size=dim)
    return normalize(psi)

def coupling(a, b):
    c = np.abs(np.vdot(a, b)) ** 2
    if c < 0 and c > -1e-9:
        c = 0.0
    if c > 1 and c < 1 + 1e-9:
        c = 1.0
    return float(c)

def coupling_matrix(states):
    N = len(states)
    C = np.zeros((N, N))
    for i in range(N):
        for j in range(i + 1, N):
            c = coupling(states[i], states[j])
            C[i, j] = C[j, i] = c
    return C

# -----------------------
# Kuramoto dynamics
# -----------------------
def kuramoto_step(theta, omega, C, K, dt, noise, rng):
    N = len(theta)
    dtheta = np.zeros(N)
    for i in range(N):
        s = 0.0
        for j in range(N):
            if i != j:
                s += C[i, j] * np.sin(theta[j] - theta[i])
        dtheta[i] = omega[i] + K * s
    theta = theta + dt * dtheta + noise * rng.normal(size=N) * np.sqrt(dt)
    return theta

def order_parameter(theta):
    return float(np.abs(np.mean(np.exp(1j * theta))))

# -----------------------
# Main experiment
# -----------------------
def run_frequency_sync(
    T=300,
    N=12,
    dim=16,
    K=0.8,
    dt=0.05,
    noise=0.01,
    seed=0,
    out_csv="outputs/toy04_frequency_sync.csv",
):
    rng = np.random.default_rng(seed)

    # NCFT states (static for this toy)
    states = [random_state(rng, dim) for _ in range(N)]
    C = coupling_matrix(states)

    # Phase + frequency init
    theta = rng.uniform(0, 2 * np.pi, size=N)
    omega = rng.normal(0.0, 0.5, size=N)

    FIELDS = [
        "toy", "run_id", "seed", "t",
        "N", "dim",
        "K", "dt", "noise",
        "C_mean", "C_sigma", "C_max", "C_total",
        "freq_sigma",
        "order_R",
        "status",
    ]
    logger = CSVLogger(out_csv, FIELDS)

    # Static coupling stats
    C_vals = C[np.triu_indices(N, 1)]
    C_mean = float(np.mean(C_vals))
    C_sigma = float(np.std(C_vals))
    C_max = float(np.max(C_vals))
    C_total = float(np.sum(C_vals))

    print("TOY04 — FREQUENCY SYNCHRONIZATION")
    print(f"N={N} dim={dim} K={K} noise={noise}")
    print("")

    for t in range(T):
        theta = kuramoto_step(theta, omega, C, K, dt, noise, rng)

        freq_sigma = float(np.std(theta))
        R = order_parameter(theta)
        status = "COHERENT" if R > 0.8 else "DECOHERED"

        logger.log(
            toy="toy04_frequency_sync",
            run_id=0,
            seed=seed,
            t=t,
            N=N,
            dim=dim,
            K=K,
            dt=dt,
            noise=noise,
            C_mean=C_mean,
            C_sigma=C_sigma,
            C_max=C_max,
            C_total=C_total,
            freq_sigma=freq_sigma,
            order_R=R,
            status=status,
        )

        if t % 25 == 0:
            print(f"t={t:03d} | R={R:.3f} | σθ={freq_sigma:.3f} | {status}")

    logger.close()

    print("")
    print(f"Saved CSV → {out_csv}")
    print("Interpretation:")
    print("  R → 1   : synchronized (Axiom 3 emergent)")
    print("  R ≈ 0   : incoherent")

if __name__ == "__main__":
    run_frequency_sync(
        T=300,
        N=12,
        dim=16,
        K=0.8,
        noise=0.01,
        seed=0,
    )
