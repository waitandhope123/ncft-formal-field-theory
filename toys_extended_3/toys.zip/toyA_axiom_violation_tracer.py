import numpy as np
from toy_utils import (
    random_states, pairwise_stats, global_norm,
    enforce_unit_norm_each, enforce_global_norm
)

def step_update(psis: np.ndarray, eta: float, mode="raw"):
    """
    Replace this with YOUR generator step.
    This default is intentionally 'dangerous' to demonstrate detection.
    """
    N, d = psis.shape
    rng = np.random.default_rng(123)
    noise = (rng.normal(size=(N, d)) + 1j*rng.normal(size=(N, d))) * 0.05
    out = psis + eta * noise

    if mode == "raw":
        return out
    elif mode == "unit_each":
        return enforce_unit_norm_each(out)
    elif mode == "global":
        out = enforce_unit_norm_each(out)
        return enforce_global_norm(out)
    else:
        raise ValueError("Unknown mode.")

def run(N=12, d=16, steps=500, eta=0.1, mode="raw", seed=0):
    psis = random_states(N, d, complex_states=True, seed=seed)

    # baseline
    base = pairwise_stats(psis)
    print(f"t=0 | <C>={base['mean']:.6f} σ={base['sigma']:.6f} Cmax={base['max']:.6f} gt1={base['count_gt1']} "
          f"| gnorm={global_norm(psis):.6f}")

    for t in range(1, steps+1):
        psis = step_update(psis, eta=eta, mode=mode)

        # diagnostics
        st = pairwise_stats(psis)
        norms = np.linalg.norm(psis, axis=1)
        max_norm_err = float(np.max(np.abs(norms - 1.0)))
        gnorm = global_norm(psis)

        # violation triggers
        if st["count_gt1"] > 0 or np.isnan(st["max"]) or max_norm_err > 1e-6 or np.isnan(gnorm):
            i, j = st["argmax_pair"] if st["argmax_pair"] else (-1, -1)
            print("💥 VIOLATION")
            print(f"t={t} mode={mode} eta={eta}")
            print(f"Cmax={st['max']:.12f} at pair ({i},{j}) | count(C>1)={st['count_gt1']}")
            print(f"Remember: for Axiom2, C must be ≤ 1.0")
            print(f"max_per_field_norm_err={max_norm_err:.3e}")
            print(f"global_norm={gnorm:.12f}")
            # dump a bit more context
            print(f"<C>={st['mean']:.6f} σ={st['sigma']:.6f} Cmin={st['min']:.6f} total={st['total']:.6f}")
            return

        if t % 50 == 0:
            print(f"t={t:04d} | <C>={st['mean']:.6f} σ={st['sigma']:.6f} Cmax={st['max']:.6f} "
                  f"| norm_err={max_norm_err:.2e} gnorm={gnorm:.6f}")

    print("✅ No violations detected within run.")

if __name__ == "__main__":
    # Try modes: raw, unit_each, global
    run(N=25, d=16, steps=1000, eta=0.1, mode="raw", seed=7)
