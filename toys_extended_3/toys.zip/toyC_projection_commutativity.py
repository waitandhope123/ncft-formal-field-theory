import numpy as np
from toy_utils import (
    random_states, pairwise_stats,
    enforce_unit_norm_each, enforce_global_norm
)

def generator_update(psis: np.ndarray, eta: float):
    """
    Replace with your actual generator step.
    """
    N, d = psis.shape
    rng = np.random.default_rng(999)
    drift = (rng.normal(size=(N, d)) + 1j*rng.normal(size=(N, d))) * 0.02
    return psis + eta * drift

def project(psis: np.ndarray, kind="global"):
    if kind == "unit_each":
        return enforce_unit_norm_each(psis)
    elif kind == "global":
        ps = enforce_unit_norm_each(psis)
        return enforce_global_norm(ps)
    else:
        raise ValueError("Unknown projection kind.")

def run(N=25, d=16, steps=200, eta=0.1, proj_kind="global", seed=0):
    base = random_states(N, d, complex_states=True, seed=seed)

    # Pipeline A: update -> project
    A = base.copy()
    # Pipeline B: project -> update -> project
    B = base.copy()
    # Pipeline C: update only (no projection)
    C = base.copy()

    print(f"Running commutativity test: N={N} d={d} eta={eta} proj={proj_kind} steps={steps}")

    for t in range(1, steps+1):
        A = project(generator_update(A, eta), kind=proj_kind)
        B = project(generator_update(project(B, kind=proj_kind), eta), kind=proj_kind)
        C = generator_update(C, eta)

        if t % 25 == 0 or t == 1:
            sA = pairwise_stats(A)
            sB = pairwise_stats(B)
            sC = pairwise_stats(C)

            # compare A vs B
            d_mean = abs(sA["mean"] - sB["mean"])
            d_sigma = abs(sA["sigma"] - sB["sigma"])
            d_max = abs(sA["max"] - sB["max"])

            print(f"t={t:03d} | "
                  f"A:<C>={sA['mean']:.4f} σ={sA['sigma']:.4f} Cmax={sA['max']:.4f} | "
                  f"B:<C>={sB['mean']:.4f} σ={sB['sigma']:.4f} Cmax={sB['max']:.4f} | "
                  f"|Δ| mean={d_mean:.2e} σ={d_sigma:.2e} max={d_max:.2e} | "
                  f"C_raw Cmax={sC['max']:.4f} gt1={sC['count_gt1']}")

    print("Done.")

if __name__ == "__main__":
    run(N=50, d=16, steps=200, eta=0.2, proj_kind="global", seed=1)
