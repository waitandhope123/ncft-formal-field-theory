import numpy as np
from dataclasses import dataclass

EPS = 1e-12

def normalize(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v)
    if n < EPS:
        raise ValueError("Zero/near-zero norm encountered during normalize().")
    return v / n

def coupling(psi_i: np.ndarray, psi_j: np.ndarray) -> float:
    # Axiom-2 form: |<psi_i|psi_j>|^2
    inner = np.vdot(psi_i, psi_j)  # conjugate dot
    return float(np.abs(inner)**2)

def pairwise_stats(psis: np.ndarray):
    # psis shape: (N, d) complex/float
    N = psis.shape[0]
    Cs = []
    pairs = []
    for i in range(N):
        for j in range(i+1, N):
            c = coupling(psis[i], psis[j])
            Cs.append(c)
            pairs.append((i, j))
    Cs = np.array(Cs, dtype=float)
    return {
        "mean": float(Cs.mean()) if len(Cs) else 0.0,
        "sigma": float(Cs.std(ddof=0)) if len(Cs) else 0.0,
        "max": float(Cs.max()) if len(Cs) else 0.0,
        "min": float(Cs.min()) if len(Cs) else 0.0,
        "argmax_pair": pairs[int(Cs.argmax())] if len(Cs) else None,
        "argmin_pair": pairs[int(Cs.argmin())] if len(Cs) else None,
        "count_gt1": int(np.sum(Cs > 1.0 + 1e-9)),
        "total": float(Cs.sum()) if len(Cs) else 0.0,
    }

def global_norm(psis: np.ndarray) -> float:
    # "global" norm: sqrt(sum_i ||psi_i||^2)
    return float(np.sqrt(np.sum(np.linalg.norm(psis, axis=1)**2)))

def enforce_unit_norm_each(psis: np.ndarray) -> np.ndarray:
    out = psis.copy()
    for i in range(out.shape[0]):
        out[i] = normalize(out[i])
    return out

def enforce_global_norm(psis: np.ndarray) -> np.ndarray:
    # makes total system norm exactly 1 (as in your v3/v4 stability toys)
    out = psis.copy()
    gn = global_norm(out)
    if gn < EPS:
        raise ValueError("Zero/near-zero global norm in enforce_global_norm().")
    return out / gn

def random_states(N: int, d: int, complex_states=True, seed=0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    if complex_states:
        x = rng.normal(size=(N, d)) + 1j * rng.normal(size=(N, d))
    else:
        x = rng.normal(size=(N, d))
    x = enforce_unit_norm_each(x)
    return x
