import numpy as np
from toy_utils import random_states, pairwise_stats, normalize

def tangent_project(psi, g):
    return g - psi * np.vdot(psi, g)

def force_fn(psis):
    # mild balanced force (won't instantly collapse)
    N, d = psis.shape
    mean = np.mean(psis, axis=0)
    g = mean - psis
    return g

def intrinsic_step(psis, eta):
    g_all = force_fn(psis)
    out = psis.copy()
    for i in range(out.shape[0]):
        gi = tangent_project(out[i], g_all[i])
        out[i] = normalize(out[i] + eta * gi)
    return out

def run(grid_N=(2, 8, 32, 128), grid_d=(4, 16, 64), etas=(0.05, 0.1, 0.2, 0.4), steps=400, seed=0):
    print("INTRINSIC PHASE MAP")
    print("N  dim  eta   ok  final<C>   finalσ    finalCmax")
    print("-"*60)

    for N in grid_N:
        for d in grid_d:
            for eta in etas:
                psis = random_states(N, d, complex_states=True, seed=seed)

                ok = True
                for _ in range(steps):
                    psis = intrinsic_step(psis, eta)
                    st = pairwise_stats(psis)
                    norms = np.linalg.norm(psis, axis=1)
                    if np.max(np.abs(norms - 1.0)) > 1e-6 or st["count_gt1"] > 0 or np.isnan(st["max"]):
                        ok = False
                        break

                st = pairwise_stats(psis)
                print(f"{N:<3d}{d:<5d}{eta:<6.2f}{'✓' if ok else '✗':<4s}{st['mean']:<10.6f}{st['sigma']:<10.6f}{st['max']:<10.6f}")

if __name__ == "__main__":
    run()
