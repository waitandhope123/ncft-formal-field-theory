import numpy as np
from toy_utils import random_states, pairwise_stats, normalize

def coupling_gradient_proxy(psis: np.ndarray):
    """
    Define a "force" that tries to change couplings.
    Replace with your intended interaction law.
    This proxy encourages coherence (pull together).
    """
    N, d = psis.shape
    g = np.zeros_like(psis, dtype=psis.dtype)
    for i in range(N):
        acc = np.zeros(d, dtype=psis.dtype)
        for j in range(N):
            if i == j:
                continue
            # Pull i toward j (simple proxy)
            acc += psis[j]
        g[i] = acc / max(N-1, 1)
    return g

def intrinsic_step(psis: np.ndarray, eta: float):
    g = coupling_gradient_proxy(psis)
    out = psis.copy()
    for i in range(out.shape[0]):
        psi = out[i]
        gi = g[i]

        # tangent projection (complex-safe)
        inner = np.vdot(psi, gi)
        gi_tan = gi - psi * inner

        # step + retract to unit sphere
        out[i] = normalize(psi + eta * gi_tan)

    return out

def run(N=25, d=16, steps=500, eta=0.2, seed=0):
    psis = random_states(N, d, complex_states=True, seed=seed)

    for t in range(0, steps+1):
        st = pairwise_stats(psis)
        if t % 50 == 0:
            print(f"t={t:04d} | <C>={st['mean']:.6f} σ={st['sigma']:.6f} Cmax={st['max']:.6f} gt1={st['count_gt1']}")

        # hard fail if C>1 (should never happen if states are unit vectors)
        if st["count_gt1"] > 0:
            print("💥 Found C>1 — this should not happen with unit-normalized states + proper vdot.")
            return

        psis = intrinsic_step(psis, eta=eta)

    print("✅ Completed without violations.")

if __name__ == "__main__":
    run(N=50, d=16, steps=1000, eta=0.3, seed=2)
