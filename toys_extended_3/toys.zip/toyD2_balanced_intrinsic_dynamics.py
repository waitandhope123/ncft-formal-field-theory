import numpy as np
from toy_utils import random_states, pairwise_stats, normalize, coupling

def tangent_project(psi: np.ndarray, g: np.ndarray) -> np.ndarray:
    inner = np.vdot(psi, g)
    return g - psi * inner

def balanced_force(psis: np.ndarray, lam_attract=1.0, lam_repel=0.7):
    """
    Attraction: pull toward mean vector
    Repulsion: push away from highly-overlapping neighbors
    """
    N, d = psis.shape
    g = np.zeros_like(psis, dtype=psis.dtype)
    mean = np.mean(psis, axis=0)

    # Attraction component
    for i in range(N):
        g[i] += lam_attract * (mean - psis[i])

    # Repulsion component: push away from top overlaps
    # (cheap O(N^2) toy; fine for N<=200-ish)
    for i in range(N):
        rep = np.zeros(d, dtype=psis.dtype)
        for j in range(N):
            if i == j:
                continue
            cij = coupling(psis[i], psis[j])
            # only repel if overlap is high; smooth ramp
            if cij > 0.2:
                rep += (cij - 0.2) * (psis[j])
        g[i] -= lam_repel * rep / max(N-1, 1)

    return g

def intrinsic_step(psis: np.ndarray, eta: float, lam_attract=1.0, lam_repel=0.7):
    g_all = balanced_force(psis, lam_attract=lam_attract, lam_repel=lam_repel)
    out = psis.copy()
    for i in range(out.shape[0]):
        gi_tan = tangent_project(out[i], g_all[i])
        out[i] = normalize(out[i] + eta * gi_tan)
    return out

def run(N=50, d=16, steps=1000, eta=0.25, lam_attract=1.0, lam_repel=0.7, seed=0):
    psis = random_states(N, d, complex_states=True, seed=seed)

    for t in range(0, steps + 1):
        st = pairwise_stats(psis)
        if t % 50 == 0:
            print(f"t={t:04d} | <C>={st['mean']:.6f} σ={st['sigma']:.6f} Cmax={st['max']:.6f} gt1={st['count_gt1']}")

        psis = intrinsic_step(psis, eta=eta, lam_attract=lam_attract, lam_repel=lam_repel)

    print("✅ Completed.")

if __name__ == "__main__":
    # Try (lam_repel) 0.0 (collapse) → 0.6..1.2 (balanced)
    run(N=50, d=16, steps=1000, eta=0.25, lam_attract=1.0, lam_repel=0.8, seed=2)
