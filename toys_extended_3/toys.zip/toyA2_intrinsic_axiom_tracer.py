import numpy as np
from toy_utils import random_states, pairwise_stats, enforce_unit_norm_each, enforce_global_norm, normalize

def tangent_project(psi: np.ndarray, g: np.ndarray) -> np.ndarray:
    inner = np.vdot(psi, g)
    return g - psi * inner

def force_fn(psis: np.ndarray):
    # Replace with your real NCFT force law once you have one.
    N, d = psis.shape
    g = np.zeros_like(psis, dtype=psis.dtype)
    mean = np.mean(psis, axis=0)
    for i in range(N):
        g[i] = mean - psis[i]
    return g

def intrinsic_step(psis: np.ndarray, eta: float):
    g_all = force_fn(psis)
    out = psis.copy()
    for i in range(out.shape[0]):
        gi_tan = tangent_project(out[i], g_all[i])
        out[i] = normalize(out[i] + eta * gi_tan)
    return out

def raw_step(psis: np.ndarray, eta: float):
    # the same force but without tangent projection (will drift)
    g_all = force_fn(psis)
    return psis + eta * g_all

def project(psis: np.ndarray, kind="global"):
    if kind == "unit_each":
        return enforce_unit_norm_each(psis)
    elif kind == "global":
        ps = enforce_unit_norm_each(psis)
        return enforce_global_norm(ps)
    else:
        raise ValueError("Unknown projection kind.")

def run(N=25, d=16, steps=200, eta=0.2, seed=0):
    base = random_states(N, d, complex_states=True, seed=seed)

    # A: intrinsic only (should be stable)
    A = base.copy()

    # B: raw update + projection (your old stabilizer)
    B = base.copy()

    print(f"Intrinsic vs projected: N={N} d={d} eta={eta} steps={steps}")

    for t in range(1, steps + 1):
        A = intrinsic_step(A, eta)
        B = project(raw_step(B, eta), kind="global")

        if t % 25 == 0 or t == 1:
            sA = pairwise_stats(A)
            sB = pairwise_stats(B)

            # compare summary stats
            d_mean = abs(sA["mean"] - sB["mean"])
            d_max = abs(sA["max"] - sB["max"])
            print(f"t={t:03d} | A:<C>={sA['mean']:.6f} Cmax={sA['max']:.6f} | "
                  f"B:<C>={sB['mean']:.6f} Cmax={sB['max']:.6f} | "
                  f"|Δ| mean={d_mean:.2e} max={d_max:.2e}")

    print("Done.")

if __name__ == "__main__":
    run(N=50, d=16, steps=200, eta=0.2, seed=1)
